package com.qc.controller;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GupshubController {

	@RequestMapping(path ="/gubshub")
	public String webhook(@RequestBody String request) 
	{
		String speech = "";
		String sessionId = "";
		String action = "";
		String questions = "";
		String source = "";
		String queryText = "";
		String mobile="";
		String message="";
		try 
		{
		JSONObject object = new JSONObject(request);
		sessionId = object.get("session") + "";
		action = object.getJSONObject("queryResult").get("action") + "";
		try {
			queryText = object.getJSONObject("queryResult").get("queryText") + "";
			String str[]=queryText.split("##");
			mobile=str[0];
			message =str[1];
			if("hi".equalsIgnoreCase(message) ||"hello".equalsIgnoreCase(message) ) {
				message="Hello I am Adit, your Max Life Assistant.How may i help you?";
			}else if("how are you".equalsIgnoreCase(message)){
				message="Hello I am good. How may i help you?";
			}else {
				message="Sorry! I did not understand you.";
			}
			message=URLEncoder.encode(message,"UTF-8");
			
		} catch (Exception ex) {
			queryText = "";
		}
		}catch(Exception e) {
			System.out.println("exception in webhook "+e);
		}
		switch (action.toUpperCase())
		{
		
		case "INPUT.WELCOME":
		{
			try
			{
			 sendMediaMsgToGupsHub();
			//sendTextMsgToGupsHub(mobile,message);	
			}catch(Exception e)
			{
			 System.out.println("creating exception while calling gupshub method "+e);
			}
		speech = response("Success");
		break;
		}
		}
		return speech;
	}
	public String response(String speech)
	{
		
		StringBuilder sb = new StringBuilder();
		sb.append("	{	");
		sb.append("	  \"fulfillmentText\": \"displayed&spoken response\",	");
		sb.append("	  \"fulfillmentMessages\": [	");
		sb.append("	    {	");
		sb.append("	      \"text\": {	");
		sb.append("	        \"text\": [\""+speech+"\"]	");
		sb.append("	      }	");
		sb.append("	    }	");
		sb.append("	  ],	");
		sb.append("	  \"payload\": {	");
		sb.append("	    \"facebook\": {	");
		sb.append("	      \"type\": \"Chatbot\",	");
		sb.append("	      \"platform\": \"API.AI\",	");
		sb.append("	      \"title\": \"MLIChatBot\",	");
		sb.append("	      \"imageUrl\": \"BOT\",	");
		sb.append("	      \"buttons\": [	");
		StringBuilder sb3 = new StringBuilder();
		sb3.append("	      ]	");
		sb3.append("	    }	");
		sb3.append("	  },	");
		sb3.append("	  \"source\": \"java-webhook\"	");
		sb3.append("	}	");
		sb.append(sb3.toString());
		return sb.toString();
	}
	
	private void sendTextMsgToGupsHub(String mobile,String msg) throws Exception {

		try {
		
		String url ="https://media.smsgupshup.com/GatewayAPI/rest?method=SendMessage&send_to="+mobile+"&msg="+msg+"&msg_type=Data_text&userid=2000183757&auth_scheme=plain&password=NnheFu&v=1.1&format=text";

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		// optional default is GET
		con.setRequestMethod("GET");
		int responseCode = con.getResponseCode();
		System.out.println("\nSending 'GET' request to URL : " + url);
		System.out.println("Response Code : " + responseCode);

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();
		while ((inputLine = in.readLine()) != null) 
		{
		 response.append(inputLine);
		}
		in.close();
		System.out.println("Response "+response.toString());

		}catch(Exception e)
		{
			System.out.println("Exception while calling gupshub API "+e);
		}
		
	}
	
	private void sendMediaMsgToGupsHub() throws Exception {

		try {
		
		String url ="https://unify.smsgupshup.com/WhatsApp/apis/getMedia.php?userid=2000183757&password=NnheFu&mediaid=08411e7d-94ed-4914-be4d-e0f75d69afac";

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		// optional default is GET
		con.setRequestMethod("GET");
		int responseCode = con.getResponseCode();
		System.out.println("\nSending 'GET' request to URL : " + url);
		System.out.println("Response Code : " + responseCode);

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();
		while ((inputLine = in.readLine()) != null) 
		{
		 response.append(inputLine);
		}
		in.close();
		System.out.println("Media Response "+response.toString());

		}catch(Exception e)
		{
		 System.out.println("Exception while calling gupshub API "+e);
		}
		
	}
	
}
