package com.qc.button;
public class InnerData 
{
	private Facebook facebook;
	public InnerData() {
		super();
	}

	public InnerData(Facebook facebook) {
		super();
		this.facebook = facebook;
	}

	public Facebook getFacebook() {
		return facebook;
	}

	public void setFacebook(Facebook facebook) {
		this.facebook = facebook;
	}
}