package com.qc.common;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.UUID;

import javax.net.ssl.HttpsURLConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class DedupeValidation 
{
	private static Logger logger = LogManager.getLogger(DedupeValidation.class);
	public String deDupeAPI(String Pan, String Aadhar, String Dob)
	{
		/*String finalString="";
		try{
			DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); 
			Date date = (Date)formatter.parse(Dob);
			SimpleDateFormat newFormat = new SimpleDateFormat("dd-MM-yyyy");
			finalString = newFormat.format(date);
		}catch(Exception ex)
		{
			System.out.println("Error Occoured in Date parse");
		}*/
		//System.out.println("Pan "+ Pan);
		//System.out.println("Aadhar "+ Aadhar);
		//System.out.println("Dob "+ Dob);
		String  DevMode = "N";
		StringBuilder result = new StringBuilder();
		String output = new String();
		ResourceBundle res = ResourceBundle.getBundle("com.qc.bot.resources.application");
		HttpURLConnection conn = null;

		try {
			logger.info("Inside Dedupe API");
			XTrustProvider trustProvider = new XTrustProvider();
			trustProvider.install();
			String serviceurl = res.getString("deDupe");
			URL url = new URL(serviceurl);
			if(DevMode!=null && !"".equalsIgnoreCase(DevMode) && "Y".equalsIgnoreCase(DevMode))
			{
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}else{
				conn = (HttpURLConnection) url.openConnection();
			}
			UUID uniqueId = UUID.randomUUID();
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("soaCorrelationId", "19a69722-9c2e-11e7-abc4-cec278b6b50a");
			conn.setRequestProperty("soaAppId", "AGENTBOT");
			if(!"".equalsIgnoreCase(Pan) && Pan!=null)
			{
				conn.setRequestProperty("panNumber", Pan.toUpperCase());
			}
			else
			{
				conn.setRequestProperty("aadhaarNumber", Aadhar);
			}
			conn.setRequestProperty("dob", Dob);
			logger.info("START External API Call : JavaProcedureService");
			int apiResponseCode = conn.getResponseCode();

			if(apiResponseCode == 200)
			{
				logger.info("Response Code Dedupe API == 200 ");
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
			}
			else
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}
				conn.disconnect();
				br.close();
			}
		}
		catch(Exception e)
		{
			logger.info("Exception Occoured in Dedupe third Call :: "+e);
		}
		logger.info("OutSide Dedupe API");
		logger.info(result.toString());
		return result.toString();

	}
}
