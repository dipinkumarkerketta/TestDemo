package com.qc.controller;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.qc.api.response.WebhookResponse;
import com.qc.button.Facebook;
import com.qc.button.InnerButton;
import com.qc.button.InnerData;
import com.qc.common.Adoptionlogs;
import com.qc.common.DedupeValidation;
import com.qc.common.KYCValidation;
import com.qc.common.ReplacementSale;
import com.qc.common.SSOValidation;



@RestController
public class AgentBotController 
{
	private static Logger logger = LogManager.getLogger(AgentBotController.class);
	public static Map<String, Map<String, String>> parentMap = new ConcurrentHashMap<String, Map<String, String>>();
	public static Map<String,String> childMap = new ConcurrentHashMap<String ,String>();

	@Autowired private SSOValidation ssoValidation;
	@Autowired private DedupeValidation ssoJavaValidation;
	@Autowired private KYCValidation kycValidation;
	@Autowired private ReplacementSale replacementSale;
	@Autowired private Adoptionlogs adoption;
	@RequestMapping(value = "/webhook", method = RequestMethod.POST, consumes = { "application/json" }, produces = {"application/json" })
	public @ResponseBody WebhookResponse webhook(@RequestBody String obj) 
	{
		logger.info("CameInside :- Controller: Webhook");
		logger.info("Skill :- Object Json from OutSide"+obj.toString());
		String speech = "";
		String ssoId = ""; 
		String password="";
		String dob="";
		String clientId="", pan="", aadhar="", clientName="", sessionId="", panNo="";
		String serviceResponse=""; String loginStatus=""; String loginInfo="";
		String policyId=""; String issueEffectiveDate="";
		String statusDescription=""; String baseCoverageStatusEffectiveDate="";
		String aadhaar="";
		String replacementsale="";
		String kycRequired="", resolvedQuery="";
		StringBuffer bufferappend = new StringBuffer();
		JSONArray array=null;
		InnerData innerData= new InnerData();
		List<InnerButton> innerbuttonlist = new ArrayList<InnerButton>();
		Facebook fb = new Facebook();
		try {
			System.out.println("");
			logger.info("MliBotController :: STARTS ::");
			JSONObject object = new JSONObject(obj);

			String actionperformed = object.getJSONObject("result").get("action")+"";
			try{
				resolvedQuery = object.getJSONObject("result").get("resolvedQuery")+"";
			}
			catch(Exception ex)
			{
				resolvedQuery="";
			}
			sessionId = object.get("sessionId") + "";
			switch(actionperformed)
			{
			case "input.search":
			{
				if(parentMap.containsKey(sessionId))
				{
					speech="Please select one of the below options to search existing customer details.";
					InnerButton innerButton1 = new InnerButton();
					innerButton1.setText("PAN & DOB");
					innerButton1.setPostback("pannumber");
					InnerButton innerButton2 = new InnerButton();
					innerButton2.setText("Aadhaar & DOB"); 
					innerButton2.setPostback("AadharandDob");
					innerbuttonlist.add(innerButton1); 
					innerbuttonlist.add(innerButton2);
					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
				}
				else 
				{
					speech="Sorry! I will need your SSO credentials for verification before proceed ing further.";	
				}
			}
			break;
			case "input.exit":
			{
				if(parentMap.containsKey(sessionId))
				{
					parentMap.remove(sessionId);
					speech="Thank You! ";
				}
				else 
				{
					speech="Sorry! I will need your SSO credentials for verification before proceed ing further.";	
				}
			}
			break;
			case "intent.welcome":
			{
				speech="Hello. I am your Max Life Assistant. "
						+ "\n I can help you with customer's address proof, DOB proof and replacement sale requirement. "
						+ "Please enter your SSO ID for authentication.";

			}
			break;
			case "sso.validation":
			{
				//System.out.println("Inside :- sso.validation");
				logger.info("Inside SSO.Validation Method :START");
				try{
					ssoId = object.getJSONObject("result").getJSONObject("parameters").get("userId")+ "";
				}catch(Exception ex)
				{
					ssoId="";
				}
				if(!"".equalsIgnoreCase(ssoId))
				{
					childMap.put(sessionId+"ssoid", ssoId);
					parentMap.put(sessionId, childMap);
					speech="Please Enter your SSO password";

				}
				else{
					speech="Sorry! I will need your SSO credentials for verification before proceeding further.";	
				}
				logger.info("Speech :- "+speech);

			}
			break;
			case "input.password":
			{
				if(parentMap.containsKey(sessionId))
				{
					logger.info("Inside :- input.password");
					try{
						password = object.getJSONObject("result").getJSONObject("parameters").get("password")+ "";
						//System.out.println("Password--"+password);
					}catch(Exception ex)
					{
						password="";
						//System.out.println("Password--"+password);
					}

					if(!"".equalsIgnoreCase(password))
					{
						logger.info("Inside---password");
						childMap.put(sessionId+"password", password);
						parentMap.put(sessionId, childMap);
						String ssoId_1 = parentMap.get(sessionId).get(sessionId+"ssoid");
						String pass_1 =  parentMap.get(sessionId).get(sessionId+"password");
						serviceResponse=ssoValidation.SSOCall(ssoId_1,pass_1);
						object = new JSONObject(serviceResponse);
						try{
							loginStatus=object.getJSONObject("response").getJSONObject("responseData").getString("loginStatus");
							logger.info("LoginStatus -- "+loginStatus);
						}catch(Exception ex)
						{
							loginStatus="";
							logger.info("Exception while getting login status :: "+ex);
							logger.info("LoginStatus -- "+loginStatus);
						}
						try{
							loginInfo=object.getJSONObject("response").getJSONObject("responseData").getString("loginInfo");
						}catch(Exception ex)
						{
							loginInfo="";
						}
						if(loginStatus.equalsIgnoreCase("SUCCESS"))
						{
							logger.info("Login Status :- Success");
							speech="Please select one of the below options to search existing customer details.";
							InnerButton innerButton1 = new InnerButton();
							innerButton1.setText("PAN & DOB");
							innerButton1.setPostback("pannumber");
							InnerButton innerButton2 = new InnerButton();
							innerButton2.setText("Aadhaar & DOB"); 
							innerButton2.setPostback("AadharandDob");
							innerbuttonlist.add(innerButton1); 
							innerbuttonlist.add(innerButton2);
							fb.setButtons(innerbuttonlist);
							fb.setTitle("MLIChatBot");
							fb.setPlatform("API.AI");
							fb.setType("Chatbot");
							fb.setImageUrl("BOT");
							innerData.setFacebook(fb);
						}
						else
						{
							speech= "Sorry! The entered SSO credentials do not match our records. Please enter your SSO ID.";
							parentMap.remove(sessionId);
						}
					}
					else{
						speech="Sorry! I will need your SSO credentials for verification before proceed ing further.------";	
					}
				}
				else
				{
					speech="Sorry! I will need your SSO credentials for verification before proceed ing further.********";	
				}
				logger.info("Speech :- "+speech);
			}
			break;
			case "input.pan":
			{
				if(parentMap.containsKey(sessionId))
				{
					logger.info("Inside :- input.pan");
					speech="Please enter customer's PAN & submit. If not available, Please search using Aadhaar number.";
					InnerButton innerButton1 = new InnerButton();
					innerButton1.setText("Aadhaar & DOB"); 
					innerButton1.setPostback("AadharandDob");
					innerbuttonlist.add(innerButton1);
					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
				}
				else 
				{
					speech="Sorry! I will need your SSO credentials for verification before proceed ing further.";	
				}
				logger.info("Speech :- "+speech);
			}
			break;
			case "input.aadhaar":
			{
				if(parentMap.containsKey(sessionId))
				{
					logger.info("Inside :- input.aadhaar");
					speech="Please enter customer's Aadhaar number & submit. If not available, Please search using PAN";
					InnerButton innerButton1 = new InnerButton();
					innerButton1.setText("PAN & DOB");
					innerButton1.setPostback("pannumber");
					innerbuttonlist.add(innerButton1);
					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
				}
				else 
				{
					speech="Sorry! I will need your SSO credentials for verification before proceed ing further.";	
				}
				logger.info("Speech :- "+speech);
			}
			break;
			case "pan.validation":
			{
				if(parentMap.containsKey(sessionId))
				{
					logger.info("Inside :- pan.validation");
					try{
						panNo=object.getJSONObject("result").getJSONObject("parameters").getString("pan");
					}catch(Exception ex)
					{
						panNo="";
					}
					if(!"".equalsIgnoreCase(panNo))
					{
						childMap.put(sessionId+"panNo", panNo);
						parentMap.put(sessionId, childMap);
						speech="Please enter customer's DOB in the format DD-MM-YYYY";
					}
				}
				else
				{
					speech="Sorry! I will need your SSO credentials for verification before proceed ing further.";	
				}
				logger.info("Speech :- "+speech);
			}
			break;
			case "aadhar.validation":
			{
				if(parentMap.containsKey(sessionId))
				{
					logger.info("Inside :- aadhar.validation");
					try{
						aadhar=object.getJSONObject("result").getJSONObject("parameters").getString("aadhar");
					}catch(Exception ex)
					{
						aadhar="";
					}
					try{
						String clientPAN=parentMap.get(sessionId).get(sessionId+"panNo");
						if(!"".equalsIgnoreCase(clientPAN) && clientPAN!=null)
						{
							childMap.put(sessionId+"panNo", "");
							parentMap.put(sessionId, childMap);
						}
					}
					catch(Exception ex)
					{
						childMap.put(sessionId+"panNo", "");
						parentMap.put(sessionId, childMap);
					}
					if(!"".equalsIgnoreCase(aadhar))
					{
						childMap.put(sessionId+"aadhar", aadhar);
						parentMap.put(sessionId, childMap);
						speech="Please enter customer's DOB in the format DD-MM-YYYY";
					}
				}
				else
				{
					speech="Sorry! I will need your SSO credentials for verification before proceed ing further.";	
				}

			}
			break;
			case "dobValidation":
			{
				if(parentMap.containsKey(sessionId))
				{
					try
					{
						logger.info("Inside :- dobValidation");
						try{
							dob=object.getJSONObject("result").getJSONObject("parameters").getString("dob");
							childMap.put(sessionId+"dob", dob);
							parentMap.put(sessionId, childMap);
						}catch(Exception ex)
						{
							dob="";
						}
						if(dob!=null && !"".equalsIgnoreCase(dob))
						{
							String clientDOB=parentMap.get(sessionId).get(sessionId+"dob");
							String clientPAN=parentMap.get(sessionId).get(sessionId+"panNo");
							String clientAadhar=parentMap.get(sessionId).get(sessionId+"aadhar");
							logger.info("DOB Captured---"+clientDOB);
							serviceResponse=ssoJavaValidation.deDupeAPI(clientPAN,clientAadhar,clientDOB);
							object = new JSONObject(serviceResponse);
							if(object!=null && !"".equals(object))
							{
								String msgDescription=object.getJSONObject("response").getJSONObject("msgInfo").get("msgDescription")+"";
								if(!"No client ID exist".equalsIgnoreCase(msgDescription))
								{
									array=object.getJSONObject("response").getJSONObject("payload").getJSONArray("policyDetails");

									for(int i=0;i<1;i++)
									{
										clientId =  array.getJSONObject(i).get("clientId")+"";
										if(!"".equalsIgnoreCase(clientId) && clientId!=null)
										{
											childMap.put(sessionId+"cliendId", clientId);
											parentMap.put(sessionId, childMap);
										}else
										{
											childMap.put(sessionId+"cliendId", "");
											parentMap.put(sessionId, childMap);
										}
										clientName =  array.getJSONObject(i).get("clientName")+"";
										if(!"".equalsIgnoreCase(clientName) && clientName!=null)
										{
											childMap.put(sessionId+"clientName", clientName);
											parentMap.put(sessionId, childMap);

										}else
										{
											childMap.put(sessionId+"clientName", clientName);
											parentMap.put(sessionId, childMap);
										}
									}
									if("".equalsIgnoreCase(clientId) && "".equalsIgnoreCase(clientName) || clientId==null && clientName==null )
									{
										speech="Sorry! I could not find any customer matching the search criteria. \n Please select one of the below options to search existing customer details.";
										InnerButton innerButton1 = new InnerButton();
										innerButton1.setText("PAN & DOB");
										innerButton1.setPostback("pannumber");
										InnerButton innerButton2 = new InnerButton();
										innerButton2.setText("Aadhaar & DOB"); 
										innerButton2.setPostback("AadharandDob");
										innerbuttonlist.add(innerButton1); 
										innerbuttonlist.add(innerButton2);
										fb.setButtons(innerbuttonlist);
										fb.setTitle("MLIChatBot");
										fb.setPlatform("API.AI");
										fb.setType("Chatbot");
										fb.setImageUrl("BOT");
										innerData.setFacebook(fb);
									}else
									{
										speech="Congratulations! We found a match in our records. "+clientName+" is an existing customer. "
												+ "Please select one of the following options.";
										InnerButton innerButton1 = new InnerButton();
										innerButton1.setText("Address & DOB Proof Requirement");
										innerButton1.setPostback("KYCRequirement");
										InnerButton innerButton2 = new InnerButton();
										innerButton2.setText("Replacement Sale Identier"); 
										innerButton2.setPostback("ReplacementSaleIdentier");
										innerbuttonlist.add(innerButton1); 
										innerbuttonlist.add(innerButton2);
										fb.setButtons(innerbuttonlist);
										fb.setTitle("MLIChatBot");
										fb.setPlatform("API.AI");
										fb.setType("Chatbot");
										fb.setImageUrl("BOT");
										innerData.setFacebook(fb);
									}
								}else
								{
									speech="Sorry! I could not find any customer matching the search criteria.";
									speech=speech+"\n Please select one of the below options to search existing customer details.";
									InnerButton innerButton1 = new InnerButton();
									innerButton1.setText("PAN & DOB");
									innerButton1.setPostback("pannumber");
									InnerButton innerButton2 = new InnerButton();
									innerButton2.setText("Aadhaar & DOB"); 
									innerButton2.setPostback("AadharandDob");
									innerbuttonlist.add(innerButton1); 
									innerbuttonlist.add(innerButton2);
									fb.setButtons(innerbuttonlist);
									fb.setTitle("MLIChatBot");
									fb.setPlatform("API.AI");
									fb.setType("Chatbot");
									fb.setImageUrl("BOT");
									innerData.setFacebook(fb);
								}
							}
							else
							{
								speech="There is some communication glitch in DeDupe API, Please try after some time";
							}
						}else
						{
							speech= "Sorry! I will need customer's DOB in oder to search customer's details.";
						}
					}
					catch(Exception ex)
					{
						speech="There seems to be some communication glitch, please try again";
						speech=speech+"\n Please select one of the below options to search existing customer details.";
						InnerButton innerButton1 = new InnerButton();
						innerButton1.setText("PAN & DOB");
						innerButton1.setPostback("pannumber");
						InnerButton innerButton2 = new InnerButton();
						innerButton2.setText("Aadhaar & DOB"); 
						innerButton2.setPostback("AadharandDob");
						innerbuttonlist.add(innerButton1); 
						innerbuttonlist.add(innerButton2);
						fb.setButtons(innerbuttonlist);
						fb.setTitle("MLIChatBot");
						fb.setPlatform("API.AI");
						fb.setType("Chatbot");
						fb.setImageUrl("BOT");
						innerData.setFacebook(fb);
					}
				}else
				{
					speech="Sorry! I will need your SSO credentials for verification before proceed ing further.";
				}
			}
			break;
			case "Client-DOB.Client-DOB-no":
			{
				if(parentMap.containsKey(sessionId))
				{
					speech=" Sorry! I will need customer's DOB in oder to search customer's details.";
				}
				else
				{
					speech="Sorry! I will need your SSO credentials for verification before proceed ing further.";
				}
			}
			break;
			case "input.KYC":
			{
				if(parentMap.containsKey(sessionId))
				{
					String custClientId = parentMap.get(sessionId).get(sessionId+"cliendId");
					String custClientName = parentMap.get(sessionId).get(sessionId+"clientName");
					String response=kycValidation.kycValidationCall(custClientId);
					logger.info("input.KyC - Respones comes form backend Service"+response);
					if(response!=null && !"".equalsIgnoreCase(response))
					{
						JSONObject kyc = new JSONObject(response);
						try
						{
							kycRequired = kyc.getJSONObject("response").getJSONObject("responseData").get("kycRequired")+"";
							if(!"N".equalsIgnoreCase(kycRequired))
							{
								speech="Latest Address & DOB proofs should be collected from the customer. "+custClientName+" is not the policy "
										+ "holder of any policy Issued after April 2010."
										+ "\n\n I can further help you with following options.";
							}else
							{
								array=kyc.getJSONObject("response").getJSONObject("responseData").getJSONArray("policyDetails");
								for(int i=0;i<array.length();i++)
								{
									policyId =  array.getJSONObject(i).get("policyId")+"";
									issueEffectiveDate =  array.getJSONObject(i).get("issueEffectiveDate")+"";

									bufferappend.append("Policy Id:- "+policyId.trim()+", issued on "+issueEffectiveDate+"\n");
								}
								speech= custClientName+" holds the following policies Issued after April 2010. \n";

								speech=speech+bufferappend.toString();
								speech=speech+"\n Address & DOB proof of "+custClientName+" is not required if there is no change in the current Proposal form."
										+ " To avail Address & DOB proof waiver, please initiate mApp journey using Pre-populate application form by using existing "
										+ "policy option and upload the KYC waiver format in document upload page under Address proof & DOB proof."
										+ "\n\n I can further help you with following options:";
							}
						}catch(Exception ex)
						{
							speech="Please provide valid Information for further process.";
						}
						InnerButton innerButton1 = new InnerButton();
						innerButton1.setText("Replacement Sale Identifier"); 
						innerButton1.setPostback("replacement");
						InnerButton innerButton2 = new InnerButton();
						innerButton2.setText("Search Other Customers"); 
						innerButton2.setPostback("Search");
						innerbuttonlist.add(innerButton1); 
						innerbuttonlist.add(innerButton2);
						fb.setButtons(innerbuttonlist);
						fb.setTitle("MLIChatBot");
						fb.setPlatform("API.AI");
						fb.setType("Chatbot");
						fb.setImageUrl("BOT");
						innerData.setFacebook(fb);
					}else
					{
						speech="There is some communication glitch. Please try after some time or connect to the concern team.";
					}

				}else
				{
					speech="Sorry! I will need your SSO credentials for verification before proceed ing further.";
				}
			}
			break;
			case "input.ReplacementSale":
			{
				if(parentMap.containsKey(sessionId))
				{
					String custClientId = parentMap.get(sessionId).get(sessionId+"cliendId");
					String custClientName = parentMap.get(sessionId).get(sessionId+"clientName");
					String response=replacementSale.replacementSaleCall(custClientId);
					JSONObject replacement = new JSONObject(response);
					try{
						replacementsale = replacement.getJSONObject("response").getJSONObject("responseData").get("replacementSaleIndicator")+"";
					}catch(Exception ex)
					{
						replacementsale="";
					}
					if(!"Y".equalsIgnoreCase(replacementsale))
					{
						speech="Replacement letter is not required. "+custClientName+" is not the life insured in any policy which ascertain replacement sale.";

					}else
					{
						array=replacement.getJSONObject("response").getJSONObject("responseData").getJSONArray("policyDetails");
						for(int i=0;i<array.length();i++)
						{

							policyId =  array.getJSONObject(i).get("policyId")+"";
							/*statusDescription =  array.getJSONObject(i).get("statusDescription")+"";*/
							baseCoverageStatusEffectiveDate =  array.getJSONObject(i).get("baseCoverageStatusEffectiveDate")+"";

								bufferappend.append("Policy Id:- "+policyId.trim()+", premium payment discontinued since "+baseCoverageStatusEffectiveDate+"\n");
						}
						speech=" Customer signed replacement consent letter is required. "+custClientName+" is the policy holder of following policies:\n";
						speech=speech+bufferappend.toString()+"\n Please upload customer signed replacement consent letter under Fact Finder "
								+ "tile in mApp for all channels except AXIS. For AXIS, it needs to be uploaded under Ezpay tile while applying "
								+ "for replacement sale";
					}
					speech=speech+"\n\n I can further help you with following options:";
					InnerButton innerButton1 = new InnerButton();
					innerButton1.setText("Address & DOB Proof Requirement");
					innerButton1.setPostback("kyc");
					InnerButton innerButton2 = new InnerButton();
					innerButton2.setText("Search Other Customers"); 
					innerButton2.setPostback("Search");
					innerbuttonlist.add(innerButton1); 
					innerbuttonlist.add(innerButton2);
					fb.setButtons(innerbuttonlist);
					fb.setTitle("MLIChatBot");
					fb.setPlatform("API.AI");
					fb.setType("Chatbot");
					fb.setImageUrl("BOT");
					innerData.setFacebook(fb);
				}else
				{
					speech="Sorry! I will need your SSO credentials for verification before proceed ing further.";
				}
			}
			break;
			default :
			}
			// Adoption logs--------------------------------
			String dbSessionId = sessionId, dbSSOId = ssoId, dbActionPerformed=actionperformed;
			String dbResolvedQuery = resolvedQuery, dbSpeech=speech;
			try{
				Thread t1=new Thread(new Runnable() 
				{
					public void run() 
					{
						logger.info("Run Method Start");
						String status=adoption.adoptionlogsCall(dbSessionId, dbSSOId, dbActionPerformed,
								dbResolvedQuery,dbSpeech);
						logger.info("adoption log status :: "+ status);
					}
				});
				t1.start();
				t1.join();
				logger.info("Run Method END");
			}catch(Exception ex)
			{
				logger.info("Excption Occoured while saving data in to the database :: "+ex);
			}
		}
		catch(Exception e)
		{
			logger.info("Exception ocoured in Agent Bot -- Outer Catch"+e);
		}
		WebhookResponse responseObj = new WebhookResponse(speech, speech,innerData);
		return responseObj;
	}
}
