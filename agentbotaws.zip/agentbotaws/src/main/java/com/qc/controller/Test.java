package com.qc.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Test 
{

	
	public static void main(String arr[])
	{
		String text = "31-12-2015";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

		try {
		    LocalDate date = formatter.parse(text, LocalDate::from);
		    System.out.println("Date Captured in valid format");
		} catch (DateTimeParseException e) {
		    System.out.println("Date should be entered in the format of DD-MM-YYYY"+e);
		}
		
	}
}
