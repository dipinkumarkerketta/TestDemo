package com.mli.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Transient;

@Entity
public class PolicyDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String policyNo;
	private String fileName;
	private String filePath;
	private String rowNum;

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getRowNum() {
		return rowNum;
	}

	public void setRowNum(String rowNum) {
		this.rowNum = rowNum;
	}

	@Transient
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@Override
	public String toString() {
		return "PolicyDetails [policyNo=" + policyNo + ", fileName=" + fileName + ", filePath=" + filePath + ", rowNum=" + rowNum + ", id=" + id + "]";
	}

}
