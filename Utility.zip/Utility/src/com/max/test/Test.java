package com.max.test;

public class Test {
	
	public static void main(String[] args) {
		int x = 5;
		for(int i=0;i<=x;i++){
			System.out.println(i);
			if(i==x){
				i=0;
				continue;
				
			}
		}
	}

}
