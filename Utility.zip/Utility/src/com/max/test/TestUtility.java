package com.max.test;

import com.max.utility.action.GetFileFromDirectory;

public class TestUtility {
	
	public static void main(String[] args) {
		System.out.println("UtilityStarted");
		GetFileFromDirectory g1 = new GetFileFromDirectory();
		g1.getFilesAndFilesSubDirectories("D://Testing");
		System.out.println("UtilityFinished");
	}

}
