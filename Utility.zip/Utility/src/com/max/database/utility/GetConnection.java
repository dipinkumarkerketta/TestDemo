package com.max.database.utility;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class GetConnection {
	static Session session = null;
	public static Session getSession(){
		
		try{
			Configuration cfg = new Configuration();
			cfg.configure("hibernate.cfg.xml");
			SessionFactory sessionFactory = cfg.buildSessionFactory();
			if(session == null){
			session = sessionFactory.openSession();
			}
		}
		catch(Exception ex){
			
			if(session != null){
				session.close();
			}
			System.out.println(ex);
			
		}
		return session;
	}

}
