package com.max.utility.action;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;

import com.max.dao.InsertData;
import com.max.dao.imp.InsertDataImpl;
import com.mli.entity.PolicyDetails;

public class GetFileFromDirectory extends ReadingFile {

	static Logger logger = Logger.getLogger(GetFileFromDirectory.class.getName());
	ReadingFile readingFile = new ReadingFile();
	@SuppressWarnings("rawtypes")
	public void getFilesAndFilesSubDirectories(String directoryName) {
		logger.info("Reading file from directory start :: " + directoryName);
		try{
		File directory = new File(directoryName);
		List<String> files = new ArrayList<>();
		List<Callable<List<Object[]>>> callables = new ArrayList<>();
		String fileExtension = null;
		List<Path> filesName = Files.walk(Paths.get(directoryName)).filter(Files::isRegularFile).collect(Collectors.toList());
		for(Path path : filesName ){
			fileExtension = getFileExtension(path.toString());
			if(fileExtension.equalsIgnoreCase("xls") || fileExtension.equalsIgnoreCase("xlsx") || fileExtension.equalsIgnoreCase("csv") ){
				if(!path.toString().contains("~")){
					files.add(path.toString());
					System.out.println("File found :: " +path.toString());
				}	
			}
		}	
		System.out.println("Total file :: "+files.size() );
		int i = 1;
		for(String fileName : files){
			System.out.println("Thread :: " +i++);
			Callable callable = new Callable() {
				List<PolicyDetails> policyDetailsList = null;
				@Override
				public String call() throws Exception {
					String flag = "true";
					policyDetailsList = readingFile.readingFile(fileName);
					InsertData insertData = new InsertDataImpl();
					if(policyDetailsList != null){
						insertData.insertExcelData(policyDetailsList);
						System.out.println("File processing done for :: "+fileName);
					}
					
					return flag;
				}	
			};
			callables.add(callable);		
		}
		
		ExecutorService execService = Executors.newFixedThreadPool(100);
		try {
			long beforeTime = System.currentTimeMillis();
			System.out.println("All Thread Stared");
			execService.invokeAll(callables);
			System.out.println("Time taken in minutes :: " +(TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis()-beforeTime)));
			System.out.println("All Thread End");
			execService.shutdown();		
//			if (execService.awaitTermination(10, TimeUnit.SECONDS)) {
//				logger.info("All threads done with their jobs");
//			}
			logger.info("All threads done with their jobs with size ::");

		} catch (Exception e) {
			logger.error("some error occures in calling executor services ::" + e);
		}
		}
		catch(Exception ex){
			System.out.println(ex);
		}
		
	}

	public static String getFileExtension(String fileName) {
		logger.info("START FileExtention method  file  name " + fileName);
		String fileExtension = "";
		try {
			int index = fileName.lastIndexOf(".");
			fileExtension = fileName.substring(index + 1, fileName.length());
		} catch (Exception e) {
//			e.printStackTrace();
			logger.debug("Error during to geting file Extention  " + e);
		}
		logger.info("END FileExtention method  file  name " + fileName);
		return fileExtension;
	}
}
