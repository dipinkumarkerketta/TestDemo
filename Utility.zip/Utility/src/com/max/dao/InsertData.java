package com.max.dao;

import java.util.List;

import com.mli.entity.PolicyDetails;

public interface InsertData {
	
	public boolean insertExcelData(List<PolicyDetails> policyDetails);

}
