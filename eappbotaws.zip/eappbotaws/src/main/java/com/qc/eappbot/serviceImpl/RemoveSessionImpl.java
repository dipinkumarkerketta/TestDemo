package com.qc.eappbot.serviceImpl;

import java.util.Map;
import org.springframework.stereotype.Service;
import com.qc.eappbot.service.RemoveSession;

@Service
public class RemoveSessionImpl implements RemoveSession 
{

	@Override
	public void removedSessionIdfromCash(Map<String, Map<String, String>> sessionMapcontainssoinfo) {
				sessionMapcontainssoinfo.clear();
	}
}
