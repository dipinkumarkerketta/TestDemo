package com.qc.eappbot.service;

import java.util.Map;

public interface RemoveSession 
{
	public void removedSessionIdfromCash(Map<String, Map<String, String>> sessionMapcontainssoinfo);

}
