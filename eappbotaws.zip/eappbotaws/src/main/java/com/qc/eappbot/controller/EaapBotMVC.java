package com.qc.eappbot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class EaapBotMVC {
	@RequestMapping("/")
	public String index() {
		return "index";
	}
	
}
