package com.qc.eappbot.service;

import java.util.Map;

public interface EAppService {
	public Map<String, Map<String, String>> APICallSSOValidation(String request);
}
