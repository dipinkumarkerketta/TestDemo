package com.qc.eappbot.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qc.eappbot.buttons.Facebook;
import com.qc.eappbot.buttons.InnerButton;
import com.qc.eappbot.buttons.InnerData;
import com.qc.eappbot.response.WebhookResponse;
import com.qc.eappbot.service.EAppService;
import com.qc.eappbot.service.RemoveSession;

@RestController
@RequestMapping("/webhook")
public class EaapBotController
{

	@Autowired 
	private EAppService eAppService;
	
	@Autowired
	private RemoveSession removeSession;

	private static Logger logger = LogManager.getLogger(EaapBotController.class);
	public static Map<String, Map<String, String>> sessionMapcontainssoinfo = new ConcurrentHashMap<String, Map<String, String>>();

	/*If you want 1:01:am at midnight then set it to*/
	/*@Scheduled(cron = "0 1 1 ? * *")*/
	/*Day 1 Pm
	cron = "0 1 1,13 * * ?"*/
	@Scheduled(cron="0 1 1,18 * * ?")
	/*Every 15 Minute*/
	/*@Scheduled(cron = "0 0/15 * * * ?")*/
	public void schedular() {
		logger.info("Spring Schedular START");
		//System.out.println("---------");
		removeSession.removedSessionIdfromCash(sessionMapcontainssoinfo);
		logger.info("Spring Schedular END");
		//System.out.println("---------++++++++++++++++");
	}

	@RequestMapping(method = RequestMethod.POST)
	public WebhookResponse webhook(@RequestBody String request) 
	{
		logger.info("CAME Inside :: Webhook Controller");
		List<InnerButton> innerbuttonlist = new ArrayList<InnerButton>();
		Facebook fb = new Facebook();
		InnerData innerData= new InnerData();
		InnerButton button=new InnerButton();
		InnerButton button2=new InnerButton();
		InnerButton button3=new InnerButton();

		String  sessionId = "", userOTP = "", speech = "";
		String  ssoId = "";
		String  nbvalidate_source = "", nbvalidateplatform="";

		try {
			logger.info("EAppBotController :: STARTS ::");
			JSONObject object = new JSONObject(request);
			String actionperformed = object.getJSONObject("result").get("action") + "";
			sessionId = object.get("sessionId") + "";
			try {
				userOTP = object.getJSONObject("result").getJSONObject("parameters").get("otp") + "";
			} catch (Exception e) {
				logger.info("Not getting OTP");
			}
			if ("SSO.Validation".equalsIgnoreCase(actionperformed) || "nb.validate".equalsIgnoreCase(actionperformed)) 
			{
				logger.info("Inside SSO.Validation Method :START");
				ssoId = object.getJSONObject("result").get("resolvedQuery")+ "";
				try{
					nbvalidate_source = object.getJSONObject("result").getJSONObject("parameters").get("source")+"";
				}
				catch(Exception ex)
				{nbvalidate_source="";}
				try{
					nbvalidateplatform = object.getJSONObject("result").getJSONObject("parameters").get("platform")+"";
				}
				catch(Exception ex)
				{nbvalidateplatform="";}
				sessionId = object.get("sessionId") + "";
				Map otpsessionMap = sessionMapcontainssoinfo.get(sessionId);
				if (otpsessionMap == null) 
				{
					/*START---------This API Validate SSOID Via SOA API and get the info of the User------------------------------*/
					logger.info("START Calling SSOValidation API SSOID :-"+ssoId+ "Session Id:-"+sessionId);
					Map<String, Map<String, String>> returnmap = eAppService.APICallSSOValidation(request);
					logger.info("END Calling SSOValidation API SSOID :-"+ssoId+ "Session Id:-"+sessionId);
					/*END---------This API Validate SSOID Via SOA API and get the info of the User------------------------------*/

					String SoaStatus = "", mnylstatus = "", PhoneStatus = "", agentName ="",bot1="",bot2="",bot3="";

					Map<String, String> cashMap = returnmap.get(sessionId);
					SoaStatus = cashMap.get("SoaStatus");
					logger.info("SOA STATUS :- "+SoaStatus);
					PhoneStatus = cashMap.get("PhoneStatus")+"";
					logger.info("SOA STATUS :- "+PhoneStatus);
					mnylstatus = cashMap.get("mnylStatus")+"";
					logger.info("SOA STATUS :- "+mnylstatus);
					agentName=cashMap.get("AgentName");
					logger.info("SOA STATUS :- "+agentName);

					bot1=cashMap.get("MISBot");
					bot2=cashMap.get("HRBot");
					bot3=cashMap.get("RABot");

					if ("N".equalsIgnoreCase(mnylstatus)){
						speech = "This UserID Is InActive";
					} else if ("success".equalsIgnoreCase(SoaStatus)) 
					{
						speech = "I need to verify the OTP which was sent on your registered mobile number. Please enter it here "
								+ cashMap.get("otp") + "";

						sessionMapcontainssoinfo.put(sessionId, cashMap);

					} else if ("".equalsIgnoreCase(PhoneStatus) || PhoneStatus==null) {
						speech = "Your PhoneNo. is not registered with us! Please Enter a registered PhoneNo.";
					} else if ("Failure_API_1".equalsIgnoreCase(SoaStatus)|| "Failure_API_2".equalsIgnoreCase("SoaStatus")) 
					{
						logger.info("Problem Occoured In Calling External API's SOA");
						speech = "There is some communication glitch ! Please try after some time !! ";
					}
					else if("partial_content".equalsIgnoreCase(SoaStatus))
					{
						speech = "Hi " + agentName + ", I can help you with following options";
						cashMap.put("Validation", "success");
						cashMap.put("nbvalidatesource", nbvalidate_source);
						cashMap.put("nbvalidateplatform", nbvalidateplatform);
						sessionMapcontainssoinfo.put(sessionId, cashMap);

						// For MISBot
						if(!bot1.equalsIgnoreCase("N"))
						{
							button.setText("Business Numbers");			
							button.setPostback(bot1);
							innerbuttonlist.add(button);
						}

						// For RABot
						if(!bot2.equalsIgnoreCase("N"))
						{
							button2.setText("HrPolicies");					
							button2.setPostback(bot2);
							innerbuttonlist.add(button2);
						}

						// For HRBot
						if(!bot3.equalsIgnoreCase("N"))
						{
							button3.setText("FLS");				
							button3.setPostback(bot3);
							innerbuttonlist.add(button3);
						}
						fb.setButtons(innerbuttonlist);
						fb.setTitle("MLIChatBot");
						fb.setPlatform("API.AI");
						fb.setType("Chatbot");
						fb.setImageUrl("BOT");

						innerData.setFacebook(fb);
					}
					else{
						speech = "Oops! I could not find any registered mobile number for this SSO";
					}
				}
				else 
				{
					if (otpsessionMap.get("validSSOID") != null	&& otpsessionMap.get("validSSOID").toString().equalsIgnoreCase(ssoId)){
						speech = "Already validated";
					}
					if (!otpsessionMap.get("validSSOID").toString().equalsIgnoreCase(ssoId)){
						speech = "You are trying to be login as different user. Please close earlier conversation to proceed";
					}
				}
			}
			else if ("nb.OTP.Validation".equalsIgnoreCase(actionperformed)) 
			{
				logger.info("Action START :- nb.OTP.Validation");
				String AgentName = "", cashOTP = "";
				if (sessionMapcontainssoinfo.containsKey(sessionId)){
					Map<String, String> cashMap = sessionMapcontainssoinfo.get(sessionId);
					String validSSOID = cashMap.get("validSSOID");
					if (cashMap.containsKey(validSSOID + "_VERIFY")){
						speech = "Already validated!";
					} else {
						cashOTP = cashMap.get("otp");
						AgentName = cashMap.get("AgentName");
						if (cashOTP.equalsIgnoreCase(userOTP)){
							speech = "Hi " + AgentName + ", How can i help you today?";
							cashMap.put("Validation", "success");
							cashMap.put(validSSOID + "_VERIFY", cashOTP);
							sessionMapcontainssoinfo.put(sessionId, cashMap);
						} else {
							speech = "Invalid OTP Entered! "
									+ "The OTP you have provided does not match. Please provide valid OTP "
									+ "that has been sent to your registered mobile number.";
						}
					}
				} else {
					speech = "Please Validate SSO Credentials For Further Process";
				}
				logger.info("Action END :- nb.OTP.Validation");
			}
		} catch (Exception e) {
			logger.info(e);
		}
		WebhookResponse response=new WebhookResponse(speech, speech,innerData);
		return response;
	}
}