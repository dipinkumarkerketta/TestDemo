package com.qc.eappbot.serviceImpl;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Random;
import org.springframework.stereotype.Service;
import com.qc.eappbot.service.OTPGenerate;

@Service
public class OTPGenerateImpl implements OTPGenerate {

	private static Logger logger = LogManager.getLogger(OTPGenerateImpl.class);
	public static Map<String, Map<String, String>> sessionMapcontainssoinfo = new ConcurrentHashMap<String, Map<String, String>>();

	@Override
	public Map<String, Map<String, String>> OTPVarification(String sessionId, String phoneno, String agentName,
			String ssoId, String actionperformed,String bot1,String bot2,String bot3) 
	{
		logger.info("OTP VARIFICATION :: METHOD :: INSIDE");
		Map<String, String> otpsession = new HashMap<String, String>();
		try {
			if("nb.validate".equalsIgnoreCase(actionperformed))
			{
				otpsession.put("SoaStatus", "partial_content");
				otpsession.put("validSSOID", ssoId);
				otpsession.put("AgentName", agentName);
				otpsession.put("MISBot", bot1);
				otpsession.put("HRBot", bot2);
				otpsession.put("RABot", bot3);

				sessionMapcontainssoinfo.put(sessionId, otpsession);
			}
			else
			{
				otpsession.put("SoaStatus", "Failure_API_2");
				sessionMapcontainssoinfo.put(sessionId, otpsession);
				logger.info("Exception Occoured while calling OTP Varification API Call");
			}	
		}	
		catch (Exception ex) 
		{
			logger.info(ex);
			otpsession.put("SoaStatus", "Failure_API_2");
			sessionMapcontainssoinfo.put(sessionId, otpsession);
			logger.info("Exception Occoured while calling OTP Varification API Call");
		}
		logger.info("OTP VARIFICATION :: METHOD :: OUTSIDE");
		return sessionMapcontainssoinfo;
	}
	public static String randomNumber() {
		StringBuffer bf = new StringBuffer();
		for (int i = 0; i < 6; i++) {
			bf = bf.append(getRandomNumberInRange(1, 9));
		}
		return bf.toString();
	}
	public static int getRandomNumberInRange(int min, int max) {

		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}
		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}
}
