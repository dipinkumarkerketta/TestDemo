package com.qc.jsonImpl;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TreeMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Service;


@Service
public class MailReportJson {
	
	private static Logger logger = LogManager.getLogger(MailReportJson.class);
	public Map<String, Object[]> getMailReportData(String sessionId, JSONObject obj){
		
		ResourceBundle res = ResourceBundle.getBundle("com.qc.bot.resources.application");
		Map<String, Object[]> map = null;
		JSONArray dataToDumpInExcel = null;
		
		 XSSFWorkbook workbook = new XSSFWorkbook();
	      
	      //Create a blank sheet
	      XSSFSheet spreadsheet = workbook.createSheet( " Sheet ");

	      //Create row object
	      XSSFRow row;
		
		try {
			 dataToDumpInExcel = obj.getJSONObject("payload").getJSONArray("mailReportDataPayloadRes");
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		try{
			map = new TreeMap<String, Object[]>();
			map.put("0", new Object[] {"Agent Id","Agent Name","Join Date","Status","Role","Segment","Reporting to ID",
					"Reporting to Name","Reporting to Role","Appointd by ID","Appointd by Name","Appointed By Role","GO",
					"GO_Name","Class","Zone","SMID","SM_Name","APID","PID","OHID","OH_Name","RM","RM_ID","ZVP","ZVP_ID",
					"Vintage","Vintage as Since Joining","Current Star Level","Paid Cases MTD"," Adj Mfyp (Rs.) MTD",
					" WGT_MFYP_MTD (Rs.) MTD"," FYC without Segment Bonus (Rs.) MTD"," Growth % MTD"," Paid Cases YTD"," Adj Mfyp (Rs.) YTD"
					,"WGT_MFYP_(Rs.) YTD"," FYC without Segment Bonus (Rs.) YTD"," Growth % YTD"," No. of Policies - Applied",
					" WGT_MFYP_MTD (Rs.) Applied"," Adj IFYP (Rs.) MTD Applied"," Early_Success_Cases "," Early_Success_FYC ",
					" Early_Success_Cases_Shortfall "," Early_Success_FYC_Shortfalll "," Final_Early_Success "
					," FYC_Actual MTD"," FYC_Target MTD"," Short In FYC MTD","Proactive Manmonths MTD/YTD"," Status MTD"," FYC_Actual YTD",
					" FYC_Target YTD"," Short In FYC YTD"," Status YTD"," Paid_Cs_YTD "," Short in Paid Case "," Manmonth ",
					"Last Active Date (Jan 2018 Onwards)"," YTD Active Status "," MTD Active Status "," QR FYC ",
					" Shortfall_QR_FYC "," Qualifying Month "," Paid Case (0-3 Month)"," FYC (Rs.) (0-3 Month)"," Short in Paid Case for 9 in 90",
					" Short in FYC (Rs.) for 9 in 90"," Qualifying Month 9 in 90"," Status (Career Agent Scheme)","FYC_Q1","FYC_Q2","FYC_Q3","FYC_Q4",
					"Source of Applicant","Protection Cases MTD","Protection Adj MFYP (in Rs) MTD","Protection WFYP (in Rs) MTD","Protection Cases YTD",
					"Protection Adj MFYP (in Rs) YTD","Protection WFYP (in Rs) YTD","Collectible (Rs.)","Collected (Rs.)","13M Persistency"});
			
			if(dataToDumpInExcel!= null)
			{
				
				for(int i=0; i<=dataToDumpInExcel.length()-1; i++){
					
					List<String> listData = new ArrayList();
					
					
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("agentId")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("agentName")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("agentJoinDate")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("agentStatus")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("role")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("segment")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("reportingToId")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("reportingToName")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("reportingToRole")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("appointdById")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("appointdByName")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("appointdByRole")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("go")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("goName")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("agentClass")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("zone")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("smid")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("smName")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("apid")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("pid")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("ohid")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("ohName")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("rm")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("rmId")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("zvp")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("zvpId")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("activityYtdVintage")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("vintageSinceJoing")));

					try{
						listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("activityYtdStLevel")));
					}
					catch(Exception ex){
						listData.add("");
						logger.error("value of ");
					}
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("paidCasesMtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("adjMfypMtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("weightMfypMtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("fycMtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("mtdGrowthPer")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("ytdPaidCases")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("adjMfypYtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("weightMfypYtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("ytdFycWithoutSgBonus")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("ytdGrowthPer")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("mtdAppliedNops")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("mtdAppliedWfyp")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("aplAdjIfypMtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("earlySuccessCases")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("earlySuccessFyc")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("earlySuccessCasesShortfall")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("earlySuccessFycShortfalll")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("finalEarlySuccess")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("fycActualMtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("fycTargetMtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("shortInFycMtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("proactiveManMonthsMtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("proStatusMtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("fycActualYtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("fycYtdTarget")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("shortInFycYtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("proStatusYtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("paidCsYtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("shortInPaidCase")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("manMonthYtd")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("activityYtdLastActiveDate")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("activityYtdYtdActiveStatus")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("activityYtdMtdActiveStatus")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("qrFyc")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("shortfallQrFyc")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("qrQualifyingMonth")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("paidCase9In90")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("fyc9In90")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("shortInPaidCase9In90")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("shortInFyc9In90")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("nineIn90Month")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("comisionDtlCarerAgtSchmSt")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("fycqtr1")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("fycqtr2")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("fycqtr3")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("fycqtr4")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("sourceOfApplicant")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("mtdProtectionUpdateNop")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("mtdProtectionUpdateAdjMfyp")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("mtdProtectionUpdateWfyp")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("ytdProtectionUpdateNop")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("ytdProtectionUpdateAdjMfyp")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("ytdProtectionUpdateWfyp")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("renewalBusiUpdtCollectible")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("renewalBusiUpdtCollected")));
					listData.add(validateData(dataToDumpInExcel.getJSONObject(i).get("renewalBusiUpdt13mPersis")));

					String[] str=new String[85];
					for(int j=0; j<=listData.size()-1; j++){
						str[j]=listData.get(j);
					}
					
					map.put(Integer.toString(i+1), str );
				}
				
				Set < String > keyid = map.keySet();
			      int rowid = 0;
			      for (String key : keyid) {
				         row = spreadsheet.createRow(rowid++);
				         Object [] objectArr = map.get(key);

				         int cellid = 0;
				         
				         for (Object object : objectArr){
				            Cell cell = row.createCell(cellid++);
				            
				            cell.setCellValue((String) object);
				         }
				      }
			      String fileLocation = res.getString("workingDirectory");
			      
			      FileOutputStream out = new FileOutputStream(
			 	         new File(fileLocation+File.separator+sessionId+".xlsx"));
			 	      
			 	      workbook.write(out);
			 	      out.close();
			 	     logger.info("Excel written successfully :: sessionId :: "+sessionId);
			      
			}
		}
		catch(Exception ex){
			logger.error("Exception in writing data in excel :: "+ex);
		}
		return map;
	}

	private String validateData(Object object) {
		String nullCheck="";
		try{
			if(object != null && !object.toString().isEmpty())
			{
				nullCheck=object.toString();
			}
		}
		catch(Exception ex){
			logger.error("Exception in validating data :: "+ex);
		}
		return nullCheck;
	}

	 
}
