package com.qc.service.messageimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class PolicyStatusDobPan 
{
	@Autowired
	private Bean bean;
	private static Logger logger = LogManager.getLogger(PolicyStatusDobPan.class);
	public String policyStatusDobPanIntent(String customerName)
	{

		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel()) || "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="Dear " +customerName+" the policy status for your policy"+bean.getPolicy_number()
			+ "is "+bean.getPolicy_status_desc();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="Dear " +customerName+" the policy status for your policy"+bean.getPolicy_number()
			+ "is "+bean.getPolicy_status_desc();
		}
		else
		{
			finalresponse="Dear " +customerName+" the policy status for your policy"+bean.getPolicy_number()
			+ "is "+bean.getPolicy_status_desc();
		}
		logger.info("PolicyStatusDobPan --"+finalresponse);
		return finalresponse;
	}

}
