package com.qc.service.messageimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class ReasonWelcomeCallStatus 
{
	private static Logger logger = LogManager.getLogger(ReasonWelcomeCallStatus.class);
	public String reasonWelcomeCallStatusIntent()
	{
		String finalresponse="Sorry we don't have anything yet for this Intent";
		logger.info("ReasonWelcomeCallStatus :: "+finalresponse);
		return finalresponse;
	}
}
