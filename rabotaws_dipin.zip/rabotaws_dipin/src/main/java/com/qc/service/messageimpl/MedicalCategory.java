package com.qc.service.messageimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class MedicalCategory 
{
	@Autowired
	private Bean bean;
	private static Logger logger = LogManager.getLogger(MedicalCategory.class);
	public String medicalCategoryIntent(String policyNumber)
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="Policy "+policyNumber+" falls under "+bean.getPol_med_category();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="Policy "+policyNumber+" falls under "+bean.getPol_med_category();
		}
		else
		{
			finalresponse="Policy "+policyNumber+" falls under "+bean.getPol_med_category();
		}
		//System.out.println("MedicalCategory--"+ finalresponse);
		logger.info("MedicalCategory--"+ finalresponse);
		return finalresponse;
	}
}
