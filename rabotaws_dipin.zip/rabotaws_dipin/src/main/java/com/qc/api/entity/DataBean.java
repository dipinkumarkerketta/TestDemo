package com.qc.api.entity;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DataBean 
{
	/*@Autowired
	public static Bean bean;
*/
	public String getDatafromJsonObject(String splitIntent, JSONObject object, Bean bean)
	{
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		Calendar cal = Calendar.getInstance();
		String finalresponse="true";
		switch(splitIntent)
		{
		case "ADJMFYP":
		{
			try	{
				String timeStamp = object.getJSONObject("payload").getJSONObject("adjMFYP").get("real_TIM_TIMSTAMP")+"";
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setAdj_mfyp_ftd("0.0");
					bean.setAdj_mfyp_mtd("0.0");
					bean.setAdj_mfyp_qtd("0.0");
					bean.setAdj_mfyp_ytd("0.0");
					bean.setREAL_TIM_TIMSTAMP("N/A");

				}else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("adjMFYP").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("adjMFYP").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("adjMFYP").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setAdj_mfyp_ftd(object.getJSONObject("payload").getJSONObject("adjMFYP").get("adj_MFYP_FTD").toString());
					}
					catch(Exception ex)
					{
						bean.setAdj_mfyp_ftd("0.0");
					}
					try	{
						bean.setAdj_mfyp_mtd(object.getJSONObject("payload").getJSONObject("adjMFYP").get("adj_MFYP_MTD").toString());
					}
					catch(Exception ex)	
					{
						bean.setAdj_mfyp_mtd("0.0");
					}
					try	{
						bean.setAdj_mfyp_qtd(object.getJSONObject("payload").getJSONObject("adjMFYP").get("adj_MFYP_QTD").toString());
					}
					catch(Exception ex)	
					{
						bean.setAdj_mfyp_qtd("0.0");
					}
					try	{
						bean.setAdj_mfyp_ytd(object.getJSONObject("payload").getJSONObject("adjMFYP").get("adj_MFYP_YTD").toString());
					}
					catch(Exception ex)	
					{
						bean.setAdj_mfyp_ytd("0.0");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("adjMFYP").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("adjMFYP").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setAdj_mfyp_ftd("0.0");
				bean.setAdj_mfyp_mtd("0.0");
				bean.setAdj_mfyp_qtd("0.0");
				bean.setAdj_mfyp_ytd("0.0");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "PAIDCASES":
		{
			try {
				String timeStamp = object.getJSONObject("payload").getJSONObject("paidcase").get("real_TIM_TIMSTAMP")+"";
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setInforced_ftd("0.0");
					bean.setInforced_mtd("0.0");
					bean.setInforced_qtd("0.0");
					bean.setInforced_ytd("0.0");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("paidcase").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("paidcase").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("paidcase").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setInforced_ftd(object.getJSONObject("payload").getJSONObject("paidcase").get("inforced_FTD").toString());
					}
					catch(Exception ex)
					{
						bean.setInforced_ftd("0.0");
					}
					try	{
						bean.setInforced_mtd(object.getJSONObject("payload").getJSONObject("paidcase").get("inforced_MTD").toString());
					}
					catch(Exception ex)	
					{
						bean.setInforced_mtd("0.0");
					}
					try	{
						bean.setInforced_qtd(object.getJSONObject("payload").getJSONObject("paidcase").get("inforced_QTD").toString());
					}
					catch(Exception ex)	
					{
						bean.setInforced_qtd("0.0");
					}
					try	{
						bean.setInforced_ytd(object.getJSONObject("payload").getJSONObject("paidcase").get("inforced_YTD").toString());
					}
					catch(Exception ex)	
					{
						bean.setInforced_ytd("0.0");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("paidcase").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("paidcase").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setInforced_ftd("0.0");
				bean.setInforced_mtd("0.0");
				bean.setInforced_qtd("0.0");
				bean.setInforced_ytd("0.0");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}		
		break;
		case "WTGMFYP":
		{
			try {
				String timeStamp = object.getJSONObject("payload").getJSONObject("wtgMFYP").get("real_TIM_TIMSTAMP")+"";
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setWtg_mfyp_mtd("0.0");
					bean.setWtg_mfyp_qtd("0.0");
					bean.setWtg_mfyp_ytd("0.0");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setWtg_mfyp_mtd(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("wtg_MFYP_MTD").toString());
					}
					catch(Exception ex)
					{
						bean.setWtg_mfyp_mtd("0.0");
					}
					try	{
						bean.setWtg_mfyp_qtd(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("wtg_MFYP_QTD").toString());
					}
					catch(Exception ex)	
					{
						bean.setWtg_mfyp_qtd("0.0");
					}
					try	{
						bean.setWtg_mfyp_ytd(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("wtg_MFYP_YTD").toString());
					}
					catch(Exception ex)	
					{
						bean.setWtg_mfyp_ytd("0.0");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("wtgMFYP").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setWtg_mfyp_mtd("0.0");
				bean.setWtg_mfyp_qtd("0.0");
				bean.setWtg_mfyp_ytd("0.0");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "POLICYSTATUS":
		{
			try {
				String timeStamp = object.getJSONObject("payload").getJSONObject("policyStatus").get("realTimTimstamp")+"";
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setPolicy_number("N/A");
					bean.setPolicy_status_desc("N/A");
					bean.setPol_due_date("N/A");
					bean.setBTCH_TIMSTAMP("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
					bean.setWorkitemDescription("N/A");
					bean.setPendingRequirement("N/A");
					bean.setTppComment("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("policyStatus").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("policyStatus").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("policyStatus").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("policyStatus").get("policyNumber").toString());
					}
					catch(Exception ex)
					{
						bean.setPolicy_number("N/A");
					}
					try	{
						bean.setPolicy_status_desc(object.getJSONObject("payload").getJSONObject("policyStatus").get("policyStatusDesc")+"");
					}
					catch(Exception ex)	
					{
						bean.setPolicy_status_desc("N/A");
					}
					try	{
						bean.setPol_due_date(object.getJSONObject("payload").getJSONObject("policyStatus").get("polDueDate").toString());
					}
					catch(Exception ex)	
					{
						bean.setPol_due_date("N/A");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyStatus").get("btchTimstamp").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyStatus").get("realTimTimstamp").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
					try	{
						bean.setWorkitemDescription(object.getJSONObject("payload").getJSONObject("policyStatus").get("workitemDescription").toString());
					}
					catch(Exception ex)	
					{
						bean.setWorkitemDescription("N/A");
					}
					try	{
						bean.setPendingRequirement(object.getJSONObject("payload").getJSONObject("policyStatus").get("pendingRequirement").toString());
					}
					catch(Exception ex)	
					{
						bean.setPendingRequirement("N/A");
					}
					try	{
						bean.setTppComment(object.getJSONObject("payload").getJSONObject("policyStatus").get("tppComment").toString());
					}
					catch(Exception ex)	
					{
						bean.setTppComment("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setPolicy_number("N/A");
				bean.setPolicy_status_desc("N/A");
				bean.setPol_due_date("N/A");
				bean.setBTCH_TIMSTAMP("N/A");
				bean.setREAL_TIM_TIMSTAMP("N/A");
				bean.setWorkitemDescription("N/A");
				bean.setPendingRequirement("N/A");
				bean.setTppComment("N/A");
			}
		}
		break;
		case "POLICYSTATUSDOBPAN":
		{  
			try {
				String timeStamp = object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("real_TIM_TIMSTAMP")+"";
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setPolicy_number("N/A");
					bean.setPol_owner_dob("N/A");
					bean.setPol_owner_pan("N/A");
					bean.setPolicy_status_desc("N/A");
					bean.setBTCH_TIMSTAMP("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("policy_NUMBER").toString());
					}
					catch(Exception ex)
					{
						bean.setPolicy_number("N/A");
					}
					try	{
						bean.setPol_owner_dob(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("pol_OWNER_DOB").toString());
					}
					catch(Exception ex)	
					{
						bean.setPol_owner_dob("N/A");
					}
					try	{
						bean.setPol_owner_pan(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("pol_OWNER_PAN").toString());
					}
					catch(Exception ex)
					{
						bean.setPol_owner_pan("N/A");
					}
					try	{
						bean.setPolicy_status_desc(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("policy_STATUS_DESC").toString());
					}
					catch(Exception ex)	
					{
						bean.setPolicy_status_desc("N/A");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyStatusdobpan").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setPolicy_number("N/A");
				bean.setPol_owner_dob("N/A");
				bean.setPol_owner_pan("N/A");
				bean.setPolicy_status_desc("N/A");
				bean.setBTCH_TIMSTAMP("N/A");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "RENEWALPREMIUM":
		{ 
			try {
				String timeStamp = object.getJSONObject("payload").getJSONObject("renewalPremium").get("real_TIM_TIMSTAMP")+"";
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setPolicy_number("N/A");
					bean.setPol_renewal_prm("0.0");
					bean.setBTCH_TIMSTAMP("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("renewalPremium").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("renewalPremium").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("renewalPremium").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("renewalPremium").get("policy_NUMBER").toString());
					}
					catch(Exception ex)
					{
						bean.setPolicy_number("N/A");
					}
					try	{
						bean.setPol_renewal_prm(object.getJSONObject("payload").getJSONObject("renewalPremium").get("pol_RENEWAL_PRM").toString());
					}
					catch(Exception ex)	
					{
						bean.setPol_renewal_prm("0.0");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("renewalPremium").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("renewalPremium").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setPolicy_number("N/A");
				bean.setPol_renewal_prm("0.0");
				bean.setBTCH_TIMSTAMP("N/A");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "PREMIUMDUE":
		{
			try {
				String timeStamp = object.getJSONObject("payload").getJSONObject("premiumDue").get("real_TIM_TIMSTAMP")+"";
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setDue_policy_count("0");
					bean.setDue_policy_mfyp("0.0");
					bean.setBTCH_TIMSTAMP("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("premiumDue").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("premiumDue").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("premiumDue").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setDue_policy_count(object.getJSONObject("payload").getJSONObject("premiumDue").get("due_POLICY_COUNT").toString());
					}
					catch(Exception ex)
					{
						bean.setDue_policy_count("0");
					}
					try	{
						bean.setDue_policy_mfyp(object.getJSONObject("payload").getJSONObject("premiumDue").get("due_POLICY_MFYP").toString());
					}
					catch(Exception ex)	
					{
						bean.setDue_policy_mfyp("0.0");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("premiumDue").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("premiumDue").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setDue_policy_count("0");
				bean.setDue_policy_mfyp("0.0");
				bean.setBTCH_TIMSTAMP("N/A");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "COLLECTION":
		{ 
			try {
				String timeStamp = object.getJSONObject("payload").getJSONObject("collection").get("real_TIM_TIMSTAMP")+"";
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setTotal_collection_amt("0.0");
					bean.setTotal_collection_mfyp("0.0");
					bean.setBTCH_TIMSTAMP("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("collection").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("collection").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("collection").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setTotal_collection_amt(object.getJSONObject("payload").getJSONObject("collection").get("total_COLLECTION_AMT").toString());
					}
					catch(Exception ex)
					{
						bean.setTotal_collection_amt("0.0");
					}
					try	{
						bean.setTotal_collection_mfyp(object.getJSONObject("payload").getJSONObject("collection").get("total_COLLECTION_MFYP").toString());
					}
					catch(Exception ex)	
					{
						bean.setTotal_collection_mfyp("0.0");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("collection").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("collection").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setTotal_collection_amt("0.0");
				bean.setTotal_collection_mfyp("0.0");
				bean.setBTCH_TIMSTAMP("N/A");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "ROLLINGCOLLECTION":
		{  
			try {
				String timeStamp = object.getJSONObject("payload").getJSONObject("rollingCollection").get("real_TIM_TIMSTAMP")+"";
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setRolling_collection_12mth("0.0");
					bean.setRolling_mfyp_12mth("0.0");
					bean.setBTCH_TIMSTAMP("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("rollingCollection").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("rollingCollection").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("rollingCollection").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setRolling_collection_12mth(object.getJSONObject("payload").getJSONObject("rollingCollection").get("rolling_COLLECTION_12MTH").toString());
					}
					catch(Exception ex)
					{
						bean.setRolling_collection_12mth("0.0");
					}
					try	{
						bean.setRolling_mfyp_12mth(object.getJSONObject("payload").getJSONObject("rollingCollection").get("rolling_MFYP_12MTH").toString());
					}
					catch(Exception ex)	
					{
						bean.setRolling_mfyp_12mth("0.0");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("rollingCollection").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("rollingCollection").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setRolling_collection_12mth("0.0");
				bean.setRolling_mfyp_12mth("0.0");
				bean.setBTCH_TIMSTAMP("N/A");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "NTUED":
		{ 
			try {
				String timeStamp = object.getJSONObject("payload").getJSONObject("ntued").get("real_TIM_TIMSTAMP")+"";
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setNtu_policy_count("0");
					bean.setNtu_policy_afyp("0.0");
					bean.setBTCH_TIMSTAMP("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("ntued").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("ntued").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("ntued").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setNtu_policy_count(object.getJSONObject("payload").getJSONObject("ntued").get("ntu_POLICY_COUNT").toString());
					}
					catch(Exception ex)
					{
						bean.setNtu_policy_count("0");
					}
					try	{
						bean.setNtu_policy_afyp(object.getJSONObject("payload").getJSONObject("ntued").get("ntu_POLICY_AFYP").toString());
					}
					catch(Exception ex)	
					{
						bean.setNtu_policy_afyp("0.0");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("ntued").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("ntued").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setNtu_policy_count("0");
				bean.setNtu_policy_afyp("0.0");
				bean.setBTCH_TIMSTAMP("N/A");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "NOMINEEDETAILS":
		{  
			try {
				String timeStamp = object.getJSONObject("payload").getJSONObject("nomineeDetail").get("real_TIM_TIMSTAMP")+"";
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setPolicy_number("N/A");
					bean.setNominee_name("N/A");
					bean.setNominee_dob("N/A");
					bean.setNominee_relationship("N/A");
					bean.setNominee_share("N/A");
					bean.setBTCH_TIMSTAMP("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("policy_NUMBER").toString());
					}
					catch(Exception ex)
					{
						bean.setPolicy_number("N/A");
					}
					try	{
						bean.setNominee_name(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("nominee_NAME")+"");
					}
					catch(Exception ex)	
					{
						bean.setNominee_name("N/A");
					}
					try	{
						bean.setNominee_dob(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("nominee_DOB").toString());
					}
					catch(Exception ex)	
					{
						bean.setNominee_dob("N/A");
					}
					try	{
						bean.setNominee_relationship(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("nominee_RELATIONSHIP").toString());
					}
					catch(Exception ex)	
					{
						bean.setNominee_relationship("N/A");
					}
					try	{
						bean.setNominee_share(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("nominee_SHARE").toString());
					}
					catch(Exception ex)	
					{
						bean.setNominee_share("N/A");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("nomineeDetail").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setPolicy_number("N/A");
				bean.setNominee_name("N/A");
				bean.setNominee_dob("N/A");
				bean.setNominee_relationship("N/A");
				bean.setNominee_share("N/A");
				bean.setBTCH_TIMSTAMP("N/A");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "POLICYPACK":
		{ 
			try {
				String timeStamp = (object.getJSONObject("payload").getJSONObject("policyPack").get("real_TIM_TIMSTAMP").toString());
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setPolicy_number("N/A");
					bean.setPol_pack_delvry_dt("N/A");
					bean.setBTCH_TIMSTAMP("null");
					bean.setREAL_TIM_TIMSTAMP(dateFormat.format(cal));
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("policyPack").get("channel").toString());
					}
					catch(Exception ex){}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("policyPack").get("subChannel").toString());
					}
					catch(Exception ex)	{}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("policyPack").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	{}
					try	{
						bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("policyPack").get("policy_NUMBER").toString());
					}
					catch(Exception ex){}
					try	{
						bean.setPol_pack_delvry_dt(object.getJSONObject("payload").getJSONObject("policyPack").get("pol_PACK_DELVRY_DT").toString());
					}
					catch(Exception ex)	{}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyPack").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	{}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("policyPack").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	{}
				}
			}
			catch(Exception ex)	{}
		}
		break;
		case "MEDICALCATEGORY":
		{  
			try {
				String timeStamp = object.getJSONObject("payload").getJSONObject("medicalCategory").get("real_TIM_TIMSTAMP")+"";
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setPolicy_number("N/A");
					bean.setPol_med_category("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("medicalCategory").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("medicalCategory").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("medicalCategory").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("medicalCategory").get("policy_NUMBER").toString());
					}
					catch(Exception ex)
					{
						bean.setPolicy_number("N/A");
					}
					try	{
						bean.setPol_med_category(object.getJSONObject("payload").getJSONObject("medicalCategory").get("pol_MED_CATEGORY").toString());
					}
					catch(Exception ex)	
					{
						bean.setPol_med_category("N/A");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("medicalCategory").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("medicalCategory").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setPolicy_number("N/A");
				bean.setPol_med_category("N/A");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "FUNDVALUE":
		{ 
			try {
				String timeStamp = (object.getJSONObject("payload").getJSONObject("fundValue").get("real_TIM_TIMSTAMP").toString());
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setPolicy_number("N/A");
					bean.setPol_fund_value("N/A");
					bean.setBTCH_TIMSTAMP("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("fundValue").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("fundValue").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("fundValue").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("fundValue").get("policy_NUMBER").toString());
					}
					catch(Exception ex)
					{
						bean.setPolicy_number("N/A");
					}
					try	{
						bean.setPol_fund_value(object.getJSONObject("payload").getJSONObject("fundValue").get("pol_FUND_VALUE").toString());
					}
					catch(Exception ex)	
					{
						bean.setPol_fund_value("N/A");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("fundValue").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("fundValue").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setPolicy_number("N/A");
				bean.setPol_fund_value("N/A");
				bean.setBTCH_TIMSTAMP("N/A");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "ECSDATEPOLICY":
		{
			try {
				String timeStamp = (object.getJSONObject("payload").getJSONObject("ecsdate").get("real_TIM_TIMSTAMP").toString());
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setPolicy_number("N/A");
					bean.setPolicy_ecs_dt("N/A");
					bean.setBTCH_TIMSTAMP("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("ecsdate").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("ecsdate").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("ecsdate").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("ecsdate").get("policy_NUMBER").toString());
					}
					catch(Exception ex)
					{
						bean.setPolicy_number("N/A");
					}
					try	{
						bean.setPolicy_ecs_dt(object.getJSONObject("payload").getJSONObject("ecsdate").get("policy_ECS_DT").toString());
					}
					catch(Exception ex)	
					{
						bean.setPolicy_ecs_dt("N/A");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("ecsdate").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("ecsdate").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setPolicy_number("N/A");
				bean.setPolicy_ecs_dt("N/A");
				bean.setBTCH_TIMSTAMP("N/A");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "WELCOMECALLINGSTATUS":
		{ 
			try {
				String timeStamp = (object.getJSONObject("payload").getJSONObject("welcomeCalling").get("real_TIM_TIMSTAMP").toString());
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setPolicy_number("N/A");
					bean.setPol_welcom_call_status("N/A");
					bean.setBTCH_TIMSTAMP("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("policy_NUMBER").toString());
					}
					catch(Exception ex)
					{
						bean.setPolicy_number("N/A");
					}
					try	{
						bean.setPol_welcom_call_status(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("pol_WELCOM_CALL_STATUS").toString());
					}
					catch(Exception ex)	
					{
						bean.setPol_welcom_call_status("N/A");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("welcomeCalling").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setPolicy_number("N/A");
				bean.setPol_welcom_call_status("N/A");
				bean.setBTCH_TIMSTAMP("N/A");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "REASONWELCOMECALLSTATUS":
		{
			try {
				String timeStamp = (object.getJSONObject("payload").getJSONObject("reasonwelcomecallstatus").get("real_TIM_TIMSTAMP").toString());
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setPolicy_number("N/A");
					bean.setPol_welcom_call_region("N/A");
					bean.setBTCH_TIMSTAMP("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("raAdmAgtId").toString());
					}
					catch(Exception ex)
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setPolicy_number(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("policy_NUMBER").toString());
					}
					catch(Exception ex)
					{
						bean.setPolicy_number("N/A");
					}
					try	{
						bean.setPol_welcom_call_region(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("pol_WELCOM_CALL_REGION").toString());
					}
					catch(Exception ex)	
					{
						bean.setPol_welcom_call_region("N/A");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("reasonWelcome").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setPolicy_number("N/A");
				bean.setPol_welcom_call_region("N/A");
				bean.setBTCH_TIMSTAMP("N/A");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "MPERSISTENCY":
		{ 
			try {
				String timeStamp = (object.getJSONObject("payload").getJSONObject("mpersistency").get("real_TIM_TIMSTAMP").toString());
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setTotal_base_13m_pers("0.0");
					bean.setUnpaid_base_13m_pers("0.0");
					bean.setAchievement_13m_pers("0.0");
					bean.setBTCH_TIMSTAMP("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("mpersistency").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("mpersistency").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("mpersistency").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setTotal_base_13m_pers(object.getJSONObject("payload").getJSONObject("mpersistency").get("total_BASE_13M_PERS").toString());
					}
					catch(Exception ex)
					{
						bean.setTotal_base_13m_pers("0.0");
					}
					try	{
						bean.setUnpaid_base_13m_pers(object.getJSONObject("payload").getJSONObject("mpersistency").get("unpaid_BASE_13M_PERS").toString());
					}
					catch(Exception ex)	
					{
						bean.setUnpaid_base_13m_pers("0.0");
					}
					try	{
						bean.setAchievement_13m_pers(object.getJSONObject("payload").getJSONObject("mpersistency").get("achievement_13M_PERS").toString());
					}
					catch(Exception ex)
					{
						bean.setAchievement_13m_pers("0.0");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("mpersistency").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("mpersistency").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	{}
		}
		break;
		/*case "WIPCASES":
		{ 
		String timeStamp = (object.getJSONObject("payload").getJSONObject("wipCases").get("real_TIM_TIMSTAMP").toString());
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setWip_count("0");
					bean.setWip_mfyp("0.0");
					bean.setWip_afyp("0.0");
					bean.setWip_adj_mfyp("0.0");
					bean.setWip_stage("0.0");
					bean.setBTCH_TIMSTAMP("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(array.getString("channel"));
						//bean.setChannel(object.getJSONObject("payload").getJSONObject("wipCases").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("wipCases").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("wipCases").get("raAdmAgtId").toString());
					}
					catch(Exception ex)
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setWip_count(object.getJSONObject("payload").getJSONObject("wipCases").get("wip_COUNT").toString());
					}
					catch(Exception ex)
					{
						bean.setWip_count("0");
					}
					try	{
						bean.setWip_mfyp(object.getJSONObject("payload").getJSONObject("wipCases").get("wip_MFYP").toString());
					}
					catch(Exception ex)	
					{
						bean.setWip_mfyp("0.0");
					}
					try	{
						bean.setWip_afyp(object.getJSONObject("payload").getJSONObject("wipCases").get("wip_AFYP").toString());
					}
					catch(Exception ex)	
					{
						bean.setWip_afyp("0.0");
					}
					try	{
						bean.setWip_adj_mfyp(object.getJSONObject("payload").getJSONObject("wipCases").get("wip_ADJ_MFYP").toString());
					}
					catch(Exception ex)	
					{
						bean.setWip_adj_mfyp("0.0");
					}
					try	{
						bean.setWip_stage(object.getJSONObject("payload").getJSONObject("wipCases").get("wip_STAGE").toString());
					}
					catch(Exception ex)	
					{
						bean.setWip_stage("0.0");
					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("wipCases").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("wipCases").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setWip_count("0");
				bean.setWip_mfyp("0.0");
				bean.setWip_afyp("0.0");
				bean.setWip_adj_mfyp("0.0");
				bean.setWip_stage("0.0");
				bean.setBTCH_TIMSTAMP("N/A");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}*/
		case "WIPCASES":
		{ 
			try {
				JSONObject array = (JSONObject) (object.getJSONObject("payload").getJSONArray("wipCases").get(0));
				String timeStamp=array.getString("realTimTimstamp").toString();
				//String timeStamp = (object.getJSONObject("payload").getJSONObject("wipCases").get("real_TIM_TIMSTAMP").toString());
				if("realTimTimstamp".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setWip_count("0");
					bean.setWip_mfyp("0.0");
					bean.setWip_afyp("0.0");
					bean.setWip_adj_mfyp("0.0");
					bean.setWip_stage("0.0");
					bean.setBTCH_TIMSTAMP("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(array.getString("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(array.getString("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(array.getString("raAdmAgtId").toString());
					}
					catch(Exception ex)
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setWip_count(array.getString("wipCount").toString());
					}
					catch(Exception ex)
					{
						bean.setWip_count("0");
					}
					/*try	{
						bean.setWip_mfyp(array.getString("wip_MFYP").toString());
					}
					catch(Exception ex)	
					{
						bean.setWip_mfyp("0.0");
					}*/
					try	{
						bean.setWip_afyp(array.getString("wipAfyp").toString());
					}
					catch(Exception ex)	
					{
						bean.setWip_afyp("0.0");
					}
					try	{
						bean.setWip_adj_mfyp(array.getString("wipAdjMfyp").toString());
					}
					catch(Exception ex)	
					{
						bean.setWip_adj_mfyp("0.0");
					}
					try	{
						bean.setWip_stage(array.getString("wipStage").toString());
					}
					catch(Exception ex)	
					{
						bean.setWip_stage("0.0");
					}
					try	{
						bean.setBTCH_TIMSTAMP(array.getString("btchTimstamp").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(array.getString("realTimTimstamp").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setWip_count("0");
				bean.setWip_mfyp("0.0");
				bean.setWip_afyp("0.0");
				bean.setWip_adj_mfyp("0.0");
				bean.setWip_stage("0.0");
				bean.setBTCH_TIMSTAMP("N/A");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "APPLIEDCASES":
		case "APPLIEDFYP":
		{ 
			try {
				String timeStamp = (object.getJSONObject("payload").getJSONObject("appliedCases").get("real_TIM_TIMSTAMP").toString());
				if("REAL_TIM_TIMSTAMP".equalsIgnoreCase(timeStamp)||"null".equalsIgnoreCase(timeStamp)
						||"".equalsIgnoreCase(timeStamp))
				{
					bean.setChannel("N/A");
					bean.setSub_channel("N/A");
					bean.setRa_adm_agt_id("N/A");
					bean.setApplied_total_afyp_ftd("0.0");
					bean.setApplied_total_afyp_mtd("0.0");
					bean.setApplied_total_afyp_qtd("0.0");
					bean.setApplied_total_afyp_ytd("0.0");
					bean.setApplied_count_ftd("0");
					bean.setApplied_count_mtd("0");
					bean.setApplied_count_qtd("0");
					bean.setApplied_count_ytd("0");
					bean.setBTCH_TIMSTAMP("N/A");
					bean.setREAL_TIM_TIMSTAMP("N/A");
				}
				else
				{
					try	{
						bean.setChannel(object.getJSONObject("payload").getJSONObject("appliedCases").get("channel").toString());
					}
					catch(Exception ex)
					{
						bean.setChannel("N/A");
					}
					try	{
						bean.setSub_channel(object.getJSONObject("payload").getJSONObject("appliedCases").get("subChannel").toString());
					}
					catch(Exception ex)	
					{
						bean.setSub_channel("N/A");
					}
					try	{
						bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("appliedCases").get("raAdmAgtId").toString());
					}
					catch(Exception ex)	
					{
						bean.setRa_adm_agt_id("N/A");
					}
					try	{
						bean.setApplied_total_afyp_ftd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_TOTAL_AFYP_FTD").toString());
					}
					catch(Exception ex)
					{
						bean.setApplied_total_afyp_ftd("0.0");
					}
					try	{
						bean.setApplied_total_afyp_mtd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_TOTAL_AFYP_MTD").toString());
					}
					catch(Exception ex)	
					{
						bean.setApplied_total_afyp_mtd("0.0");
					}
					try	{
						bean.setApplied_total_afyp_qtd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_TOTAL_AFYP_QTD").toString());
					}
					catch(Exception ex)	
					{
						bean.setApplied_total_afyp_qtd("0.0");
					}
					try	{
						bean.setApplied_total_afyp_ytd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_TOTAL_AFYP_YTD").toString());
					}
					catch(Exception ex)	
					{
						bean.setApplied_total_afyp_ytd("0.0");
					}
					try	{
						bean.setApplied_count_ftd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_COUNT_FTD").toString());
					}
					catch(Exception ex)	
					{
						bean.setApplied_count_ftd("0");
					}
					try	{
						bean.setApplied_count_mtd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_COUNT_MTD").toString());
					}
					catch(Exception ex)	
					{
						bean.setApplied_count_mtd("0");
					}
					try	{
						bean.setApplied_count_qtd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_COUNT_QTD").toString());
					}
					catch(Exception ex)	
					{
						bean.setApplied_count_qtd("0");
					}
					try	{
						bean.setApplied_count_ytd(object.getJSONObject("payload").getJSONObject("appliedCases").get("applied_COUNT_YTD").toString());
					}
					catch(Exception ex)	
					{
						bean.setApplied_count_ytd("0");

					}
					try	{
						bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("appliedCases").get("btch_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setBTCH_TIMSTAMP("N/A");
					}
					try	{
						bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("appliedCases").get("real_TIM_TIMSTAMP").toString());
					}
					catch(Exception ex)	
					{
						bean.setREAL_TIM_TIMSTAMP("N/A");
					}
				}
			}
			catch(Exception ex)	
			{
				bean.setChannel("N/A");
				bean.setSub_channel("N/A");
				bean.setRa_adm_agt_id("N/A");
				bean.setApplied_total_afyp_ftd("0.0");
				bean.setApplied_total_afyp_mtd("0.0");
				bean.setApplied_total_afyp_qtd("0.0");
				bean.setApplied_total_afyp_ytd("0.0");
				bean.setApplied_count_ftd("0");
				bean.setApplied_count_mtd("0");
				bean.setApplied_count_qtd("0");
				bean.setApplied_count_ytd("0");
				bean.setBTCH_TIMSTAMP("N/A");
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		/*-------------------------------Sprint 3.2-----------------------------------------------------------------*/
		case "AXISBANK":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("axisBank").get("channel").toString());
			}
			catch(Exception ex)
			{
				bean.setChannel("N/A");
			}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("axisBank").get("subChannel").toString());
			}
			catch(Exception ex)	
			{
				bean.setSub_channel("N/A");
			}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("axisBank").get("raAdmAgtId").toString());
			}
			catch(Exception ex)
			{
				bean.setRa_adm_agt_id("N/A");
			}
			try	{
				bean.setActivisa_mtd_active(object.getJSONObject("payload").getJSONObject("axisBank").get("activisa_MTD_ACTIVE").toString());
			}
			catch(Exception ex)
			{
				bean.setActivisa_mtd_active("N/A");
			}
			try	{
				bean.setPerform_15th_month_pers_qtd_p(object.getJSONObject("payload").getJSONObject("axisBank").get("perform_15TH_MONTH_PERS_QTD_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setPerform_15th_month_pers_qtd_p("N/A");
			}
			try	{
				bean.setMtd_adj_mfyp_ach_prcntg(object.getJSONObject("payload").getJSONObject("axisBank").get("mtd_ADJ_MFYP_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_adj_mfyp_ach_prcntg("N/A");
			}
			try	{
				bean.setGpa_score(object.getJSONObject("payload").getJSONObject("axisBank").get("gpa_SCORE").toString());
			}
			catch(Exception ex)	
			{
				bean.setGpa_score("N/A");
			}
			try	{
				bean.setActivisa_mtd_prcntg(object.getJSONObject("payload").getJSONObject("axisBank").get("activisa_MTD_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setActivisa_mtd_prcntg("N/A");
			}
			try	{
				bean.setActivisa_mtd_manmonth(object.getJSONObject("payload").getJSONObject("axisBank").get("activisa_MTD_MANMONTH").toString());
			}
			catch(Exception ex)	
			{
				bean.setActivisa_mtd_manmonth("N/A");
			}
			try	{
				bean.setMtd_activa_act_ach_prcntg(object.getJSONObject("payload").getJSONObject("axisBank").get("mtd_ACTIVA_ACT_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_activa_act_ach_prcntg("N/A");
			}
			try	{
				bean.setPerform_adj_mfyp_plan_ach_p(object.getJSONObject("payload").getJSONObject("axisBank").get("perform_ADJ_MFYP_PLAN_ACH_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setPerform_adj_mfyp_plan_ach_p("N/A");
			}
			try	{
				bean.setMtd_adj_mfyp_plan(object.getJSONObject("payload").getJSONObject("axisBank").get("mtd_ADJ_MFYP_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_adj_mfyp_plan("N/A");
			}
			try	{
				bean.setMtd_adj_mfyp_actual(object.getJSONObject("payload").getJSONObject("axisBank").get("mtd_ADJ_MFYP_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_adj_mfyp_actual("N/A");
			}
			try	{
				bean.setQtd_adj_mfyp_ach_prcntg(object.getJSONObject("payload").getJSONObject("axisBank").get("qtd_ADJ_MFYP_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_adj_mfyp_ach_prcntg("N/A");
			}
			try	{
				bean.setQtd_adj_mfyp_plan(object.getJSONObject("payload").getJSONObject("axisBank").get("qtd_ADJ_MFYP_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_adj_mfyp_plan("N/A");
			}
			try	{
				bean.setQtd_adj_mfyp_actual(object.getJSONObject("payload").getJSONObject("axisBank").get("qtd_ADJ_MFYP_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_adj_mfyp_actual("N/A");
			}
			try	{
				bean.setYtd_adj_mfyp_ach_prcntg(object.getJSONObject("payload").getJSONObject("axisBank").get("ytd_ADJ_MFYP_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_adj_mfyp_ach_prcntg("N/A");
			}
			try	{
				bean.setYtd_adj_mfyp_plan(object.getJSONObject("payload").getJSONObject("axisBank").get("ytd_ADJ_MFYP_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_adj_mfyp_plan("N/A");
			}
			try	{
				bean.setYtd_adj_mfyp_actual(object.getJSONObject("payload").getJSONObject("axisBank").get("ytd_ADJ_MFYP_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_adj_mfyp_actual("N/A");
			}
			try	{
				bean.setMtd_activa_plan_manmonth(object.getJSONObject("payload").getJSONObject("axisBank").get("mtd_ACTIVA_PLAN_MANMONTH").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_activa_plan_manmonth("N/A");
			}
			try	{
				bean.setMtd_activa_plan_active(object.getJSONObject("payload").getJSONObject("axisBank").get("mtd_ACTIVA_PLAN_ACTIVE").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_activa_plan_active("N/A");
			}
			try	{
				bean.setMtd_activa_plan_ach_prcntg(object.getJSONObject("payload").getJSONObject("axisBank").get("mtd_ACTIVA_PLAN_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_activa_plan_ach_prcntg("N/A");
			}
			try	{
				bean.setPerform_activation_ach_p(object.getJSONObject("payload").getJSONObject("axisBank").get("perform_ACTIVATION_ACH_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setPerform_activation_ach_p("N/A");
			}
			/* DB team Added after development------------------------------------------------------------------------*/
			try	{
				bean.setPrmtn_shrtfl_adj_mfyp_pln_ach(object.getJSONObject("payload").getJSONObject("axisBank").get("prmtn_SHRTFL_ADJ_MFYP_PLN_ACH").toString());
			}
			catch(Exception ex)	
			{
				bean.setPrmtn_shrtfl_adj_mfyp_pln_ach("N/A");
			}
			try	{
				bean.setPrmtn_shrtfl_actvn_ach(object.getJSONObject("payload").getJSONObject("axisBank").get("prmtn_SHRTFL_ACTVN_ACH").toString());
			}
			catch(Exception ex)	
			{
				bean.setPrmtn_shrtfl_actvn_ach("N/A");
			}
			try	{
				bean.setPrmtn_shrtfl_15m_pers_qtd_ach(object.getJSONObject("payload").getJSONObject("axisBank").get("prmtn_SHRTFL_15M_PERS_QTD_ACH").toString());
			}
			catch(Exception ex)	
			{
				bean.setPrmtn_shrtfl_15m_pers_qtd_ach("N/A");
			}
			/*------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("axisBank").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	
			{
				bean.setBTCH_TIMSTAMP("N/A");
			}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("axisBank").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	
			{
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "CAT":
		{ 

			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("cat").get("channel").toString());
			}
			catch(Exception ex)
			{
				bean.setChannel("N/A");
			}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("cat").get("subChannel").toString());
			}
			catch(Exception ex)	
			{
				bean.setSub_channel("N/A");
			}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("cat").get("raAdmAgtId").toString());
			}
			catch(Exception ex)	
			{
				bean.setSub_channel("N/A");
			}
			try	{
				bean.setPromo_wtg_fyp_act_6m(object.getJSONObject("payload").getJSONObject("cat").get("promo_WTG_FYP_ACT_6M").toString());
			}
			catch(Exception ex)
			{
				bean.setPromo_wtg_fyp_act_6m("N/A");
			}
			try	{
				bean.setPromo_wtg_fyp_ach_p_6m(object.getJSONObject("payload").getJSONObject("cat").get("promo_WTG_FYP_ACH_P_6M").toString());
			}
			catch(Exception ex)
			{
				bean.setPromo_wtg_fyp_ach_p_6m("N/A");
			}
			try	{
				bean.setPromo_nop_act_6m(object.getJSONObject("payload").getJSONObject("cat").get("promo_NOP_ACT_6M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_nop_act_6m("N/A");
			}
			try	{
				bean.setPromo_nop_ach_p_6m(object.getJSONObject("payload").getJSONObject("cat").get("promo_NOP_ACH_P_6M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_nop_ach_p_6m("N/A");
			}
			try	{
				bean.setPromo_collection_ach_p(object.getJSONObject("payload").getJSONObject("cat").get("promo_COLLECTION_ACH_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_collection_ach_p("N/A");
			}
			try	{
				bean.setPromo_wtg_fyp_act_9m(object.getJSONObject("payload").getJSONObject("cat").get("promo_WTG_FYP_ACT_9M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_wtg_fyp_act_9m("N/A");
			}
			try	{
				bean.setPromo_wtg_fyp_ach_p_9m(object.getJSONObject("payload").getJSONObject("cat").get("promo_WTG_FYP_ACH_P_9M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_wtg_fyp_ach_p_9m("N/A");
			}
			try	{
				bean.setPromo_nop_act_9m(object.getJSONObject("payload").getJSONObject("cat").get("promo_NOP_ACT_9M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_nop_act_9m("N/A");
			}
			try	{
				bean.setPromo_nop_ach_p_9m(object.getJSONObject("payload").getJSONObject("cat").get("promo_NOP_ACH_P_9M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_nop_ach_p_9m("N/A");
			}
			try	{
				bean.setPromo_wtg_fyp_act12m(object.getJSONObject("payload").getJSONObject("cat").get("promo_WTG_FYP_ACT12M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_wtg_fyp_act12m("N/A");
			}
			try	{
				bean.setPromo_wtg_fyp_ach_p_12m(object.getJSONObject("payload").getJSONObject("cat").get("promo_WTG_FYP_ACH_P_12M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_wtg_fyp_ach_p_12m("N/A");
			}
			try	{
				bean.setPromo_nop_act12m(object.getJSONObject("payload").getJSONObject("cat").get("promo_NOP_ACT12M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_nop_act12m("N/A");
			}
			try	{
				bean.setPromo_nop_ach_p_12m(object.getJSONObject("payload").getJSONObject("cat").get("promo_NOP_ACH_P_12M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_nop_ach_p_12m("N/A");
			}
			try	{
				bean.setYtd_wtg_fyp_plan(object.getJSONObject("payload").getJSONObject("cat").get("ytd_WTG_FYP_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_wtg_fyp_plan("N/A");
			}
			try	{
				bean.setYtd_wtg_fyp_actual(object.getJSONObject("payload").getJSONObject("cat").get("ytd_WTG_FYP_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_wtg_fyp_actual("N/A");
			}
			try	{
				bean.setMtd_g3_wtg_fyp_ach_prcntg(object.getJSONObject("payload").getJSONObject("cat").get("mtd_G3_WTG_FYP_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_g3_wtg_fyp_ach_prcntg("N/A");
			}
			try	{
				bean.setMtd_g3_wtg_fyp_plan(object.getJSONObject("payload").getJSONObject("cat").get("mtd_G3_WTG_FYP_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_g3_wtg_fyp_plan("N/A");
			}
			try	{
				bean.setMtd_g3_wtg_fyp_actual(object.getJSONObject("payload").getJSONObject("cat").get("mtd_G3_WTG_FYP_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_g3_wtg_fyp_actual("N/A");
			}
			try	{
				bean.setQtd_g3_wtg_fyp_ach_prcntg(object.getJSONObject("payload").getJSONObject("cat").get("qtd_G3_WTG_FYP_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_g3_wtg_fyp_ach_prcntg("N/A");
			}
			try	{
				bean.setQtd_g3_wtg_fyp_plan(object.getJSONObject("payload").getJSONObject("cat").get("qtd_G3_WTG_FYP_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_g3_wtg_fyp_plan("N/A");
			}
			try	{
				bean.setQtd_g3_wtg_fyp_actual(object.getJSONObject("payload").getJSONObject("cat").get("qtd_G3_WTG_FYP_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_g3_wtg_fyp_actual("N/A");
			}
			try	{
				bean.setYtd_g3_wtg_fyp_ach_prcntg(object.getJSONObject("payload").getJSONObject("cat").get("ytd_G3_WTG_FYP_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_g3_wtg_fyp_ach_prcntg("N/A");
			}
			try	{
				bean.setYtd_g3_wtg_fyp_plan(object.getJSONObject("payload").getJSONObject("cat").get("ytd_G3_WTG_FYP_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_g3_wtg_fyp_plan("N/A");
			}
			try	{
				bean.setYtd_g3_wtg_fyp_actual(object.getJSONObject("payload").getJSONObject("cat").get("ytd_G3_WTG_FYP_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_g3_wtg_fyp_actual("N/A");
			}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("cat").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	
			{
				bean.setBTCH_TIMSTAMP("N/A");
			}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("cat").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	
			{
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "Agency":
		{ 

			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("agency").get("channel").toString());
			}
			catch(Exception ex)
			{
				bean.setChannel("N/A");
			}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("agency").get("subChannel").toString());
			}
			catch(Exception ex)	
			{
				bean.setSub_channel("N/A");
			}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("agency").get("raAdmAgtId").toString());
			}
			catch(Exception ex)
			{
				bean.setRa_adm_agt_id("N/A");
			}
			try	{
				bean.setAdm_tot_gpa_scor_extra_credit(object.getJSONObject("payload").getJSONObject("agency").get("adm_TOT_GPA_SCOR_EXTRA_CREDIT").toString());
			}
			catch(Exception ex)
			{
				bean.setAdm_tot_gpa_scor_extra_credit("N/A");
			}
			try	{
				bean.setRecruitment_mtd(object.getJSONObject("payload").getJSONObject("agency").get("recruitment_MTD").toString());
			}
			catch(Exception ex)	
			{
				bean.setRecruitment_mtd("N/A");
			}
			try	{
				bean.setRecruitment_ytd(object.getJSONObject("payload").getJSONObject("agency").get("recruitment_YTD").toString());
			}
			catch(Exception ex)	
			{
				bean.setRecruitment_ytd("N/A");
			}
			try	{
				bean.setQua_recruit_extra_cr_actual(object.getJSONObject("payload").getJSONObject("agency").get("qua_RECRUIT_EXTRA_CR_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setQua_recruit_extra_cr_actual("N/A");
			}
			try	{
				bean.setQua_recruit_ach_percntg(object.getJSONObject("payload").getJSONObject("agency").get("qua_RECRUIT_ACH_PERCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setQua_recruit_ach_percntg("N/A");
			}
			try	{
				bean.setNat_count_ftd(object.getJSONObject("payload").getJSONObject("agency").get("nat_COUNT_FTD").toString());
			}
			catch(Exception ex)	
			{
				bean.setNat_count_ftd("N/A");
			}
			try	{
				bean.setNat_count_mtd(object.getJSONObject("payload").getJSONObject("agency").get("nat_COUNT_MTD").toString());
			}
			catch(Exception ex)	
			{
				bean.setNat_count_mtd("N/A");
			}
			try	{
				bean.setYtd_wtg_fyp_in_lac_act(object.getJSONObject("payload").getJSONObject("agency").get("ytd_WTG_FYP_IN_LAC_ACT").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_wtg_fyp_in_lac_act("N/A");
			}
			try	{
				bean.setYtd_wtg_fyp_in_lac_ach_p(object.getJSONObject("payload").getJSONObject("agency").get("ytd_WTG_FYP_IN_LAC_ACH_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_wtg_fyp_in_lac_ach_p("N/A");
			}
			try	{
				bean.setQua_recruit_with_extra_cre_act(object.getJSONObject("payload").getJSONObject("agency").get("qua_RECRUIT_WITH_EXTRA_CRE_ACT").toString());
			}
			catch(Exception ex)	
			{
				bean.setQua_recruit_with_extra_cre_act("N/A");
			}
			try	{
				bean.setQua_recruit_ach_p(object.getJSONObject("payload").getJSONObject("agency").get("qua_RECRUIT_ACH_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setQua_recruit_ach_p("N/A");
			}
			try	{
				bean.setTot_proac_agt_mm_wit_extr_cred(object.getJSONObject("payload").getJSONObject("agency").get("tot_PROAC_AGT_MM_WIT_EXTR_CRED").toString());
			}
			catch(Exception ex)	
			{
				bean.setTot_proac_agt_mm_wit_extr_cred("N/A");
			}
			try	{
				bean.setTot_proac_agt_mm_ach_p(object.getJSONObject("payload").getJSONObject("agency").get("tot_PROAC_AGT_MM_ACH_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setTot_proac_agt_mm_ach_p("N/A");
			}
			try	{
				bean.setYtd_wtg_fyp_ach_prcntg(object.getJSONObject("payload").getJSONObject("agency").get("ytd_WTG_FYP_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_wtg_fyp_ach_prcntg("N/A");
			}
			try	{
				bean.setPromo_wtg_fyp_act_6m(object.getJSONObject("payload").getJSONObject("agency").get("promo_WTG_FYP_ACT_6M").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_wtg_fyp_act_6m("N/A");
			}
			try	{
				bean.setYtd_adj_mfyp_plan(object.getJSONObject("payload").getJSONObject("agency").get("ytd_ADJ_MFYP_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_adj_mfyp_plan("N/A");
			}
			try	{
				bean.setYtd_adj_mfyp_actual(object.getJSONObject("payload").getJSONObject("agency").get("ytd_ADJ_MFYP_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_adj_mfyp_actual("N/A");
			}
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("agency").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	
			{
				bean.setBTCH_TIMSTAMP("N/A");
			}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("agency").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	
			{
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
		case "YBL":
		{ 
			try	{
				bean.setChannel(object.getJSONObject("payload").getJSONObject("ybl").get("channel").toString());
			}
			catch(Exception ex)
			{
				bean.setChannel("N/A");
			}
			try	{
				bean.setSub_channel(object.getJSONObject("payload").getJSONObject("ybl").get("subChannel").toString());
			}
			catch(Exception ex)	
			{
				bean.setSub_channel("N/A");
			}
			try	{
				bean.setRa_adm_agt_id(object.getJSONObject("payload").getJSONObject("ybl").get("raAdmAgtId").toString());
			}
			catch(Exception ex)
			{
				bean.setRa_adm_agt_id("N/A");
			}
			try	{
				bean.setActivisa_mtd_prcntg(object.getJSONObject("payload").getJSONObject("ybl").get("activisa_MTD_PRCNTG").toString());
			}
			catch(Exception ex)
			{
				bean.setActivisa_mtd_prcntg("N/A");
			}
			try	{
				bean.setActivisa_mtd_manmonth(object.getJSONObject("payload").getJSONObject("ybl").get("activisa_MTD_MANMONTH").toString());
			}
			catch(Exception ex)	
			{
				bean.setActivisa_mtd_manmonth("N/A");
			}
			try	{
				bean.setActivisa_mtd_active(object.getJSONObject("payload").getJSONObject("ybl").get("activisa_MTD_ACTIVE").toString());
			}
			catch(Exception ex)	
			{
				bean.setActivisa_mtd_active("N/A");
			}
			try	{
				bean.setActivisa_mtd_plan_prcntg(object.getJSONObject("payload").getJSONObject("ybl").get("activisa_MTD_PLAN_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setActivisa_mtd_plan_prcntg("N/A");
			}
			try	{
				bean.setPromo_adj_p_mfyp_in_lacs_act(object.getJSONObject("payload").getJSONObject("ybl").get("promo_ADJ_P_MFYP_IN_LACS_ACT").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_adj_p_mfyp_in_lacs_act("N/A");
			}
			try	{
				bean.setPromo_adj_p_mfyp_in_lacs_p(object.getJSONObject("payload").getJSONObject("ybl").get("promo_ADJ_P_MFYP_IN_LACS_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_adj_p_mfyp_in_lacs_p("N/A");
			}
			try	{
				bean.setPromo_paid_cases_act(object.getJSONObject("payload").getJSONObject("ybl").get("promo_PAID_CASES_ACT").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_paid_cases_act("N/A");
			}
			try	{
				bean.setPromo_paid_cases_p(object.getJSONObject("payload").getJSONObject("ybl").get("promo_PAID_CASES_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_paid_cases_p("N/A");
			}
			try	{
				bean.setPromo_15m_pers_in_lacs_p(object.getJSONObject("payload").getJSONObject("ybl").get("promo_15M_PERS_IN_LACS_P").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_15m_pers_in_lacs_p("N/A");
			}
			try	{
				bean.setMtd_adj_mfyp_in_lac_ach_prcntg(object.getJSONObject("payload").getJSONObject("ybl").get("mtd_ADJ_MFYP_IN_LAC_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_adj_mfyp_in_lac_ach_prcntg("N/A");
			}
			try	{
				bean.setMtd_adj_mfyp_in_lac_plan(object.getJSONObject("payload").getJSONObject("ybl").get("mtd_ADJ_MFYP_IN_LAC_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_adj_mfyp_in_lac_plan("N/A");
			}
			try	{
				bean.setMtd_adj_mfyp_in_lac_actual(object.getJSONObject("payload").getJSONObject("ybl").get("mtd_ADJ_MFYP_IN_LAC_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setMtd_adj_mfyp_in_lac_actual("N/A");
			}
			try	{
				bean.setQtd_adj_mfyp_in_lac_ach_prcntg(object.getJSONObject("payload").getJSONObject("ybl").get("qtd_ADJ_MFYP_IN_LAC_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_adj_mfyp_in_lac_ach_prcntg("N/A");
			}
			try	{
				bean.setQtd_adj_mfyp_in_lac_plan(object.getJSONObject("payload").getJSONObject("ybl").get("qtd_ADJ_MFYP_IN_LAC_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_adj_mfyp_in_lac_plan("N/A");
			}
			try	{
				bean.setQtd_adj_mfyp_in_lac_actual(object.getJSONObject("payload").getJSONObject("ybl").get("qtd_ADJ_MFYP_IN_LAC_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setQtd_adj_mfyp_in_lac_actual("N/A");
			}
			try	{
				bean.setYtd_adj_mfyp_in_lac_ach_prcntg(object.getJSONObject("payload").getJSONObject("ybl").get("ytd_ADJ_MFYP_IN_LAC_ACH_PRCNTG").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_adj_mfyp_in_lac_ach_prcntg("N/A");
			}
			try	{
				bean.setYtd_adj_mfyp_in_lac_plan(object.getJSONObject("payload").getJSONObject("ybl").get("ytd_ADJ_MFYP_IN_LAC_PLAN").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_adj_mfyp_in_lac_plan("N/A");
			}
			try	{
				bean.setYtd_adj_mfyp_in_lac_actual(object.getJSONObject("payload").getJSONObject("ybl").get("ytd_ADJ_MFYP_IN_LAC_ACTUAL").toString());
			}
			catch(Exception ex)	
			{
				bean.setYtd_adj_mfyp_in_lac_actual("N/A");
			}
			
			/*-------------------------------------------------------------------------------------------------------------------------*/
			try	{
				bean.setPromo_adj_p_mfyp_in_lacs_srtfl(object.getJSONObject("payload").getJSONObject("ybl").get("promo_ADJ_P_MFYP_IN_LACS_SRTFL").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_adj_p_mfyp_in_lacs_srtfl("N/A");
			}
			try	{
				bean.setPromo_paid_cases_shortfall(object.getJSONObject("payload").getJSONObject("ybl").get("promo_PAID_CASES_SHORTFALL").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_paid_cases_shortfall("N/A");
			}
			try	{
				bean.setPromo_15m_pers_shortfall(object.getJSONObject("payload").getJSONObject("ybl").get("promo_15M_PERS_SHORTFALL").toString());
			}
			catch(Exception ex)	
			{
				bean.setPromo_15m_pers_shortfall("N/A");
			}
			try	{
				bean.setGpa_score(object.getJSONObject("payload").getJSONObject("ybl").get("gpa_SCORE").toString());
			}
			catch(Exception ex)	
			{
				bean.setGpa_score("N/A");
			}
			/*------------------------------------------------------------------------------*/
			try	{
				bean.setBTCH_TIMSTAMP(object.getJSONObject("payload").getJSONObject("ybl").get("btch_TIMSTAMP").toString());
			}
			catch(Exception ex)	
			{
				bean.setBTCH_TIMSTAMP("N/A");
			}
			try	{
				bean.setREAL_TIM_TIMSTAMP(object.getJSONObject("payload").getJSONObject("ybl").get("real_TIM_TIMSTAMP").toString());
			}
			catch(Exception ex)	
			{
				bean.setREAL_TIM_TIMSTAMP("N/A");
			}
		}
		break;
	default :
		finalresponse="No Action Matched";
	}
	return finalresponse;
}
}
