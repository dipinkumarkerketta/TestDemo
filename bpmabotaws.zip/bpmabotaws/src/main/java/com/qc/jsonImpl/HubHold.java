package com.qc.jsonImpl;

import org.json.JSONObject;

import com.qc.dataBean.HubHoldBean;
public class HubHold 
{
	public HubHoldBean HubHoldmethod(JSONObject object)
	{
		HubHoldBean hubHoldBean = new HubHoldBean();
		try{
			hubHoldBean.setMtd_hub_hold_cases(object.getJSONObject("payload").getJSONObject("hubHold").get("mtd_hub_hold_cases").toString());
		}catch(Exception e){}
		try{
			hubHoldBean.setYtd_hub_hold_cases(object.getJSONObject("payload").getJSONObject("hubHold").get("ytd_hub_hold_cases").toString());
		}catch(Exception e){}
		try{
			hubHoldBean.setDaily_hub_hold_cases(object.getJSONObject("payload").getJSONObject("hubHold").get("daily_hub_hold_cases").toString());
		}catch(Exception e){}
		try{
			hubHoldBean.setMtd_hub_hold_adj_mfyp(object.getJSONObject("payload").getJSONObject("hubHold").get("mtd_hub_hold_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			hubHoldBean.setYtd_hub_hold_adj_mfyp(object.getJSONObject("payload").getJSONObject("hubHold").get("ytd_hub_hold_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			hubHoldBean.setDaily_hub_hold_adj_mfyp(object.getJSONObject("payload").getJSONObject("hubHold").get("daily_hub_hold_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			hubHoldBean.setTotal_hub_hold_cases(object.getJSONObject("payload").getJSONObject("hubHold").get("total_hub_hold_cases").toString());
		}catch(Exception e){}
		try{
			hubHoldBean.setTotal_hub_hold_adj_mfyp(object.getJSONObject("payload").getJSONObject("hubHold").get("total_hub_hold_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			hubHoldBean.setBtch_timstamp(object.getJSONObject("payload").getJSONObject("hubHold").get("btch_timstamp").toString());
		}catch(Exception e){}
		try{
			hubHoldBean.setReal_tim_timstamp(object.getJSONObject("payload").getJSONObject("hubHold").get("real_tim_timstamp").toString());
		}catch(Exception e){}
		return hubHoldBean;
	}
}
