package com.qc.jsonImpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import com.qc.dataBean.AprAgentListBean;
import com.qc.dataBean.AprBean;

public class AprAgentList 
{
	private static Logger logger = LogManager.getLogger(Apr.class);
	@Autowired
	AprAgentListBean aprBeanAgentList;
	
	public AprAgentListBean getAprAgentList(JSONObject object)
	{
		JSONObject payLoad = null;
		try
		{
		if(object != null)
		{		
		payLoad=object.getJSONObject("payload");
		
		JSONArray agentDetails= payLoad.getJSONArray("agentDetails");
		
		for(int i=0;i<agentDetails.length();i++)
		{
		
		aprBeanAgentList.setAgentId(validatePolicyData(agentDetails.getJSONObject(i).get("agentId")));
		aprBeanAgentList.setAgentName(validatePolicyData(agentDetails.getJSONObject(i).get("agentName")));
		aprBeanAgentList.setAgentDesignationCode(validatePolicyData(agentDetails.getJSONObject(i).get("agentDesignationCode")));
		}
		}
		}
		catch(Exception ex)
		{
			logger.error("creating exception in getAprAgentList "+ex);
		}
		return aprBeanAgentList;
	}
	
	private String validatePolicyData(Object object) 
	{
		String policyStatus="";
		try
		{
		if(object!=null && !(object.toString().isEmpty())){
			policyStatus= object.toString();
		}
			
		}catch(Exception ex)
		{
			logger.error("creating exception in validatePolicyData "+ex);
		}
		return policyStatus;
	}
}
