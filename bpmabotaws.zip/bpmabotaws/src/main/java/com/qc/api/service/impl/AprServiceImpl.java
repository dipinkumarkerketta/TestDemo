package com.qc.api.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.axis2.util.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.qc.api.response.WebhookResponse;
import com.qc.api.service.AprService;
import com.qc.common.ADMHeaderConstant;
import com.qc.common.DRHeaderConstant;
import com.qc.common.Facebook;
import com.qc.common.InnerButton;
import com.qc.common.InnerData;
import com.qc.common.ValueInLacs;
import com.qc.controller.MliBotController;
import com.qc.dataBean.AprBean;
import com.qc.jsonImpl.Apr;
import com.qc.jsonImpl.MailReportJson;
import com.qc.utils.AprApiCall;

@Component
public class AprServiceImpl implements AprService {

	private static Logger logger = LogManager.getLogger(AprServiceImpl.class);
	ResourceBundle res = ResourceBundle.getBundle("com.qc.bot.resources.application");

	@Autowired
	AprApiCall aprApiCall;

	@Autowired
	Apr aprImpl;

	@Autowired
	AprBean aprBean;

	@Autowired
	Apr apr;

	@Autowired
	private MailReportJson mailReportJson;

	@Autowired
	private SendMailServiceImpl sendMailServiceImpl;

	@Autowired
	private ValueInLacs valueInLacs;

	public WebhookResponse getAPrData(String actionperformed, String user_ssoid, String agentId, String emailId,
			String agentCode, String agentName, String sessionId) {
		JSONObject jSONObject = null;
		String speech = " ";
		String finalresponse = "";
		String agentListResponse = "";
		InnerData innerData = new InnerData();
		List<InnerButton> buttons = null;
		Facebook fb = new Facebook();
		boolean belowAgent = false;
		switch (actionperformed) {

		case "APR": {


			finalresponse = aprApiCall.getAprData(user_ssoid, agentId, "NO");

			if(finalresponse!=null && !"".equalsIgnoreCase(finalresponse)){
				jSONObject = new JSONObject(finalresponse);
				String allAgentCode = jSONObject.getJSONObject("payload").getJSONObject("aprDesignationResponse").get("designationCode").toString();
				String[] arrayAgentCode = allAgentCode.split(",");

				for (int i = 0; i < arrayAgentCode.length; i++) {
					if (arrayAgentCode[i].equalsIgnoreCase(agentCode))
						belowAgent = true;
				}
				agentListResponse = aprApiCall.getAgentList(user_ssoid, agentId);

				aprBean = apr.getApr(jSONObject);
				String toBePopulateAgentList = apr.toBePopulateAgentList(agentListResponse);
				if (belowAgent) {
					buttons = new ArrayList<InnerButton>();

					StringBuilder str1 = new StringBuilder();
					InnerButton button1 = new InnerButton();
					str1.append(DRHeaderConstant.MTD + "|" + aprBean.getPaidCasesMtd() + "#" + aprBean.getAdjMfypMtd() + "#"
							+ aprBean.getWeightMfypMtd() + "#" + aprBean.getFycMtd() + "#" + aprBean.getMtdGrowthPer());
					button1.setText("MTD - Paid Business");
					button1.setPostback(str1.toString());
					buttons.add(button1);

					StringBuilder str2 = new StringBuilder();
					InnerButton button2 = new InnerButton();
					str2.append(DRHeaderConstant.YTD + "|" + aprBean.getYtdPaidCases() + "#" + aprBean.getAdjMfypYtd() + "#"
							+ aprBean.getWeightMfypYtd() + "#" + aprBean.getYtdFycWithoutSgBonus() + "#" + aprBean.getYtdGrowthPer());
					button2.setText("YTD - Paid Business");
					button2.setPostback(str2.toString());
					buttons.add(button2);

					StringBuilder str3 = new StringBuilder();
					InnerButton button3 = new InnerButton();
					str3.append(DRHeaderConstant.MTD_APPLIED_BUSINESS + "|" + aprBean.getMtdAppliedNops() + "#"
							+ aprBean.getMtdAppliedWfyp() + "#" + aprBean.getAplAdjIfypMtd());
					button3.setText("MTD - Applied Business");
					button3.setPostback(str3.toString());
					buttons.add(button3);

					StringBuilder str4 = new StringBuilder();
					InnerButton button4 = new InnerButton();
					str4.append(DRHeaderConstant.EARLY_SUCCESS + "|" + aprBean.getEarlySuccessCases() + "#"
							+ aprBean.getEarlySuccessFyc() + "#" + aprBean.getEarlySuccessCasesShortfall() + "#"
							+ aprBean.getEarlySuccessFycShortfall() + "#" + aprBean.getFinalEarlySuccess());
					button4.setText("Early Success");
					button4.setPostback(str4.toString());
					buttons.add(button4);

					StringBuilder str5 = new StringBuilder();
					InnerButton button5 = new InnerButton();
					str5.append(DRHeaderConstant.PROACTIVE_ON_MTD + "|" + aprBean.getFycActualMtd() + "#"
							+ aprBean.getFycTargetMtd() + "#" + aprBean.getShortInFycMtd() + "#"
							+ aprBean.getProactiveManMonthsMtd() + "#" + aprBean.getProStatusmtd());
					button5.setText("Proactive on MTD");
					button5.setPostback(str5.toString());
					buttons.add(button5);

					StringBuilder str6 = new StringBuilder();
					InnerButton button6 = new InnerButton();
					str6.append(DRHeaderConstant.PROACTIVE_ON_YTD + "|" + aprBean.getFycActualYtd() + "#"
							+ aprBean.getFycYtdTarget() + "#" + aprBean.getShortInFycYtd() + "#"
							+ aprBean.getProStatusYtd());
					button6.setText("Proactive on MTD");
					button6.setPostback(str6.toString());
					buttons.add(button6);

					StringBuilder str7 = new StringBuilder();
					InnerButton button7 = new InnerButton();
					str7.append(DRHeaderConstant.ACTIVITY_ON_YTD_BASIS1 + "|" + aprBean.getPaidCsYtd() + "#"
							+ aprBean.getShortInPaidCase() + "#" + aprBean.getManMonthytd() + "#"
							+ aprBean.getActivityYtdVintage() + "#" + aprBean.getActivityYtdStLevel());
					button7.setText("Activity on YTD basis");
					button7.setPostback(str7.toString());
					buttons.add(button7);

					StringBuilder str8 = new StringBuilder();
					InnerButton button8 = new InnerButton();
					str8.append(DRHeaderConstant.ACTIVITY_ON_YTD_BASIS2 + "|" + aprBean.getActivityYtdLastActiveDate() + "#"
							+ aprBean.getActivityYtdYtdActiveStatus() + "#" + aprBean.getActivityYtdMtdActiveStatus());
					button8.setText("Activity on YTD basis");
					button8.setPostback(str8.toString());
					buttons.add(button8);

					StringBuilder str9 = new StringBuilder();
					InnerButton button9 = new InnerButton();
					str9.append(DRHeaderConstant.Quality_Recruitment + "|" + aprBean.getQrFyc() + "#"
							+ aprBean.getShortfallQrFyc() + "#" + aprBean.getQrQualifyingMonth());
					button9.setText("Quality Recruitment");
					button9.setPostback(str9.toString());
					buttons.add(button9);

					StringBuilder str10 = new StringBuilder();
					InnerButton button10 = new InnerButton();
					str10.append(DRHeaderConstant.nine_In90 + "|" + aprBean.getPaidCase9In90() + "#" + aprBean.getFyc9In90()
					+ "#" + aprBean.getShortInPaidCase9In90() + "#" + aprBean.getShortInFyc9In90() + "#"
					+ aprBean.getNineIn90Month());
					button10.setText("9 in 90");
					button10.setPostback(str10.toString());
					buttons.add(button10);

					StringBuilder str11 = new StringBuilder();
					InnerButton button11 = new InnerButton();
					str11.append(DRHeaderConstant.COMMISSION_DETAILS + "|" + aprBean.getComisionDtlCarerAgtSchmSt() + "#"
							+ aprBean.getFycqtr1() + "#" + aprBean.getFycqtr2() + "#" + aprBean.getFycqtr3() + "#"
							+ aprBean.getFycqtr4());
					button11.setText("Commission Details");
					button11.setPostback(str11.toString());
					buttons.add(button11);

					StringBuilder str12 = new StringBuilder();
					InnerButton button12 = new InnerButton();
					str12.append(DRHeaderConstant.MTD_PROTECTION_UPDATE + "|" + aprBean.getMtdProtectionUpdateNop() + "#"
							+ aprBean.getMtdProtectionUpdateWfyp() + "#" + aprBean.getMtdProtectionUpdateAdjMfyp());
					button12.setText("MTD Protection update");
					button12.setPostback(str12.toString());
					buttons.add(button12);

					StringBuilder str13 = new StringBuilder();
					InnerButton button13 = new InnerButton();
					str13.append(DRHeaderConstant.YTD_PROTECTION_UPDATE + "|" + aprBean.getYtdProtectionUpdateNop() + "#"
							+ aprBean.getYtdProtectionUpdateWfyp() + "#" + aprBean.getYtdProtectionUpdateAdjMfyp());
					button13.setText("YTD Protection Update");
					button13.setPostback(str13.toString());
					buttons.add(button13);

					StringBuilder str14 = new StringBuilder();
					InnerButton button14 = new InnerButton();
					str14.append(DRHeaderConstant.RENEWAL_BUSINESS_UPDATE + "|" + aprBean.getRenewalBusiUpdtCollectible()
					+ "#" + aprBean.getRenewalBusiUpdtCollected() + "#" + aprBean.getRenewalBusiUpdt13mPersis());
					button14.setText("Renewal Business Update");
					button14.setPostback(str14.toString());
					buttons.add(button14);

					InnerButton button15 = new InnerButton();
					button15.setText("Send Email");
					button15.setPostback("Email");
					buttons.add(button15);

					InnerButton button16 = new InnerButton();
					button16.setText("Agent - AgentId");
					button16.setPostback(toBePopulateAgentList);
					buttons.add(button16);

				} else {
					buttons = new ArrayList<InnerButton>();

					StringBuilder str1 = new StringBuilder();
					InnerButton button1 = new InnerButton();
					str1.append(ADMHeaderConstant.MTD + "|" + aprBean.getPaidCasesMtd() + "#" + valueInLacs.getValueInLacs(aprBean.getAdjMfypMtd())
					+ "#" + valueInLacs.getValueInLacs(aprBean.getWeightMfypMtd()) + "#" + valueInLacs.getValueInLacs(aprBean.getFycMtd()) + "#" 
					+ aprBean.getMtdGrowthPer());
					button1.setText("MTD - Paid Business");
					button1.setPostback(str1.toString());
					buttons.add(button1);

					StringBuilder str2 = new StringBuilder();
					InnerButton button2 = new InnerButton();
					str2.append(ADMHeaderConstant.YTD + "|" + aprBean.getYtdPaidCases() + "#" + valueInLacs.getValueInLacs(aprBean.getAdjMfypYtd())
					+ "#" + valueInLacs.getValueInLacs(aprBean.getWeightMfypYtd()) + "#" + valueInLacs.getValueInLacs(aprBean.getYtdFycWithoutSgBonus()) + "#"
					+ aprBean.getYtdGrowthPer());
					button2.setText("YTD - Paid Business");
					button2.setPostback(str2.toString());
					buttons.add(button2);

					StringBuilder str3 = new StringBuilder();
					InnerButton button3 = new InnerButton();
					str3.append(ADMHeaderConstant.MTD_APPLIED_BUSINESS + "|" + aprBean.getMtdAppliedNops() + "#"
							+ valueInLacs.getValueInLacs(aprBean.getMtdAppliedWfyp()) + "#" + valueInLacs.getValueInLacs(aprBean.getAplAdjIfypMtd()));
					button3.setText("MTD - Applied Business");
					button3.setPostback(str3.toString());
					buttons.add(button3);

					StringBuilder str4 = new StringBuilder();
					InnerButton button4 = new InnerButton();
					str4.append(ADMHeaderConstant.EARLY_SUCCESS_AGGENTS_DETAILS + "|" + aprBean.getEarlySuccessCases()
					+ "#" + aprBean.getEarlySuccessSinceInception() + "#" + aprBean.getEarlySuccessCurrentFy() + "#"
					+ aprBean.getEarlySuccessCurrentMonth());
					button4.setText("Early Success Agents Details");
					button4.setPostback(str4.toString());
					buttons.add(button4);

					StringBuilder str5 = new StringBuilder();
					InnerButton button5 = new InnerButton();
					str5.append(ADMHeaderConstant.DETAILS_OF_PROACTIVE_AGENTS + "|" + aprBean.getMtdProactiveAgents() + "#"
							+ aprBean.getYtdProactiveAgents() + "#" + valueInLacs.getValueInLacs(aprBean.getFycShortfall()));
					button5.setText("Details of Proactive Agents");
					button5.setPostback(str5.toString());
					buttons.add(button5);

					StringBuilder str6 = new StringBuilder();
					InnerButton button6 = new InnerButton();
					str6.append(ADMHeaderConstant.ACTIVITY_ON_YTD_BASIS + "|" + aprBean.getActivityTotalMM() + "#"
							+ aprBean.getPaidCsYtd() + "#" + aprBean.getShortInPaidCase() + "#"
							+ aprBean.getActivityMtdActive() + "#" + aprBean.getActivityYtdActive());
					button6.setText("Activity on YTD Basis");
					button6.setPostback(str6.toString());
					buttons.add(button6);

					StringBuilder str7 = new StringBuilder();
					InnerButton button7 = new InnerButton();
					str7.append(ADMHeaderConstant.QUALITY_RECRUITMENT_9IN90_CAREER_AGENT_SCHEME_STATUS + "|"
							+ aprBean.getQrTargetMtd() + "#" + aprBean.getActualQr() + "#"
							+ aprBean.getAgentsQualifiedNineIn90() + "#" + aprBean.getProbableAgents() + "#"
							+ aprBean.getGetGoingAgents());
					button7.setText("Quality Recruitment/ 9 in 90 / Career Agent Scheme Status");
					button7.setPostback(str7.toString());
					buttons.add(button7);

					StringBuilder str8 = new StringBuilder();
					InnerButton button8 = new InnerButton();
					str8.append(ADMHeaderConstant.COMMISSION_DETAILS_OF_AGENTS + "|" + valueInLacs.getValueInLacs(aprBean.getFycqtr1()) + "#"
							+ valueInLacs.getValueInLacs(aprBean.getFycqtr2()) + "#" + valueInLacs.getValueInLacs(aprBean.getFycqtr3()) + "#" 
							+ valueInLacs.getValueInLacs(aprBean.getFycqtr4()) + "#" + valueInLacs.getValueInLacs(aprBean.getYtdFyc()));
					button8.setText("Commission Details of Agents");
					button8.setPostback(str8.toString());
					buttons.add(button8);

					StringBuilder str9 = new StringBuilder();
					InnerButton button9 = new InnerButton();
					str9.append(ADMHeaderConstant.MTD_PROTECTION_UPDATE + "|" + aprBean.getMtdProtectionUpdateNop() + "#"
							+ valueInLacs.getValueInLacs(aprBean.getMtdProtectionUpdateWfyp()) + "#" + valueInLacs.getValueInLacs(aprBean.getMtdProtectionUpdateAdjMfyp()));
					button9.setText("MTD Protection Update");
					button9.setPostback(str9.toString());
					buttons.add(button9);

					StringBuilder str10 = new StringBuilder();
					InnerButton button10 = new InnerButton();
					str10.append(ADMHeaderConstant.YTD_PROTECTION_UPDATE + "|" + aprBean.getYtdProtectionUpdateNop() + "#"
							+ valueInLacs.getValueInLacs(aprBean.getYtdProtectionUpdateWfyp()) + "#" + valueInLacs.getValueInLacs(aprBean.getYtdProtectionUpdateAdjMfyp()));
					button10.setText("YTD Protection Update");
					button10.setPostback(str10.toString());
					buttons.add(button10);

					StringBuilder str11 = new StringBuilder();
					InnerButton button11 = new InnerButton();
					str11.append(ADMHeaderConstant.RENEWAL_BUSINESS_UPDATE + "|" + valueInLacs.getValueInLacs(aprBean.getRenewalBusiUpdtCollectible())
					+ "#" + valueInLacs.getValueInLacs(aprBean.getRenewalBusiUpdtCollected()) + "#" + aprBean.getRenewalBusiUpdt13mPersis());
					button11.setText("Renewal Business Update");
					button11.setPostback(str11.toString());
					buttons.add(button11);

					InnerButton button12 = new InnerButton();
					button12.setText("Send Email");
					button12.setPostback("Email");
					buttons.add(button12);

					InnerButton button13 = new InnerButton();
					button13.setText("Agent - AgentId");
					button13.setPostback(toBePopulateAgentList);
					buttons.add(button13);

				}
			}else{
				speech="There is some communication glitch, please try again.";
			}
		}

		break;

		case "agentList": {
			finalresponse = aprApiCall.getAprData(user_ssoid, agentId, "NO");

			jSONObject = new JSONObject(finalresponse);

			String allAgentCode = jSONObject.getJSONObject("payload").getJSONObject("aprDesignationResponse").get("designationCode").toString();

			String[] arrayAgentCode = allAgentCode.split(",");

			for (int i = 0; i < arrayAgentCode.length; i++) {
				if (arrayAgentCode[i].equalsIgnoreCase(agentCode))
					belowAgent = true;
			}
			aprBean = apr.getApr(jSONObject);

			if (belowAgent) {
				buttons = new ArrayList<InnerButton>();

				StringBuilder str1 = new StringBuilder();
				InnerButton button1 = new InnerButton();
				str1.append(DRHeaderConstant.MTD + "|" + aprBean.getPaidCasesMtd() + "#" + aprBean.getAdjMfypMtd() + "#"
						+ aprBean.getWeightMfypMtd() + "#" + aprBean.getFycMtd() + "#" + aprBean.getMtdGrowthPer());
				button1.setText("MTD - Paid Business");
				button1.setPostback(str1.toString());
				buttons.add(button1);

				StringBuilder str2 = new StringBuilder();
				InnerButton button2 = new InnerButton();
				str2.append(DRHeaderConstant.YTD + "|" + aprBean.getYtdPaidCases() + "#" + aprBean.getAdjMfypYtd() + "#"
						+ aprBean.getWeightMfypYtd() + "#" + aprBean.getYtdFycWithoutSgBonus() + "#" + aprBean.getYtdGrowthPer());
				button2.setText("YTD - Paid Business");
				button2.setPostback(str2.toString());
				buttons.add(button2);

				StringBuilder str3 = new StringBuilder();
				InnerButton button3 = new InnerButton();
				str3.append(DRHeaderConstant.MTD_APPLIED_BUSINESS + "|" + aprBean.getMtdAppliedNops() + "#"
						+ aprBean.getMtdAppliedWfyp() + "#" + aprBean.getAplAdjIfypMtd());
				button3.setText("MTD - Applied Business");
				button3.setPostback(str3.toString());
				buttons.add(button3);

				StringBuilder str4 = new StringBuilder();
				InnerButton button4 = new InnerButton();
				str4.append(DRHeaderConstant.EARLY_SUCCESS + "|" + aprBean.getEarlySuccessCases() + "#"
						+ aprBean.getEarlySuccessFyc() + "#" + aprBean.getEarlySuccessCasesShortfall() + "#"
						+ aprBean.getEarlySuccessFycShortfall() + "#" + aprBean.getFinalEarlySuccess());
				button4.setText("Early Success");
				button4.setPostback(str4.toString());
				buttons.add(button4);

				StringBuilder str5 = new StringBuilder();
				InnerButton button5 = new InnerButton();
				str5.append(DRHeaderConstant.PROACTIVE_ON_MTD + "|" + aprBean.getFycActualMtd() + "#"
						+ aprBean.getFycTargetMtd() + "#" + aprBean.getShortInFycMtd() + "#"
						+ aprBean.getProactiveManMonthsMtd() + "#" + aprBean.getProStatusmtd());
				button5.setText("Proactive on MTD");
				button5.setPostback(str5.toString());
				buttons.add(button5);

				StringBuilder str6 = new StringBuilder();
				InnerButton button6 = new InnerButton();
				str6.append(DRHeaderConstant.PROACTIVE_ON_YTD + "|" + aprBean.getFycActualYtd() + "#"
						+ aprBean.getFycYtdTarget() + "#" + aprBean.getShortInFycYtd() + "#"
						+ aprBean.getProStatusYtd());
				button6.setText("Proactive on YTD");
				button6.setPostback(str6.toString());
				buttons.add(button6);

				StringBuilder str7 = new StringBuilder();
				InnerButton button7 = new InnerButton();
				str7.append(DRHeaderConstant.ACTIVITY_ON_YTD_BASIS1 + "|" + aprBean.getPaidCsYtd() + "#"
						+ aprBean.getShortInPaidCase() + "#" + aprBean.getManMonthytd() + "#"
						+ aprBean.getActivityYtdVintage() + "#" + aprBean.getActivityYtdStLevel());
				button7.setText("Activity on YTD basis");
				button7.setPostback(str7.toString());
				buttons.add(button7);

				StringBuilder str8 = new StringBuilder();
				InnerButton button8 = new InnerButton();
				str8.append(DRHeaderConstant.ACTIVITY_ON_YTD_BASIS2 + "|" + aprBean.getActivityYtdLastActiveDate() + "#"
						+ aprBean.getActivityYtdYtdActiveStatus() + "#" + aprBean.getActivityYtdMtdActiveStatus());
				button8.setText("Activity on YTD basis");
				button8.setPostback(str8.toString());
				buttons.add(button8);

				StringBuilder str9 = new StringBuilder();
				InnerButton button9 = new InnerButton();
				str9.append(DRHeaderConstant.Quality_Recruitment + "|" + aprBean.getQrFyc() + "#"
						+ aprBean.getShortfallQrFyc() + "#" + aprBean.getQrQualifyingMonth());
				button9.setText("Quality Recruitment");
				button9.setPostback(str9.toString());
				buttons.add(button9);

				StringBuilder str10 = new StringBuilder();
				InnerButton button10 = new InnerButton();
				str10.append(DRHeaderConstant.nine_In90 + "|" + aprBean.getPaidCase9In90() + "#" + aprBean.getFyc9In90()
				+ "#" + aprBean.getShortInPaidCase9In90() + "#" + aprBean.getShortInFyc9In90() + "#"
				+ aprBean.getNineIn90Month());
				button10.setText("9 in 90");
				button10.setPostback(str10.toString());
				buttons.add(button10);

				StringBuilder str11 = new StringBuilder();
				InnerButton button11 = new InnerButton();
				str11.append(DRHeaderConstant.COMMISSION_DETAILS + "|" + aprBean.getComisionDtlCarerAgtSchmSt() + "#"
						+ aprBean.getFycqtr1() + "#" + aprBean.getFycqtr2() + "#" + aprBean.getFycqtr3() + "#"
						+ aprBean.getFycqtr4());
				button11.setText("Commission Details");
				button11.setPostback(str11.toString());
				buttons.add(button11);

				StringBuilder str12 = new StringBuilder();
				InnerButton button12 = new InnerButton();
				str12.append(DRHeaderConstant.MTD_PROTECTION_UPDATE + "|" + aprBean.getMtdProtectionUpdateNop() + "#"
						+ aprBean.getMtdProtectionUpdateWfyp() + "#" + aprBean.getMtdProtectionUpdateAdjMfyp());
				button12.setText("MTD Protection update");
				button12.setPostback(str12.toString());
				buttons.add(button12);

				StringBuilder str13 = new StringBuilder();
				InnerButton button13 = new InnerButton();
				str13.append(DRHeaderConstant.YTD_PROTECTION_UPDATE + "|" + aprBean.getYtdProtectionUpdateNop() + "#"
						+ aprBean.getYtdProtectionUpdateWfyp() + "#" + aprBean.getYtdProtectionUpdateAdjMfyp());
				button13.setText("YTD Protection Update");
				button13.setPostback(str13.toString());
				buttons.add(button13);

				StringBuilder str14 = new StringBuilder();
				InnerButton button14 = new InnerButton();
				str14.append(DRHeaderConstant.RENEWAL_BUSINESS_UPDATE + "|" + aprBean.getRenewalBusiUpdtCollectible()
				+ "#" + aprBean.getRenewalBusiUpdtCollected() + "#" + aprBean.getRenewalBusiUpdt13mPersis());
				button14.setText("Renewal Business Update");
				button14.setPostback(str14.toString());
				buttons.add(button14);

				InnerButton button15 = new InnerButton();
				button15.setText("Send Email");
				button15.setPostback("Email");
				buttons.add(button15);
			} else {
				buttons = new ArrayList<InnerButton>();

				StringBuilder str1 = new StringBuilder();
				InnerButton button1 = new InnerButton();
				str1.append(ADMHeaderConstant.MTD + "|" + aprBean.getPaidCasesMtd() + "#" + valueInLacs.getValueInLacs(aprBean.getAdjMfypMtd())
				+ "#" + valueInLacs.getValueInLacs(aprBean.getWeightMfypMtd()) + "#" + valueInLacs.getValueInLacs(aprBean.getFycMtd()) + "#"
				+ aprBean.getMtdGrowthPer());
				button1.setText("MTD - Paid Business");
				button1.setPostback(str1.toString());
				buttons.add(button1);

				StringBuilder str2 = new StringBuilder();
				InnerButton button2 = new InnerButton();
				str2.append(ADMHeaderConstant.YTD + "|" + aprBean.getYtdPaidCases() + "#" + valueInLacs.getValueInLacs(aprBean.getAdjMfypYtd())
				+ "#" + valueInLacs.getValueInLacs(aprBean.getWeightMfypYtd()) + "#" + valueInLacs.getValueInLacs(aprBean.getYtdFycWithoutSgBonus()) + "#"
				+ aprBean.getYtdGrowthPer());
				button2.setText("YTD - Paid Business");
				button2.setPostback(str2.toString());
				buttons.add(button2);

				StringBuilder str3 = new StringBuilder();
				InnerButton button3 = new InnerButton();
				str3.append(ADMHeaderConstant.MTD_APPLIED_BUSINESS + "|" + aprBean.getMtdAppliedNops() + "#"
						+ valueInLacs.getValueInLacs(aprBean.getMtdAppliedWfyp()) + "#" + valueInLacs.getValueInLacs(aprBean.getAplAdjIfypMtd()));
				button3.setText("MTD - Applied Business");
				button3.setPostback(str3.toString());
				buttons.add(button3);

				StringBuilder str4 = new StringBuilder();
				InnerButton button4 = new InnerButton();
				str4.append(ADMHeaderConstant.EARLY_SUCCESS_AGGENTS_DETAILS + "|" + aprBean.getEarlySuccessCases()
				+ "#" + aprBean.getEarlySuccessSinceInception() + "#" + aprBean.getEarlySuccessCurrentFy() + "#"
				+ aprBean.getEarlySuccessCurrentMonth());
				button4.setText("Early Success Agents Details");
				button4.setPostback(str4.toString());
				buttons.add(button4);

				StringBuilder str5 = new StringBuilder();
				InnerButton button5 = new InnerButton();
				str5.append(ADMHeaderConstant.DETAILS_OF_PROACTIVE_AGENTS + "|" + aprBean.getMtdProactiveAgents() + "#"
						+ aprBean.getYtdProactiveAgents() + "#" + valueInLacs.getValueInLacs(aprBean.getFycShortfall()));
				button5.setText("Details of Proactive Agents");
				button5.setPostback(str5.toString());
				buttons.add(button5);

				StringBuilder str6 = new StringBuilder();
				InnerButton button6 = new InnerButton();
				str6.append(ADMHeaderConstant.ACTIVITY_ON_YTD_BASIS + "|" + aprBean.getActivityTotalMM() + "#"
						+ aprBean.getPaidCsYtd() + "#" + aprBean.getShortInPaidCase() + "#"
						+ aprBean.getActivityMtdActive() + "#" + aprBean.getActivityYtdActive());
				button6.setText("Activity on YTD Basis");
				button6.setPostback(str6.toString());
				buttons.add(button6);

				StringBuilder str7 = new StringBuilder();
				InnerButton button7 = new InnerButton();
				str7.append(ADMHeaderConstant.QUALITY_RECRUITMENT_9IN90_CAREER_AGENT_SCHEME_STATUS + "|"
						+ aprBean.getQrTargetMtd() + "#" + aprBean.getActualQr() + "#"
						+ aprBean.getAgentsQualifiedNineIn90() + "#" + aprBean.getProbableAgents() + "#"
						+ aprBean.getGetGoingAgents());
				button7.setText("Quality Recruitment/ 9 in 90 / Career Agent Scheme Status");
				button7.setPostback(str7.toString());
				buttons.add(button7);

				StringBuilder str8 = new StringBuilder();
				InnerButton button8 = new InnerButton();
				str8.append(ADMHeaderConstant.COMMISSION_DETAILS_OF_AGENTS + "|" + valueInLacs.getValueInLacs(aprBean.getFycqtr1()) + "#"
						+ valueInLacs.getValueInLacs(aprBean.getFycqtr2()) + "#" + valueInLacs.getValueInLacs(aprBean.getFycqtr3()) + "#" 
						+ valueInLacs.getValueInLacs(aprBean.getFycqtr4()) + "#" + valueInLacs.getValueInLacs(aprBean.getYtdFyc()));
				button8.setText("Commission Details of Agents");
				button8.setPostback(str8.toString());
				buttons.add(button8);

				StringBuilder str9 = new StringBuilder();
				InnerButton button9 = new InnerButton();
				str9.append(ADMHeaderConstant.MTD_PROTECTION_UPDATE + "|" + aprBean.getMtdProtectionUpdateNop() + "#"
						+ valueInLacs.getValueInLacs(aprBean.getMtdProtectionUpdateWfyp()) + "#" + valueInLacs.getValueInLacs(aprBean.getMtdProtectionUpdateAdjMfyp()));
				button9.setText("MTD Protection Update");
				button9.setPostback(str9.toString());
				buttons.add(button9);

				StringBuilder str10 = new StringBuilder();
				InnerButton button10 = new InnerButton();
				str10.append(ADMHeaderConstant.YTD_PROTECTION_UPDATE + "|" + aprBean.getYtdProtectionUpdateNop() + "#"
						+ valueInLacs.getValueInLacs(aprBean.getYtdProtectionUpdateWfyp()) + "#" + valueInLacs.getValueInLacs(aprBean.getYtdProtectionUpdateAdjMfyp()));
				button10.setText("YTD Protection Update");
				button10.setPostback(str10.toString());
				buttons.add(button10);

				StringBuilder str11 = new StringBuilder();
				InnerButton button11 = new InnerButton();
				str11.append(ADMHeaderConstant.RENEWAL_BUSINESS_UPDATE + "|" + valueInLacs.getValueInLacs(aprBean.getRenewalBusiUpdtCollectible())
				+ "#" + valueInLacs.getValueInLacs(aprBean.getRenewalBusiUpdtCollected()) + "#" + aprBean.getRenewalBusiUpdt13mPersis());
				button11.setText("Renewal Business Update");
				button11.setPostback(str11.toString());
				buttons.add(button11);

				InnerButton button12 = new InnerButton();
				button12.setText("Send Email");
				button12.setPostback("Email");
				buttons.add(button12);
			}
		}
		break;
		case "EMAIL":
		{
			callMailAction(user_ssoid, agentId, emailId,agentName,sessionId);

			if(true)
			{
				speech="Excel has been sent to you on your official email ID.";
				logger.info("Mail sent successfully :: sessionId :: "+sessionId);
			}

		}
		}

		fb.setButtons(buttons);
		fb.setTitle("MLIChatBot");
		fb.setPlatform("API.AI");
		fb.setType("Chatbot");
		fb.setImageUrl("BOT");
		innerData.setFacebook(fb);
		WebhookResponse responseObj = new WebhookResponse(speech, speech, innerData);
		return responseObj;
	}

	private void callMailAction(String user_ssoid,String agentId,String emailId,String agentName,String sessionId) {
		try{
			Thread t =new Thread(){

				public void run(){	
					logger.info("Start thread executing for mail ");
					String aprResponse = aprApiCall.getAprData(user_ssoid, agentId, "YES");

					JSONObject obj = new JSONObject(aprResponse);
					String status = obj.getJSONObject("errorInfo").get("status").toString();

					if("SUCCESS".equalsIgnoreCase(status)){

						Map<String, Object[] > newMap = mailReportJson.getMailReportData(sessionId, obj);

						String fileName=sessionId+".xlsx";
						String workingDir =  res.getString("workingDirectory");
						logger.info("Working dir ++++ "+workingDir);
						logger.info("Path =+++=== "+workingDir+File.separator+fileName);
						String realFile=workingDir+File.separator+fileName;	

						byte[] bytedata=sendMailServiceImpl.convertPdfToByteArray(workingDir+File.separator+fileName);
						String filedata=Base64.encode(bytedata);
						Boolean mailStatus =  sendMailServiceImpl.sendMail(filedata, emailId, agentName);
						logger.info("Mail sent successfully");

						deleteFile(realFile);
						logger.info("End thread executing for mail sessionId");
					}
				}
			};
			t.start();
		}


		catch(Exception ex){
			logger.error("Exception in APR service impl :: sessionId :: "+sessionId +" :: "+ex);
		}

	}

	private void deleteFile(String realFile) {
		try{
			if (new File(realFile).exists())
			{
				new File(realFile).delete();
			}
		}
		catch(Exception ex)
		{
			logger.error("Exception in deleting file from location");
		}

	}
}
