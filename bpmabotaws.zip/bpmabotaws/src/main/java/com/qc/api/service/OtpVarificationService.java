package com.qc.api.service;

import java.util.Map;

public interface OtpVarificationService 
{
	public Map<String, Map<String, String>> OTPVarification(String sessionId, String phoneno, String agentName,
			String ssoId,String actionperformed, Map<String, Map<String, String>> sessionMapcontainssoinfo, String agentId, String emailId);
}
