package com.qc.api.service;

import com.qc.api.response.WebhookResponse;

public interface AprService
{
	public WebhookResponse getAPrData(String actionperformed, String user_ssoid, String agentId, String emailId, String agentCode, String agentName, String sessionId);
}
