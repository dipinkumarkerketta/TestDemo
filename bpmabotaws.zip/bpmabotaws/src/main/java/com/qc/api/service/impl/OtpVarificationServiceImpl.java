package com.qc.api.service.impl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.UUID;

import javax.net.ssl.HttpsURLConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.service.BpmaBotHelperService;
import com.qc.api.service.OtpVarificationService;
import com.qc.utils.XTrustProvider;

@Service
public class OtpVarificationServiceImpl implements OtpVarificationService
{
	private static Logger logger = LogManager.getLogger(OtpVarificationServiceImpl.class);
	
	@Autowired private BpmaBotHelperService bpmaBotHelperService;
	
	public Map<String, Map<String, String>> OTPVarification(String sessionId, String phoneno, String agentName,
			String ssoId,String actionperformed,Map<String, Map<String, String>> sessionMapcontainssoinfo, String agentId, String emailId)
	{
		logger.info("START :- Inside : - OTPVarification :- SSOID:- "+ssoId);
		HttpURLConnection conn = null;
		String output = new String();
		String DevMode = "N", status = "", randomotp = "";
		JSONObject object=null;
		StringBuilder result = new StringBuilder();
		Map<String, String> otpsession = new HashMap<String, String>();
		ResourceBundle res = ResourceBundle.getBundle("com.qc.bot.resources.application");
		try {
			XTrustProvider trustProvider = new XTrustProvider();
			trustProvider.install();
			StringBuilder requestdata = new StringBuilder();
			//UAT
			String serviceurl = res.getString("servicesendotp");
			/*//PROD
			String serviceurl = res.getString("servicesendprodotp");*/

			String otpAppAccId = res.getString("otpAppAccId");
			String otpAppAccPass = res.getString("otpAppAccPass");
			URL url = new URL(serviceurl);

			if(DevMode!=null && !"".equalsIgnoreCase(DevMode) && "Y".equalsIgnoreCase(DevMode))
			{
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			} else {
				conn = (HttpURLConnection) url.openConnection();
			}
			UUID uniqueId2 = UUID.randomUUID();
			randomotp = bpmaBotHelperService.randomNumber();
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			//UAT
			requestdata.append("	{	");
			requestdata.append("	   \"MliSmsService\": {	");
			requestdata.append("	      \"requestHeader\": {	");
			requestdata.append("	         \"generalConsumerInformation\": {	");
			requestdata.append("	            \"messageVersion\": \"1.0\",	");
			requestdata.append("	            \"consumerId\": \"BPMA_BOT\",	");
			requestdata.append("	            \"correlationId\": \""+uniqueId2+"\"	");
			requestdata.append("	         }	");
			requestdata.append("	      },	");
			requestdata.append("	      \"requestBody\": {	");
			requestdata.append("	         \"appAccId\": \""+otpAppAccId+"\",	");
			requestdata.append("	         \"appAccPass\": \""+otpAppAccPass+"\",	");
			requestdata.append("	         \"appId\": \"MAXLIT\",	");
			requestdata.append("	         \"msgTo\": \"" + phoneno + "\",	");
			requestdata.append("	         \"msgText\": \"Your Maxlife Assistant OTP is:"+randomotp+"\"	");
			requestdata.append("	      }	");
			requestdata.append("	   }	");
			requestdata.append("	}	");
			logger.info("OutputStream call : START ::: OTPVarification :- SSOID:- "+ssoId);
			logger.info(" OTP :- "+randomotp );
			OutputStreamWriter writer3 = new OutputStreamWriter(conn.getOutputStream());
			writer3.write(requestdata.toString());
			writer3.flush();
			try {
				writer3.close();
			} catch (Exception e1)
			{}
			logger.info("OutputStream call : END ::: OTPVarification :- SSOID:- "+ssoId);
			int apiResponseCode3 = conn.getResponseCode();
			logger.info("Response Code :- OTPVarification "+ apiResponseCode3+ " SSOID:- "+ssoId);
			if (apiResponseCode3 == 200 || apiResponseCode3 == 201) 
			{
				if(!"nb.validate".equalsIgnoreCase(actionperformed))
				{
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
					while ((output = br.readLine()) != null) {
						result.append(output);
					}
					conn.disconnect();
					br.close();
					object = new JSONObject(result.toString());
				}
				try {
					if(!"nb.validate".equalsIgnoreCase(actionperformed))
					{
						status = object.getJSONObject("MliSmsServiceResponse").getJSONObject("responseHeader")
								.getJSONObject("generalResponse").get("status") + "";

						/*Calendar cal = Calendar.getInstance();
						DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
						System.out.println(dateFormat.format(cal.getTime()));*/

						DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
						LocalDateTime now = LocalDateTime.now();

						otpsession.put("Status", status);
						otpsession.put("AgentName", agentName);
						otpsession.put("otp", randomotp);
						otpsession.put("SoaStatus", "success");
						otpsession.put("validSSOID", ssoId);
						otpsession.put("channel", "MLI");
						otpsession.put("period", "MTD");
						otpsession.put("agentId", agentId);
						otpsession.put("emailId", emailId);
						otpsession.put("timeStamp", dateFormat.format(now));
						sessionMapcontainssoinfo.put(sessionId, otpsession);
					}
					else
					{
						otpsession.put("SoaStatus", "partial_content");
						otpsession.put("validSSOID", ssoId);
						otpsession.put("AgentName", agentName);
						sessionMapcontainssoinfo.put(sessionId, otpsession);
					}
				} catch (Exception e) 
				{
					logger.info(e);
				}
				logger.info("END : OutSide:- OTPVarification :- SSOID:- "+ssoId);
			} else
			{
				otpsession.put("SoaStatus", "Failure_API_2");
				sessionMapcontainssoinfo.put(sessionId, otpsession);
				logger.info("Exception Occoured while calling OTP Varification API Call");
			}
		} catch (Exception ex) 
		{
			otpsession.put("SoaStatus", "Failure_API_2");
			sessionMapcontainssoinfo.put(sessionId, otpsession);
			logger.info("Exception Occoured while calling OTP Varification API Call :: "+ex);
		}

		return sessionMapcontainssoinfo;
	}
}
