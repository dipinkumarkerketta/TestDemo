package com.qc.button;

import com.qc.common.InnerData;

public interface Button {
	public InnerData getButtonApr();
}
