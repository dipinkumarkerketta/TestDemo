package com.qc.service.messageimpl;

public class Recruitmentpercentage {

	public static String recruitmentPercentageIntent(String channel, String period, String user_region, String user_circle, String userzone , String real_tim_timstamp,
			String achiev_mtd_recruitment, String achiev_ytd_recruitment, String subchannel,
			String user_clusters, String user_go, String superZone, String keyMarket)

	{
		String finalresponse="";
		if("MLI".equalsIgnoreCase(channel))
		{channel="";}
		if("Monthly".equalsIgnoreCase(period))
		{period="";}
		else
		{
			if("FTD".equalsIgnoreCase(period))
			{
				period="MTD";
			}else
			{
				period=period.toUpperCase();
			}
		}
		if(!"".equalsIgnoreCase(user_circle))
		{
			user_region="Circle "+user_circle;
		}
		if(!"".equalsIgnoreCase(user_go))
		{
			user_clusters="Office "+user_go;
		}
		if(!"".equalsIgnoreCase(subchannel))
		{
        	 	channel = subchannel;
		}
		if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(superZone)&& "".equalsIgnoreCase(keyMarket))
		{
			finalresponse= "MLI recruitment acheivement MTD: "+achiev_mtd_recruitment+" % YTD "+achiev_ytd_recruitment+" % till "+real_tim_timstamp+
					". If you want to see the channel wise business numbers, please specify the same.";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(superZone)&& "".equalsIgnoreCase(keyMarket))
		{
			finalresponse= channel+" recruitment acheivement MTD: "+achiev_mtd_recruitment+" % YTD "+achiev_ytd_recruitment+" % till "+real_tim_timstamp+
					". If you want to see the Zone/Region wise business numbers, please specify the same.";
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
		{
			finalresponse= superZone+" recruitment acheivement MTD: "+achiev_mtd_recruitment+"% YTD "+achiev_ytd_recruitment+" % till "+real_tim_timstamp+
					". If you want to see the region wise business numbers, please specify the same.";
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(keyMarket))
		{
			finalresponse= "Zone " +userzone+" recruitment acheivement MTD: "+achiev_mtd_recruitment+"% YTD "+achiev_ytd_recruitment+" % till "+real_tim_timstamp+
					". If you want to see the region wise business numbers, please specify the same.";
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(keyMarket)  && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
		{
			finalresponse= "KM "+keyMarket+" recruitment acheivement MTD: "+achiev_mtd_recruitment+"% YTD "+achiev_ytd_recruitment+" % till "+real_tim_timstamp+
					". If you want to see the region wise business numbers, please specify the same.";
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
		{
			finalresponse= ""+user_region+" recruitment acheivement MTD: "+achiev_mtd_recruitment+" % YTD "+achiev_ytd_recruitment+" % till "+real_tim_timstamp+
					". If you want to see the region wise business numbers, please specify the same.";
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(period)&& !"".equalsIgnoreCase(user_clusters))
		{
			finalresponse= ""+user_clusters+" recruitment acheivement MTD: "+achiev_mtd_recruitment+" % YTD "+achiev_ytd_recruitment+" % till "+real_tim_timstamp+
					".";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && !"".equalsIgnoreCase(user_clusters) 
			&& "".equalsIgnoreCase(period))
		{
			finalresponse= ""+user_clusters+" recruitment acheivement MTD: "+achiev_mtd_recruitment+" % YTD "+achiev_ytd_recruitment+" % till "+real_tim_timstamp+
					".";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(period)&& !"".equalsIgnoreCase(user_clusters))
		{
			finalresponse= ""+user_clusters+" recruitment acheivement MTD: "+achiev_mtd_recruitment+" % YTD "+achiev_ytd_recruitment+" % till "+real_tim_timstamp+
					".";
		}
				else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
		{
			finalresponse= ""+user_region+" recruitment acheivement MTD: "+achiev_mtd_recruitment+" % YTD "+achiev_ytd_recruitment+" % till "+real_tim_timstamp+
					". If you want to see the region wise business numbers, please specify the same.";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && !"".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(superZone))
		{
			if("YTD".equalsIgnoreCase(period)){
				finalresponse= channel+" channel recruitment acheivement "+period+" : "+achiev_ytd_recruitment+" % till "+real_tim_timstamp+
						". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}else
			{
				finalresponse= channel+" channel recruitment acheivement "+period+" : "+achiev_mtd_recruitment+" % till "+real_tim_timstamp+
						". If you want to see the Zone/Region wise business numbers, please specify the same.";	
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) && !"".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
		{
			if("YTD".equalsIgnoreCase(period)){
				finalresponse= superZone+" recruitment acheivement " +period+" : "+achiev_ytd_recruitment+" % till " +real_tim_timstamp+
						". If you want to see the region wise business numbers please specify the same.";
			}
			else
			{
				finalresponse= superZone+" recruitment acheivement " +period+" : "+achiev_mtd_recruitment+" % till " +real_tim_timstamp+
						". If you want to see the region wise business numbers please specify the same.";	
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) && !"".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
		{
			if("YTD".equalsIgnoreCase(period)){
				finalresponse= "KM "+keyMarket+" recruitment acheivement " +period+" : "+achiev_ytd_recruitment+" % till " +real_tim_timstamp+
						". If you want to see the region wise business numbers please specify the same.";
			}
			else
			{
				finalresponse= "KM "+keyMarket+" recruitment acheivement " +period+" : "+achiev_mtd_recruitment+" % till " +real_tim_timstamp+
						". If you want to see the region wise business numbers please specify the same.";	
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && !"".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(keyMarket))
		{
			if("YTD".equalsIgnoreCase(period)){
				finalresponse= "Zone "+userzone+" recruitment acheivement " +period+" : "+achiev_ytd_recruitment+" % till " +real_tim_timstamp+
						". If you want to see the region wise business numbers please specify the same.";
			}
			else
			{
				finalresponse= "Zone "+userzone+" recruitment acheivement " +period+" : "+achiev_mtd_recruitment+" % till " +real_tim_timstamp+
						". If you want to see the region wise business numbers please specify the same.";	
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && !"".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
		{
			if("YTD".equalsIgnoreCase(period)){
				finalresponse= ""+user_region+" recruitment acheivement " +period+" : "+achiev_ytd_recruitment+" % till " +real_tim_timstamp+
						". If you want to see the region wise business numbers please specify the same.";
			}else
			{
				finalresponse= ""+user_region+" recruitment acheivement " +period+" : "+achiev_mtd_recruitment+" % till " +real_tim_timstamp+
						". If you want to see the region wise business numbers please specify the same.";	
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && !"".equalsIgnoreCase(period)&& !"".equalsIgnoreCase(user_clusters))
		{
			if("YTD".equalsIgnoreCase(period)){
				finalresponse= ""+user_clusters+" recruitment acheivement " +period+" : "+achiev_ytd_recruitment+" % till " +real_tim_timstamp+
						".";
			}else
			{
				finalresponse= ""+user_clusters+" recruitment acheivement " +period+" : "+achiev_mtd_recruitment+" % till " +real_tim_timstamp+
						".";	
			}
		}
		/*---added by bhavneet*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && !"".equalsIgnoreCase(period)&& !"".equalsIgnoreCase(user_clusters))
		{
			if("YTD".equalsIgnoreCase(period)){
				finalresponse= ""+user_clusters+" recruitment acheivement " +period+" : "+achiev_ytd_recruitment+" % till " +real_tim_timstamp+
						".";
			}else
			{
				finalresponse= ""+user_clusters+" recruitment acheivement " +period+" : "+achiev_mtd_recruitment+" % till " +real_tim_timstamp+
						".";	
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && !"".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters))
		{
			if("YTD".equalsIgnoreCase(period)){
				finalresponse= ""+user_region+" recruitment acheivement " +period+" : "+achiev_ytd_recruitment+" % till " +real_tim_timstamp+
						". If you want to see the region wise business numbers please specify the same.";
			}else
			{
				finalresponse= ""+user_region+" recruitment acheivement " +period+" : "+achiev_mtd_recruitment+" % till " +real_tim_timstamp+
						". If you want to see the region wise business numbers please specify the same.";	
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && !"".equalsIgnoreCase(period)&& !"".equalsIgnoreCase(user_clusters))
		{
			if("YTD".equalsIgnoreCase(period)){
				finalresponse= ""+user_clusters+" recruitment acheivement " +period+" : "+achiev_ytd_recruitment+" % till " +real_tim_timstamp+
						".";
			}else
			{
				finalresponse= ""+user_clusters+" recruitment acheivement " +period+" : "+achiev_mtd_recruitment+" % till " +real_tim_timstamp+
						".";	
			}
		}
		else
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "MLI recruitment acheivement " +period+" : "+achiev_ytd_recruitment+" % till " +real_tim_timstamp+
						". If you want to see the channel wise business numbers please specify the same.";
			}else
			{
				finalresponse= "MLI recruitment acheivement " +period+" : "+achiev_mtd_recruitment+" % till " +real_tim_timstamp+
						". If you want to see the channel wise business numbers please specify the same.";	
			}
		}
	
		return finalresponse.toString();
	}
}