package com.qc.service.messageimpl;

import com.qc.jsonImpl.NatHybPenetration;

public class Penetration 
{
	public static String penetrationIntent(String period, String productType, String source, String msgChannel, 
			String ul_penet_mtd_afyp, String mtd_inforced_afyp, String ul_penet_mtd_pol_cnt, 
			String mtd_inforced_count, String trad_penet_mtd_afyp, String trad_penet_mtd_pol_cnt, 
			String protec_penet_mtd_afyp, String protec_penet_mtd_pol_cnt, String ul_penet_ytd_afyp,
			String ytd_inforced_afyp, String ul_penet_ytd_pol_cnt, String ytd_inforced_count,
			String trad_penet_ytd_afyp, String trad_penet_ytd_pol_cnt, String protec_penet_ytd_afyp,
			String protec_penet_ytd_pol_cnt, String LacsCr)
	{
		String finalresponse="";
		if(!"Monthly".equalsIgnoreCase(period))
		{
			period=period.toUpperCase();
		}
		if("FTD".equalsIgnoreCase(period))
		{
			period="YTD";
		}
		if("Monthly".equalsIgnoreCase(period) || "".equalsIgnoreCase(period) || "MTD".equalsIgnoreCase(period)||"MONTH".equalsIgnoreCase(period))
		{
			if("ULIP".equalsIgnoreCase(productType))
			{
				if("google".equalsIgnoreCase(source))
				{
					finalresponse=msgChannel+" "+productType+" Penetration is "+ul_penet_mtd_afyp+" % of "+mtd_inforced_afyp
							+" " + LacsCr +" of paid Business and "+ul_penet_mtd_pol_cnt+" % of "+mtd_inforced_count+" Policies"
							+ "  issued in this month ";	
				}
				else
				{
					if("Internet Sales".equalsIgnoreCase(msgChannel))
					{
						finalresponse="Native ecomm ULIP Penetration is "+NatHybPenetration.penetrationBean.getNt_ul_penet_mtd_afyp()+" % of "+NatHybPenetration.penetrationBean.getNt_mtd_inforced_afyp()+" " + LacsCr
								+ "of paid Business AFYP MONTHLY and "+NatHybPenetration.penetrationBean.getNt_ul_penet_mtd_pol_cnt()+" % of "+NatHybPenetration.penetrationBean.getNt_mtd_inforced_count()
								+" Policies issued on MONTHLY basis. \n\n "
								+ "Hybrid ecomm ULIP Penetration is "+NatHybPenetration.penetrationBean.getHy_ul_penet_mtd_afyp()+" % of "+NatHybPenetration.penetrationBean.getHy_mtd_inforced_afyp()
								+" " + LacsCr +" of paid Business AFYP MONTHLY and "+NatHybPenetration.penetrationBean.getNt_ul_penet_mtd_pol_cnt()+" of "+NatHybPenetration.penetrationBean.getNt_mtd_inforced_count()
								+" Policies issued on MONTHLY basis";
					}
					else
					{
						finalresponse=msgChannel+" "+productType+" Penetration is "+ul_penet_mtd_afyp+" % of "+mtd_inforced_afyp
								+" " + LacsCr +" of paid Business AFYP "+period+" and "+ul_penet_mtd_pol_cnt+" % of "+mtd_inforced_count+" Policies"
								+ " issued on "+period+" basis";
					}

				}
			}
			else if("TRAD".equalsIgnoreCase(productType))
			{
				if("google".equalsIgnoreCase(source))
				{
					finalresponse=msgChannel+" "+productType+" Penetration is "+trad_penet_mtd_afyp+" % of "+mtd_inforced_afyp
							+" " + LacsCr +" of paid Business, and "+trad_penet_mtd_pol_cnt+" % of "+mtd_inforced_count+" Policies"
							+ " issued in this month";
				}
				else
				{
					if("Internet Sales".equalsIgnoreCase(msgChannel))
					{
						finalresponse="Native ecomm TRAD Penetration is "+NatHybPenetration.penetrationBean.getNt_trad_penet_mtd_afyp()+" % of "+NatHybPenetration.penetrationBean.getNt_mtd_inforced_afyp()+" " + LacsCr
								+ "of paid Business AFYP MONTHLY and "+NatHybPenetration.penetrationBean.getNt_trad_penet_mtd_pol_cnt()+" % of "+NatHybPenetration.penetrationBean.getNt_mtd_inforced_count()
								+" Policies issued on MONTHLY basis. \n\n "
								+ "Hybrid ecomm TRAD Penetration is "+NatHybPenetration.penetrationBean.getHy_trad_penet_mtd_afyp()+" % of "+NatHybPenetration.penetrationBean.getHy_mtd_inforced_afyp()
								+" " + LacsCr +" of paid Business AFYP MONTHLY and "+NatHybPenetration.penetrationBean.getNt_trad_penet_mtd_pol_cnt()+" of "+NatHybPenetration.penetrationBean.getNt_mtd_inforced_count()
								+" Policies issued on MONTHLY basis";
					}
					else
					{
						finalresponse=msgChannel+" "+productType+" Penetration is "+trad_penet_mtd_afyp+" % of "+mtd_inforced_afyp
								+" " + LacsCr +" of paid Business AFYP "+period+" and "+trad_penet_mtd_pol_cnt+" % of "+mtd_inforced_count+" Policies"
								+ " issued on "+period+" basis";
					}
				}
			}
			else
			{
				if("google".equalsIgnoreCase(source))
				{
					finalresponse=msgChannel+" "+productType+" Penetration is "+protec_penet_mtd_afyp+" % of "+mtd_inforced_afyp
							+" " + LacsCr +" of paid Business  and "+protec_penet_mtd_pol_cnt+" % of "+mtd_inforced_count+" Policies"
							+ " issued in this month ";
				}
				else
				{
					if("Internet Sales".equalsIgnoreCase(msgChannel))
					{
						finalresponse="Native ecomm Protection Penetration is "+NatHybPenetration.penetrationBean.getNt_protec_penet_mtd_afyp()+" % of "+NatHybPenetration.penetrationBean.getNt_mtd_inforced_afyp()+" " + LacsCr
								+ " of paid Business AFYP MONTHLY and "+NatHybPenetration.penetrationBean.getNt_protec_penet_mtd_pol_cnt()+" % of "+NatHybPenetration.penetrationBean.getNt_mtd_inforced_count()+
								" Policies issued on MONTHLY basis. \n\n "
								+ " Hybrid ecomm Protection Penetration is "+NatHybPenetration.penetrationBean.getHy_mtd_inforced_afyp()+" % of "+ NatHybPenetration.penetrationBean.getHy_mtd_inforced_afyp()
								+" " + LacsCr +" of paid Business AFYP MONTHLY and "+NatHybPenetration.penetrationBean.getHy_protec_penet_mtd_pol_cnt()+" % of "+NatHybPenetration.penetrationBean.getHy_mtd_inforced_count()+
								" Policies issued on MONTHLY basis";

					}
					else
					{
						finalresponse=msgChannel+" "+productType+" Penetration is "+protec_penet_mtd_afyp+" % of "+mtd_inforced_afyp
								+" " + LacsCr +" of paid Business AFYP "+period+" and "+protec_penet_mtd_pol_cnt+" % of "+mtd_inforced_count+" Policies"
								+ " issued on "+period+" basis";
					}

				}
			}
		}
		else
		{
			if("ULIP".equalsIgnoreCase(productType))
			{
				if("google".equalsIgnoreCase(source))
				{
					finalresponse=msgChannel+" "+productType+" Penetration is "+ul_penet_ytd_afyp+" % of "+ytd_inforced_afyp+
							" " + LacsCr +" of paid Business and "+ul_penet_ytd_pol_cnt+" % of "+ytd_inforced_count+" Policies"
							+ " issued on this year";
				}
				else
				{
					if("Internet Sales".equalsIgnoreCase(msgChannel))
					{
						finalresponse="Native ecomm ULIP Penetration is "+NatHybPenetration.penetrationBean.getNt_ul_penet_ytd_afyp()+" % of "+NatHybPenetration.penetrationBean.getNt_ytd_inforced_afyp()+" " + LacsCr
								+ "of paid Business AFYP YTD and "+NatHybPenetration.penetrationBean.getNt_ul_penet_ytd_pol_cnt()+" % of "+NatHybPenetration.penetrationBean.getNt_ytd_inforced_count()
								+" Policies issued on YTD basis. \n\n "
								+ "Hybrid ecomm Protection Penetration is "+NatHybPenetration.penetrationBean.getHy_ul_penet_ytd_afyp()+" % of "+NatHybPenetration.penetrationBean.getHy_ytd_inforced_afyp()
								+" " + LacsCr +" of paid Business AFYP YTD and "+NatHybPenetration.penetrationBean.getNt_ul_penet_ytd_pol_cnt()+" of "+NatHybPenetration.penetrationBean.getNt_ytd_inforced_count()
								+" Policies issued on YTD basis";
					}
					else
					{
						finalresponse=msgChannel+" "+productType+" Penetration is "+ul_penet_ytd_afyp+" % of "+ytd_inforced_afyp+
								" " + LacsCr +" of paid Business AFYP "+period+" and "+ul_penet_ytd_pol_cnt+" % of "+ytd_inforced_count+" Policies"
								+ " issued on "+period+" basis";
					}

				}

			}else if("TRAD".equalsIgnoreCase(productType))
			{
				if("google".equalsIgnoreCase(source))
				{
					finalresponse=msgChannel+" "+productType+" Penetration is "+trad_penet_ytd_afyp+" % of "+ytd_inforced_afyp+
							" " + LacsCr +" of paid business, and "+trad_penet_ytd_pol_cnt+" % of "+ytd_inforced_count+" Policies"
							+ " issued in this year";
				}
				else
				{
					if("Internet Sales".equalsIgnoreCase(msgChannel))
					{
						finalresponse="Native ecomm ULIP Penetration is "+NatHybPenetration.penetrationBean.getNt_trad_penet_ytd_afyp()+" % of "+NatHybPenetration.penetrationBean.getNt_ytd_inforced_afyp()+" " + LacsCr
								+ "of paid Business AFYP YTD and "+NatHybPenetration.penetrationBean.getNt_trad_penet_ytd_pol_cnt()+" % of "+NatHybPenetration.penetrationBean.getNt_ytd_inforced_count()
								+" Policies issued on YTD basis. \n\n "
								+ "Hybrid ecomm Protection Penetration is "+NatHybPenetration.penetrationBean.getHy_trad_penet_ytd_afyp()+" % of "+NatHybPenetration.penetrationBean.getHy_ytd_inforced_afyp()
								+" " + LacsCr +" of paid Business AFYP YTD and "+NatHybPenetration.penetrationBean.getNt_trad_penet_ytd_pol_cnt()+" of "+NatHybPenetration.penetrationBean.getNt_ytd_inforced_count()
								+" Policies issued on YTD basis";
					}
					else
					{
						finalresponse=msgChannel+" "+productType+" Penetration is "+trad_penet_ytd_afyp+" % of "+ytd_inforced_afyp+
								" " + LacsCr +" of paid Business AFYP "+period+" and "+trad_penet_ytd_pol_cnt+" % of "+ytd_inforced_count+" Policies"
								+ " issued on "+period+" basis";

					}
				}
			}
			else
			{
				if("Internet Sales".equalsIgnoreCase(msgChannel))
				{
					finalresponse="Native ecomm Protection Penetration is "+NatHybPenetration.penetrationBean.getNt_protec_penet_ytd_afyp()+" % of "+NatHybPenetration.penetrationBean.getNt_ytd_inforced_afyp()+" " + LacsCr
							+ "of paid Business AFYP YTD and "+NatHybPenetration.penetrationBean.getNt_protec_penet_ytd_pol_cnt()+" % of "+NatHybPenetration.penetrationBean.getNt_ytd_inforced_count()
							+" Policies issued on YTD basis. \n\n "
							+ "Hybrid ecomm Protection Penetration is "+NatHybPenetration.penetrationBean.getHy_protec_penet_ytd_afyp()+" % of "+NatHybPenetration.penetrationBean.getHy_ytd_inforced_afyp()
							+" " + LacsCr +" of paid Business AFYP YTD and "+NatHybPenetration.penetrationBean.getNt_protec_penet_ytd_pol_cnt()+" of "+NatHybPenetration.penetrationBean.getNt_ytd_inforced_count()
							+" Policies issued on YTD basis";
				}
				else
				{
					finalresponse=msgChannel+" "+productType+" Penetration is "+protec_penet_ytd_afyp+" % of "+ytd_inforced_afyp+
							" " + LacsCr +" of paid Business AFYP "+period+" and "+protec_penet_ytd_pol_cnt+" % of "+ytd_inforced_count+" Policies"
							+ " issued on "+period+" basis";
				}
			}
		}
		if("Agency".equalsIgnoreCase(msgChannel))
		{
			finalresponse=finalresponse+"\n If you want to see the data for sub-channels, please enter sub-channel name - Defence, Office within office, APC, Greenfield.";
		}
		return finalresponse.toString();
	}
}
