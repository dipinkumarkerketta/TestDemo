package com.qc.service.messageimpl;

import com.qc.jsonImpl.NatHybCaseSize;

public class NBCaseSize 
{
	public static String nbCaseSizeIntent(String channel, String period, String user_circle, String user_region, String userzone, 
			String real_tim_timstamp, String case_size_afyp_mtd, String case_size_afyp_ytd, String subchannel,
			String user_clusters, String user_go, String superZone, String keyMarket)
	{
		String finalresponse="";
		if("MLI".equalsIgnoreCase(channel))
		{channel="";}
		if("Monthly".equalsIgnoreCase(period))
		{period="";}
		else
		{
			if("FTD".equalsIgnoreCase(period))
			{
				period="MTD";
			}
			else
			{
				period=period.toUpperCase();
			}
		}
		if(!"".equalsIgnoreCase(user_circle))
		{
			user_region="Circle "+user_circle;
		}
		if(!"".equalsIgnoreCase(user_go))
		{
			user_clusters="Office "+user_go;
		}
		if(!"".equalsIgnoreCase(subchannel))
		{
			channel = subchannel;
		}
		if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(keyMarket))
		{
			finalresponse= "As of " +real_tim_timstamp+ " Case Size MTD for MLI is Rs. "
					+ case_size_afyp_mtd+ " Case Size YTD for MLI is Rs. " +case_size_afyp_ytd+ 
					". If you want to see the channel wise business numbers, please specify the same.";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(keyMarket))
		{
			if("Agency".equalsIgnoreCase(channel))
			{
				finalresponse= "As of " +real_tim_timstamp+ " Case Size MTD for "+channel+" is Rs. "+case_size_afyp_mtd+
						" Case Size YTD for "+channel+" is Rs. "+case_size_afyp_ytd+
						". If you want to see the data for sub-channels, please enter sub-channel name - Defence, Office within office, APC, Greenfield.";
			}
			else
			{
				if("Internet Sales".equalsIgnoreCase(channel))
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()
					+" For Native ecomm, Case Size MTD is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_mtd()
					+" and YTD  is Rs. "+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_ytd()+"\n\n"
					+" Hybrid ecomm, Case Size MTD is Rs."+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_mtd()
					+" and YTD  is Rs."+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_ytd()+".";

				}
				else
				{
					finalresponse= "As of " +real_tim_timstamp+ " Case Size MTD for "+channel+" is Rs. "+case_size_afyp_mtd+
							" Case Size YTD for "+channel+" is Rs. "+case_size_afyp_ytd+
							". If you want to see the Zone/Region wise business numbers, please specify the same.";
				}
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(period))
		{
			finalresponse="As of " +real_tim_timstamp+" Case Size MTD for "+superZone+ " is Rs. "+ case_size_afyp_mtd+" Case Size YTD for "+
					superZone+" is Rs. "+case_size_afyp_ytd+". If you want to see the zone wise business numbers, please specify the same.";

		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse="As of " +real_tim_timstamp+" Case Size MTD for KM "+keyMarket+ " is Rs. "+ case_size_afyp_mtd+" Case Size YTD for KM "+
					keyMarket+" is Rs. "+case_size_afyp_ytd+". If you want to see the region wise business numbers, please specify the same.";

		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
		{
			finalresponse="As of " +real_tim_timstamp+" Case Size MTD for "+userzone+ " zone is Rs. "+ case_size_afyp_mtd+" Case Size YTD for "+
					userzone+" zone is Rs. "+case_size_afyp_ytd+". If you want to see the region wise business numbers, please specify the same.";

		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse="As of " +real_tim_timstamp+ " Case Size MTD for "+user_region+"  is Rs. "+case_size_afyp_mtd+
					" Case Size YTD for"+user_region+" is Rs. "+case_size_afyp_ytd;
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse="As of " +real_tim_timstamp+ " Case Size MTD for "+user_clusters+" is Rs. "+case_size_afyp_mtd+
					" Case Size YTD for"+user_clusters+" is Rs. "+case_size_afyp_ytd;
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse="As of " +real_tim_timstamp+ " Case Size MTD for "+user_clusters+" is Rs. "+case_size_afyp_mtd+
					" Case Size YTD for"+user_clusters+" is Rs. "+case_size_afyp_ytd;
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region)
				&& !"".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse="As of " +real_tim_timstamp+ " Case Size MTD for "+user_clusters+" is Rs. "+case_size_afyp_mtd+
					" Case Size YTD for"+user_clusters+" is Rs. "+case_size_afyp_ytd;
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse="As of " +real_tim_timstamp+ " Case Size MTD for "+user_region+" is Rs. "+case_size_afyp_mtd+
					" Case Size YTD for"+user_region+" is Rs. "+case_size_afyp_ytd;
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(superZone))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp+ " Case Size " +period+" for "+channel+ " is Rs. "+ case_size_afyp_ytd+
							". If you want to see the Zone/Region wise business numbers, please specify the same.";
				}else 
				{
					finalresponse="As of " +real_tim_timstamp+ " Case Size " +period+" for "+channel+ " is Rs. "+ case_size_afyp_mtd+
							". If you want to see the Zone/Region wise business numbers, please specify the same.";
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size YTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_ytd()+""
							+ " For Hybrid ecomm, Case Size YTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_ytd()+".";

				}
				else
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size MTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_mtd()+""
							+ " For Hybrid ecomm, Case Size MTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_mtd()+".";
				}
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp+" Case Size "+period+" for "+superZone+" is Rs. "+case_size_afyp_ytd+
							". If you want to see the zone/region wise business numbers, please specify the same.";
				}else
				{
					finalresponse="As of " +real_tim_timstamp+" Case Size "+period+" for "+superZone+" is Rs. "+case_size_afyp_mtd+
							". If you want to see the zone/region wise business numbers, please specify the same.";
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size YTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_ytd()+""
							+ " For Hybrid ecomm, Case Size YTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_ytd()+".";

				}
				else
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size MTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_mtd()+""
							+ " For Hybrid ecomm, Case Size MTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_mtd()+".";
				}
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp+" Case Size "+period+" for KM "+keyMarket+" is Rs. "+case_size_afyp_ytd+
							". If you want to see the region wise business numbers, please specify the same.";
				}else
				{
					finalresponse="As of " +real_tim_timstamp+" Case Size "+period+" for KM "+keyMarket+" is Rs. "+case_size_afyp_mtd+
							". If you want to see the region wise business numbers, please specify the same.";
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size YTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_ytd()+""
							+ " For Hybrid ecomm, Case Size YTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_ytd()+".";

				}
				else
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size MTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_mtd()+""
							+ " For Hybrid ecomm, Case Size MTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_mtd()+".";
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp+" Case Size "+period+" for "+userzone+" zone is Rs. "+case_size_afyp_ytd+
							". If you want to see the region wise business numbers, please specify the same.";
				}else
				{
					finalresponse="As of " +real_tim_timstamp+" Case Size "+period+" for "+userzone+" zone is Rs. "+case_size_afyp_mtd+
							". If you want to see the region wise business numbers, please specify the same.";
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size YTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_ytd()+""
							+ " For Hybrid ecomm, Case Size YTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_ytd()+".";

				}
				else
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size MTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_mtd()+""
							+ " For Hybrid ecomm, Case Size MTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_mtd()+".";
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp+" Case Size "+period+" for "+user_region+" is Rs. "+case_size_afyp_ytd;
				}else
				{
					finalresponse="As of " +real_tim_timstamp+" Case Size "+period+" for "+user_region+" is Rs. "+case_size_afyp_mtd;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size YTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_ytd()+""
							+ " For Hybrid ecomm, Case Size YTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_ytd()+".";
				}
				else
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size MTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_mtd()+""
							+ " For Hybrid ecomm, Case Size MTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_mtd()+".";
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region)
				&& !"".equalsIgnoreCase(user_clusters)&& !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp+" Case Size "+period+" for "+user_clusters+" is Rs. "+case_size_afyp_ytd;
				}else
				{
					finalresponse="As of " +real_tim_timstamp+" Case Size "+period+" for "+user_clusters+" is Rs. "+case_size_afyp_mtd;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size YTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_ytd()+""
							+ " For Hybrid ecomm, Case Size YTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_ytd()+".";

				}
				else
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size MTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_mtd()+""
							+ " For Hybrid ecomm, Case Size MTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_mtd()+".";
				}
			}
		}
		/*-------added by bhavneet*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
				&& !"".equalsIgnoreCase(user_clusters)&& !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp+" Case Size "+period+" for "+user_clusters+" is Rs. "+case_size_afyp_ytd;
				}else
				{
					finalresponse="As of " +real_tim_timstamp+" Case Size "+period+" for "+user_clusters+" is Rs. "+case_size_afyp_mtd;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size YTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_ytd()+""
							+ " For Hybrid ecomm, Case Size YTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_ytd()+".";

				}
				else
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size MTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_mtd()+""
							+ " For Hybrid ecomm, Case Size MTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_mtd()+".";
				}
			}
		}
		
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp+" Case Size "+period+" for "+user_region+" is Rs. "+case_size_afyp_ytd;
				}else
				{
					finalresponse="As of " +real_tim_timstamp+" Case Size "+period+" for "+user_region+" is Rs. "+case_size_afyp_mtd;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size YTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_ytd()+""
							+ " For Hybrid ecomm, Case Size YTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_ytd()+".";

				}
				else
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size MTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_mtd()+""
							+ " For Hybrid ecomm, Case Size MTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_mtd()+".";
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp+" Case Size "+period+" for "+user_clusters+" is Rs. "+case_size_afyp_ytd;
				}else
				{
					finalresponse="As of " +real_tim_timstamp+" Case Size "+period+" for "+user_clusters+" is Rs. "+case_size_afyp_mtd;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size YTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_ytd()+""
							+ " For Hybrid ecomm, Case Size YTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_ytd()+".";

				}
				else
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size MTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_mtd()+""
							+ " For Hybrid ecomm, Case Size MTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_mtd()+".";
				}
			}
		}
		else
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp+"  Case Size "+period+ " for MLI is Rs. "+case_size_afyp_ytd+
							". If you want to see the channel wise business numbers, please specify the same.";
				}else 
				{
					finalresponse="As of " +real_tim_timstamp+"  Case Size "+period+ " for MLI is Rs. "+case_size_afyp_mtd+
							". If you want to see the channel wise business numbers, please specify the same.";
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size YTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_ytd()+""
							+ " For Hybrid ecomm, Case Size YTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_ytd()+".";

				}
				else
				{
					finalresponse="As of "+NatHybCaseSize.casesizeBean.getReal_tim_timstamp()+" For Native ecomm, Case Size MTD  is Rs."+NatHybCaseSize.casesizeBean.getNativ_case_size_afyp_mtd()+""
							+ " For Hybrid ecomm, Case Size MTD  is Rs. "+NatHybCaseSize.casesizeBean.getHybrd_case_size_afyp_mtd()+".";
				}
			}

		}
		return finalresponse.toString();
	}
}