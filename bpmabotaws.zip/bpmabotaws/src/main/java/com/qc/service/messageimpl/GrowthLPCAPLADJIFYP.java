package com.qc.service.messageimpl;

public class GrowthLPCAPLADJIFYP {

	public static String growthLPCAPLADJIFYPIntent(String channel,String period,String userzone,
			String user_region,String real_tim_timstamp,String user_circle,
			String grth_lpc_applied_adj_ifyp_ytd,String prev_lpc_applied_adj_ifyp_ytd,
			String lpc_applied_adj_ifyp_ytd_growth,String grth_lpc_applied_adj_ifyp_mtd,
			String prev_lpc_applied_adj_ifyp_mtd,String lpc_applied_adj_ifyp_mtd_growth,
			String lpc_paid_adj_mfyp_ytd_growth,String lpc_paid_adj_mfyp_mtd_growth,
			String grth_lpc_paid_adj_mfyp_ytd,String prev_lpc_paid_adj_mfyp_ytd,
			String prev_lpc_paid_adj_mfyp_mtd,String grth_lpc_paid_adj_mfyp_mtd, String subchannel,
			String user_clusters, String user_go, String LacsCr, String superZone, String keyMarket)
	{
		String finalresponse="";

		if("MLI".equalsIgnoreCase(channel))
		{channel="";}
		if("Monthly".equalsIgnoreCase(period))
		{period="";}
		else
		{
			if("FTD".equalsIgnoreCase(period))
			{
				period="MTD";
			}
			else
			{
				period=period.toUpperCase();
			}
		}
		if(!"".equalsIgnoreCase(user_circle))
		{
			user_region="Circle "+user_circle;
		}
		if(!"".equalsIgnoreCase(user_go))
		{
			user_clusters="Office "+user_go;
		}
		if(!"".equalsIgnoreCase(subchannel))
		{
			channel = subchannel;
		}

		if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
		   && "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(superZone)&& "".equalsIgnoreCase(keyMarket))
		{
			finalresponse= "MLI has witnessed LPC applied business growth of "+grth_lpc_applied_adj_ifyp_ytd+" % on YTD basis, last year same time we had clocked "+
					prev_lpc_applied_adj_ifyp_ytd+ " " + LacsCr +" LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_ytd_growth+ " " + LacsCr +" today MTD business Growth of "+ 
					grth_lpc_applied_adj_ifyp_mtd+ " % on MTD basis, last year same month we have clocked "+
					prev_lpc_applied_adj_ifyp_mtd+" " + LacsCr +" of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_mtd_growth+ " " + LacsCr +" today."
					+ " If you want to see the Channel wise business numbers, please specify the same.";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(superZone)&& "".equalsIgnoreCase(keyMarket))
		{
			if("Agency".equalsIgnoreCase(channel))
			{
				finalresponse= channel+" has witnessed LPC applied business growth of "+grth_lpc_applied_adj_ifyp_ytd+" % on YTD basis, last year same time we had clocked "+
						prev_lpc_applied_adj_ifyp_ytd+ " " + LacsCr +" LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_ytd_growth+ " " + LacsCr +" today MTD business Growth of "+ 
						grth_lpc_applied_adj_ifyp_mtd+ " % on MTD basis, last year same month we have clocked "+
						prev_lpc_applied_adj_ifyp_mtd+" " + LacsCr +" of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_mtd_growth+ " " + LacsCr +" today."
						+ " If you want to see the data for sub-channels, please enter sub-channel name - Defence, Office within office, APC, Greenfield.";
			}
			else
			{
				finalresponse= channel+" has witnessed LPC applied business growth of "+grth_lpc_applied_adj_ifyp_ytd+" % on YTD basis, last year same time we had clocked "+
						prev_lpc_applied_adj_ifyp_ytd+ " " + LacsCr +" LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_ytd_growth+ " " + LacsCr +" today MTD business Growth of "+ 
						grth_lpc_applied_adj_ifyp_mtd+ " % on MTD basis, last year same month we have clocked "+
						prev_lpc_applied_adj_ifyp_mtd+" " + LacsCr +" of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_mtd_growth+ " " + LacsCr +" today."
						+ " If you want to see the Zone/Region wise business numbers, please specify the same.";
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
			{
				finalresponse= superZone+" has witnessed LPC applied business growth of "+grth_lpc_applied_adj_ifyp_ytd+" % on YTD basis, last year same time we had clocked "+
						prev_lpc_applied_adj_ifyp_ytd+ " " + LacsCr +" LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_ytd_growth+ " " + LacsCr +" today MTD business Growth of "+ 
						grth_lpc_applied_adj_ifyp_mtd+ " % on MTD basis, last year same month we have clocked "+
						prev_lpc_applied_adj_ifyp_mtd+" " + LacsCr +" of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_mtd_growth+ " " + LacsCr +" today."
						+ " If you want to see region wise business numbers, please specify the same.";
			}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
		{
			finalresponse= "Zone "+userzone+" has witnessed LPC applied business growth of "+grth_lpc_applied_adj_ifyp_ytd+" % on YTD basis, last year same time we had clocked "+
					prev_lpc_applied_adj_ifyp_ytd+ " " + LacsCr +" LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_ytd_growth+ " " + LacsCr +" today MTD business Growth of "+ 
					grth_lpc_applied_adj_ifyp_mtd+ " % on MTD basis, last year same month we have clocked "+
					prev_lpc_applied_adj_ifyp_mtd+" " + LacsCr +" of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_mtd_growth+ " " + LacsCr +" today."
					+ " If you want to see region wise business numbers, please specify the same.";
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(keyMarket)  && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
			{
				finalresponse= "KM "+keyMarket+" has witnessed LPC applied business growth of "+grth_lpc_applied_adj_ifyp_ytd+" % on YTD basis, last year same time we had clocked "+
						prev_lpc_applied_adj_ifyp_ytd+ " " + LacsCr +" LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_ytd_growth+ " " + LacsCr +" today MTD business Growth of "+ 
						grth_lpc_applied_adj_ifyp_mtd+ " % on MTD basis, last year same month we have clocked "+
						prev_lpc_applied_adj_ifyp_mtd+" " + LacsCr +" of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_mtd_growth+ " " + LacsCr +" today."
						+ " If you want to see region wise business numbers, please specify the same.";
			}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= ""+user_region+" has witnessed LPC applied business growth of "+grth_lpc_applied_adj_ifyp_ytd+" % on YTD basis, last year same time we had clocked "+
					prev_lpc_applied_adj_ifyp_ytd+ " " + LacsCr +" LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_ytd_growth+ " " + LacsCr +" today MTD business Growth of "+ 
					grth_lpc_applied_adj_ifyp_mtd+ " % on MTD basis, last year same month we have clocked "+
					prev_lpc_applied_adj_ifyp_mtd+" " + LacsCr +" of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_mtd_growth+ " " + LacsCr +" today."
					+ " If you want to see the Zone/Region wise business numbers, please specify the same.";
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= ""+user_clusters+" has witnessed LPC applied business growth of "+grth_lpc_applied_adj_ifyp_ytd+" % on YTD basis, last year same time we had clocked "+
					prev_lpc_applied_adj_ifyp_ytd+ " " + LacsCr +" LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_ytd_growth+ " " + LacsCr +" today MTD business Growth of "+ 
					grth_lpc_applied_adj_ifyp_mtd+ " % on MTD basis, last year same month we have clocked "+
					prev_lpc_applied_adj_ifyp_mtd+" " + LacsCr +" of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_mtd_growth+ " " + LacsCr +" today.";

		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= ""+user_clusters+" has witnessed LPC applied business growth of "+grth_lpc_applied_adj_ifyp_ytd+" % on YTD basis, last year same time we had clocked "+
					prev_lpc_applied_adj_ifyp_ytd+ " " + LacsCr +" LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_ytd_growth+ " " + LacsCr +" today MTD business Growth of "+ 
					grth_lpc_applied_adj_ifyp_mtd+ " % on MTD basis, last year same month we have clocked "+
					prev_lpc_applied_adj_ifyp_mtd+" " + LacsCr +" of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_mtd_growth+ " " + LacsCr +" today.";

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region)
			&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= ""+user_clusters+" has witnessed LPC applied business growth of "+grth_lpc_applied_adj_ifyp_ytd+" % on YTD basis, last year same time we had clocked "+
					prev_lpc_applied_adj_ifyp_ytd+ " " + LacsCr +" LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_ytd_growth+ " " + LacsCr +" today MTD business Growth of "+ 
					grth_lpc_applied_adj_ifyp_mtd+ " % on MTD basis, last year same month we have clocked "+
					prev_lpc_applied_adj_ifyp_mtd+" " + LacsCr +" of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_mtd_growth+ " " + LacsCr +" today.";

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= ""+user_region+" has witnessed LPC applied business growth of "+grth_lpc_applied_adj_ifyp_ytd+" % on YTD basis, last year same time we had clocked "+
					prev_lpc_applied_adj_ifyp_ytd+ " " + LacsCr +" LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_ytd_growth+ " " + LacsCr +" today MTD business Growth of "+ 
					grth_lpc_applied_adj_ifyp_mtd+ " % on MTD basis, last year same month we have clocked "+
					prev_lpc_applied_adj_ifyp_mtd+" " + LacsCr +" of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_mtd_growth+ " " + LacsCr +" today."
					+ " If you want to see the Zone/Region wise business numbers, please specify the same.";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(superZone))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= channel+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_ytd+" % on "+period+" basis, last year same time we had clocked "+
						prev_lpc_applied_adj_ifyp_ytd+ " of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_ytd_growth+ " " + LacsCr +" today"
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}
			else
			{
				finalresponse= channel+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_mtd+" % on "+period+" basis, last year same time we had clocked "+
						prev_lpc_applied_adj_ifyp_mtd+ " of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_mtd_growth+ " " + LacsCr +" today"
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";	
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse= superZone+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_ytd+" % on "+period+" basis, last year same time we had clocked "+
							prev_lpc_applied_adj_ifyp_ytd+ " of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_ytd_growth+ " " + LacsCr +" today"
							+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
				}
				else
				{
					finalresponse= superZone+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_mtd+" % on "+period+" basis, last year same time we had clocked "+
							prev_lpc_applied_adj_ifyp_mtd+ " of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_mtd_growth+ " " + LacsCr +" today"
							+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";	
				}
			}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse= "KM "+keyMarket+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_ytd+" % on "+period+" basis, last year same time we had clocked "+
							prev_lpc_applied_adj_ifyp_ytd+ " of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_ytd_growth+ " " + LacsCr +" today"
							+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
				}
				else
				{
					finalresponse= "KM "+keyMarket+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_mtd+" % on "+period+" basis, last year same time we had clocked "+
							prev_lpc_applied_adj_ifyp_mtd+ " of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_mtd_growth+ " " + LacsCr +" today"
							+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";	
				}
			}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "Zone "+userzone+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_ytd+" % on "+period+" basis, last year same time we had clocked "+
						prev_lpc_applied_adj_ifyp_ytd+ " of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_ytd_growth+ " " + LacsCr +" today"
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}
			else
			{
				finalresponse= "Zone "+userzone+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_mtd+" % on "+period+" basis, last year same time we had clocked "+
						prev_lpc_applied_adj_ifyp_mtd+ " of LPC applied Adj IFYP as compared to " +lpc_applied_adj_ifyp_mtd_growth+ " " + LacsCr +" today"
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";	
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= ""+user_region+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_ytd+" % on "+period+" basis, last year same time we had clocked "+
						prev_lpc_applied_adj_ifyp_ytd+ " of LPC applied Adj IFYP as compared to " +lpc_paid_adj_mfyp_ytd_growth+ " " + LacsCr +" today"
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}
			else
			{
				finalresponse= ""+user_region+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_mtd+" % on "+period+" basis, last year same time we had clocked "+
						prev_lpc_applied_adj_ifyp_mtd+ " of LPC applied Adj IFYP as compared to " +lpc_paid_adj_mfyp_mtd_growth+ " " + LacsCr +" today"
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";	
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= ""+user_clusters+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_ytd+" % on "+period+" basis, last year same time we had clocked "+
						prev_lpc_applied_adj_ifyp_ytd+ " of LPC applied Adj IFYP as compared to " +lpc_paid_adj_mfyp_ytd_growth+ " " + LacsCr +" today ";

			}
			else
			{
				finalresponse= ""+user_clusters+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_mtd+" % on "+period+" basis, last year same time we had clocked "+
						prev_lpc_applied_adj_ifyp_mtd+ " of LPC applied Adj IFYP as compared to " +lpc_paid_adj_mfyp_mtd_growth+ " " + LacsCr +" today. ";

			}
		}
		/*added by bhavneet*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse= ""+user_clusters+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_ytd+" % on "+period+" basis, last year same time we had clocked "+
							prev_lpc_applied_adj_ifyp_ytd+ " of LPC applied Adj IFYP as compared to " +lpc_paid_adj_mfyp_ytd_growth+ " " + LacsCr +" today ";

				}
				else
				{
					finalresponse= ""+user_clusters+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_mtd+" % on "+period+" basis, last year same time we had clocked "+
							prev_lpc_applied_adj_ifyp_mtd+ " of LPC applied Adj IFYP as compared to " +lpc_paid_adj_mfyp_mtd_growth+ " " + LacsCr +" today. ";

				}
			}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= ""+user_region+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_ytd+" % on "+period+" basis, last year same time we had clocked "+
						prev_lpc_applied_adj_ifyp_ytd+ " of LPC applied Adj IFYP as compared to " +lpc_paid_adj_mfyp_ytd_growth+ " " + LacsCr +" today"
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}
			else
			{
				finalresponse= ""+user_region+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_mtd+" % on "+period+" basis, last year same time we had clocked "+
						prev_lpc_applied_adj_ifyp_mtd+ " of LPC applied Adj IFYP as compared to " +lpc_paid_adj_mfyp_mtd_growth+ " " + LacsCr +" today"
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";	
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= ""+user_clusters+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_ytd+" % on "+period+" basis, last year same time we had clocked "+
						prev_lpc_applied_adj_ifyp_ytd+ " of LPC applied Adj IFYP as compared to " +lpc_paid_adj_mfyp_ytd_growth+ " " + LacsCr +" today. ";

			}
			else
			{
				finalresponse= ""+user_clusters+" has witnessed LPC applied business growth of " +grth_lpc_applied_adj_ifyp_mtd+" % on "+period+" basis, last year same time we had clocked "+
						prev_lpc_applied_adj_ifyp_mtd+ " of LPC applied Adj IFYP as compared to " +lpc_paid_adj_mfyp_mtd_growth+ " " + LacsCr +" today. ";

			}
		}
		else
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= channel+" has witnessed LPC applied business growth of " +grth_lpc_paid_adj_mfyp_ytd+" % on "+period+" basis, last year same time we had clocked "+
						prev_lpc_paid_adj_mfyp_ytd+ " of LPC applied Adj IFYP as compared to " +lpc_paid_adj_mfyp_ytd_growth+ " " + LacsCr +" today"
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}else
			{
				finalresponse= channel+" has witnessed LPC applied business growth of " +grth_lpc_paid_adj_mfyp_mtd+" % on "+period+" basis, last year same time we had clocked "+
						prev_lpc_paid_adj_mfyp_mtd+ " of LPC applied Adj IFYP as compared to " +lpc_paid_adj_mfyp_mtd_growth+ " " + LacsCr +" today"
						+ ". If you want to see the Zone/Region wise business numbers, please specify the same.";	
			}
		}

		return finalresponse.toString();
	}
}
