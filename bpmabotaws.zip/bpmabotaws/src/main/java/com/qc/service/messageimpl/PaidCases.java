package com.qc.service.messageimpl;

import com.qc.jsonImpl.NatHybInforced;
public class PaidCases 
{
	public static String paidCasesIntent(String channel, String period, String user_circle, String user_region, String userzone,
			String real_tim_timstamp, String mtd_inforced_count, String ytd_inforced_count, String daily_inforced_count1, String subchannel,
			String user_clusters, String user_go, 
			String daily_inforced_afyp2, String daily_inforced_count2, String daily_adj_mfyp2, String superZone, String keyMarket)

	{
		String finalresponse="";
		if("MLI".equalsIgnoreCase(channel))
		{
			channel="";
		}if("Monthly".equalsIgnoreCase(period))
		{
			period="";
		}else
		{
			period=period.toUpperCase();
		}if(!"".equalsIgnoreCase(user_circle))
		{
			user_region="Circle "+user_circle;
		}if(!"".equalsIgnoreCase(user_go))
		{
			user_clusters="Office "+user_go;
		}
		if(!"".equalsIgnoreCase(subchannel))
		{
			channel = subchannel;
		}
		if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region)  && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period)&& "".equalsIgnoreCase(superZone)&& "".equalsIgnoreCase(keyMarket))
		{
			finalresponse= "As of " + real_tim_timstamp + " Paid cases MTD for MLI is "
					+ mtd_inforced_count+". Paid cases YTD for MLI is " + ytd_inforced_count + 
					". If you want to see the channel wise business numbers, please specify the same.";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters) 
				&& "".equalsIgnoreCase(period)&& "".equalsIgnoreCase(superZone)&& "".equalsIgnoreCase(keyMarket))
		{
			if("Internet Sales".equalsIgnoreCase(channel))
			{
				finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getNativ_mtd_inforced_count()+ ". Paid cases YTD is " + NatHybInforced.inforcedBean.getNativ_ytd_inforced_count()
				+"\n\n "
				+ "For Hybrid ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getHybride_mtd_inforced_count()+ ". Paid cases YTD is " + NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
			}
			else
			{
				finalresponse= "As of " + real_tim_timstamp + " Paid cases MTD for " + channel + " is " + mtd_inforced_count +
						". Paid cases YTD for " +channel + " is " + ytd_inforced_count;
				if("Agency".equalsIgnoreCase(channel))
				{
					finalresponse=finalresponse+" If you want to see the data for sub-channels, please enter sub-channel name - Defence, Office within office, APC, Greenfield.";
				}

			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(userzone) 
				&& "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(keyMarket)&& "".equalsIgnoreCase(period)) {
			finalresponse="As of " + real_tim_timstamp + " Paid cases MTD for " + superZone + " is " + mtd_inforced_count + ". Paid cases YTD for " +
					superZone + " is " + ytd_inforced_count;
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(keyMarket)  
				&& "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)&& "".equalsIgnoreCase(period) ) {
			finalresponse="As of " + real_tim_timstamp + " Paid cases MTD for KM " + keyMarket + " is " + mtd_inforced_count + ". Paid cases YTD for KM " +
					keyMarket + " is " + ytd_inforced_count;
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters) 
				&& "".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
		{
			finalresponse="As of " + real_tim_timstamp + " Paid cases MTD for " + userzone + " zone is " + mtd_inforced_count + ". Paid cases YTD for " +
					userzone + " zone is " + ytd_inforced_count; 
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse="As of " +real_tim_timstamp + " Paid cases MTD for " + user_region + " is " + mtd_inforced_count +
					". Paid cases YTD for " + user_region + " is " + ytd_inforced_count;
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)&& !"".equalsIgnoreCase(user_clusters) 
				&& "".equalsIgnoreCase(period))
		{
			finalresponse="As of " +real_tim_timstamp + " Paid cases MTD for " + user_clusters + " is " + mtd_inforced_count +
					". Paid cases YTD for " + user_clusters + " is " + ytd_inforced_count;
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse="As of " +real_tim_timstamp + " Paid cases MTD for " + user_clusters + " is " + mtd_inforced_count +
					". Paid cases YTD for " + user_clusters + " is " + ytd_inforced_count;
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region)&& !"".equalsIgnoreCase(user_clusters) 
				&& "".equalsIgnoreCase(period))
		{
			finalresponse="As of " +real_tim_timstamp + " Paid cases MTD for " + user_clusters + " is " + mtd_inforced_count +
					". Paid cases YTD for " + user_clusters + " is " + ytd_inforced_count;
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)&& "".equalsIgnoreCase(user_clusters) 
				&& "".equalsIgnoreCase(period))
		{
			finalresponse="As of " +real_tim_timstamp + " Paid cases MTD for " + user_region + " is " + mtd_inforced_count +
					". Paid cases YTD for " + user_region + " is " + ytd_inforced_count;
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& !"".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(superZone))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " + real_tim_timstamp + " Paid cases " + period + " for " + channel + " is " + ytd_inforced_count;

				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " + real_tim_timstamp + " Paid cases " + period + " for " + channel + " is " + mtd_inforced_count;

				}else
				{
					finalresponse="As of " + real_tim_timstamp + " for " + channel+ " Paid cases - " + period+ " (as on last batch) is " + daily_inforced_count1+
							" and FTD (as on current date) is "+daily_inforced_count2;

				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getNativ_ytd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getNativ_mtd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getHybride_mtd_inforced_count();
				}
				else
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getNativ_daily_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getHybride_daily_inforced_count();
				}
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& !"".equalsIgnoreCase(period)) {
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp + " Paid cases " + period + " for " + superZone+ " is " + ytd_inforced_count;

				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp + " Paid cases " + period + " for " + superZone+ " is " + mtd_inforced_count;

				}else
				{
					finalresponse="As of " + real_tim_timstamp + " for " + superZone+ " Paid cases - " + period + " (as on last batch) is " + daily_inforced_count1+
							" and FTD (as on current date) is "+daily_inforced_count2;

				}
			}else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getNativ_ytd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getNativ_mtd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getHybride_mtd_inforced_count();
				}
				else
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getNativ_daily_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(keyMarket)  && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& !"".equalsIgnoreCase(period)) {
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp + " Paid cases " + period + " for KM " + keyMarket+ " is " + ytd_inforced_count;

				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp + " Paid cases " + period + " for KM " + keyMarket+ " is " + mtd_inforced_count;

				}else
				{
					finalresponse="As of " + real_tim_timstamp + " for KM " + keyMarket+ " Paid cases - " + period + " (as on last batch) is " + daily_inforced_count1+
							" and FTD (as on current date) is "+daily_inforced_count2;

				}
			}else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getNativ_ytd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getNativ_mtd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getHybride_mtd_inforced_count();
				}
				else
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getNativ_daily_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& !"".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp + " Paid cases " + period + " for " + userzone+ " zone is " + ytd_inforced_count;

				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp + " Paid cases " + period + " for " + userzone+ " zone is " + mtd_inforced_count;

				}else
				{
					finalresponse="As of " + real_tim_timstamp + " for " + userzone+ " Paid cases - " + period + " (as on last batch) is " + daily_inforced_count1+
							" and FTD (as on current date) is "+daily_inforced_count2;

				}
			}else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getNativ_ytd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getNativ_mtd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getHybride_mtd_inforced_count();
				}
				else
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getNativ_daily_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)&& "".equalsIgnoreCase(user_clusters) 
				&& !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{	
					finalresponse="As of " + real_tim_timstamp + " Paid cases " + period + " for " + user_region + " is " + ytd_inforced_count;
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " + real_tim_timstamp + " Paid cases " + period + " for " + user_region + " is " + mtd_inforced_count;
				}else
				{
					finalresponse="As of " + real_tim_timstamp + " for " + user_region+ " Paid cases - " + period + " (as on last batch) is " + daily_inforced_count1+
							" and FTD (as on current date) is "+daily_inforced_count2;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getNativ_ytd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getNativ_mtd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getHybride_mtd_inforced_count();
				}
				else
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getNativ_daily_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
			}
		}
		/*----------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region)&& !"".equalsIgnoreCase(user_clusters) 
				&& !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{	
					finalresponse="As of " + real_tim_timstamp + " Paid cases " + period + " for " + user_clusters + " is " + ytd_inforced_count;
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " + real_tim_timstamp + " Paid cases " + period + " for " + user_clusters + " is " + mtd_inforced_count;
				}else
				{
					finalresponse="As of " + real_tim_timstamp + " for " + user_clusters+ " Paid cases - " + period + " (as on last batch) is " + daily_inforced_count1+
							" and FTD (as on current date) is "+daily_inforced_count2;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getNativ_ytd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getNativ_mtd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getHybride_mtd_inforced_count();
				}
				else
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getNativ_daily_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
			}
		}
		/*-------New Cases channel region cluster period------------------------*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)&& !"".equalsIgnoreCase(user_clusters) 
				&& !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{	
					finalresponse="As of " + real_tim_timstamp + " Paid cases " + period + " for " + user_clusters + " is " + ytd_inforced_count;
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " + real_tim_timstamp + " Paid cases " + period + " for " + user_clusters + " is " + mtd_inforced_count;
				}else
				{
					finalresponse="As of " + real_tim_timstamp + " for " + user_clusters+ " Paid cases - " + period + " (as on last batch) is " + daily_inforced_count1+
							" and FTD (as on current date) is "+daily_inforced_count2;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getNativ_ytd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getNativ_mtd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getHybride_mtd_inforced_count();
				}
				else
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getNativ_daily_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters) 
				&& !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{	
					finalresponse="As of " + real_tim_timstamp + " Paid cases " + period + " for " + user_region + " is " + ytd_inforced_count;
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " + real_tim_timstamp + " Paid cases " + period + " for " + user_region + " is " + mtd_inforced_count;
				}else
				{
					finalresponse="As of " + real_tim_timstamp + " for " + user_region+ " Paid cases - " + period + " (as on last batch) is " + daily_inforced_count1+
							" and FTD (as on current date) is "+daily_inforced_count2;
				}
			}else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getNativ_ytd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getNativ_mtd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getHybride_mtd_inforced_count();
				}
				else
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getNativ_daily_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && !"".equalsIgnoreCase(user_clusters)
				&& !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{	
					finalresponse="As of " + real_tim_timstamp + " Paid cases " + period + " for " + user_clusters + " is " + ytd_inforced_count;
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " + real_tim_timstamp + " Paid cases " + period + " for " + user_clusters + " is " + mtd_inforced_count;
				}else
				{
					finalresponse="As of " + real_tim_timstamp + " for " + user_clusters+ " Paid cases - " + period + " (as on last batch) is " + daily_inforced_count1+
							" and FTD (as on current date) is "+daily_inforced_count2;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getNativ_ytd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getNativ_mtd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getHybride_mtd_inforced_count();
				}
				else
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getNativ_daily_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
			}
		}else if(!"".equalsIgnoreCase(channel)&&!"".equalsIgnoreCase(user_clusters)&&!"".equalsIgnoreCase(period)) {
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{	
					finalresponse="As of " + real_tim_timstamp + " Paid cases " + period + " for " + user_clusters + " is " + ytd_inforced_count;
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " + real_tim_timstamp + " Paid cases " + period + " for " + user_clusters + " is " + mtd_inforced_count;
				}else
				{
					finalresponse="As of " + real_tim_timstamp + " for " + user_clusters+ " Paid cases - " + period + " (as on last batch) is " + daily_inforced_count1+
							" and FTD (as on current date) is "+daily_inforced_count2;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getNativ_ytd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getNativ_mtd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getHybride_mtd_inforced_count();
				}
				else
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getNativ_daily_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
			}
		}else if(!"".equalsIgnoreCase(channel)&&!"".equalsIgnoreCase(user_clusters)&&"".equalsIgnoreCase(period)) {
			finalresponse="As of " +real_tim_timstamp + " Paid cases MTD for " + user_clusters + " is " + mtd_inforced_count +
					". Paid cases YTD for " + user_clusters + " is " + ytd_inforced_count;
		}
		else
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " + real_tim_timstamp + " Paid cases " + period + " for MLI is " + ytd_inforced_count +
							". If you want to see the channel wise business numbers, please specify the same.";
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " + real_tim_timstamp + " Paid cases " + period + " for MLI is " + mtd_inforced_count +
							". If you want to see the channel wise business numbers, please specify the same.";
				}else
				{
					finalresponse="As of " + real_tim_timstamp + " for MLI Paid cases " + period + " (as on last batch) is " + daily_inforced_count1+
							" and FTD (as on current date) is "+daily_inforced_count2+
							" If you want to see the channel wise business numbers, please specify the same.";
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getNativ_ytd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases YTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getNativ_mtd_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases MTD is "+NatHybInforced.inforcedBean.getHybride_mtd_inforced_count();
				}
				else
				{
					finalresponse="As of "+NatHybInforced.inforcedBean.getReal_tim_timstamp()+", For Native ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getNativ_daily_inforced_count()+
							"\n\n For Hybrid ecomm - Paid cases FTD is "+NatHybInforced.inforcedBean.getHybride_ytd_inforced_count();
				}
			}
		}
		return finalresponse.toString();
	}
}

