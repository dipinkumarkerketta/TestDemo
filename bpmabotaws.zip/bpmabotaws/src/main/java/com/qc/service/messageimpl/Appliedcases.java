package com.qc.service.messageimpl;

import com.qc.jsonImpl.NatHybApplied;

public class Appliedcases 
{
	public static String appliedCasesIntent(String channel, String period, String user_region, String user_circle, String userzone , String real_tim_timstamp,
			String mtd_applied_count, String ytd_applied_count, String daily_applied_count, String subchannel,
			String user_clusters, String user_go,
			String daily_applied_afyp2, String daily_applied_count2, String daily_applied_adj_ifyp2, String superZone, String keyMarket)
	{

		String finalresponse="";

		if("MLI".equalsIgnoreCase(channel))
		{channel="";}
		if("Monthly".equalsIgnoreCase(period))
		{period="";}
		else
		{
			period=period.toUpperCase();
		}
		if(!"".equalsIgnoreCase(user_circle))
		{
			user_region="Circle "+user_circle;
		}
		if(!"".equalsIgnoreCase(user_go))
		{
			user_clusters="Office "+user_go;
		}
		if(!"".equalsIgnoreCase(subchannel))
		{
			channel = subchannel;
		}
		if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(keyMarket))
		{
			finalresponse= "As of "+real_tim_timstamp+" Applied cases MTD for MLI is "
					+mtd_applied_count+". Applied cases YTD for MLI is "+ytd_applied_count+ 
					". If you want to see the channel wise business numbers, please specify the same.";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(keyMarket))
		{

			if("Internet Sales".equalsIgnoreCase(channel))
			{
				finalresponse = "As of " + NatHybApplied.appliedBean.getReal_tim_timstamp() 
				+ ", For Native ecomm - Applied cases MTD is " +NatHybApplied.appliedBean.getNativ_mtd_applied_count() 
				+ ". Applied cases YTD is " + NatHybApplied.appliedBean.getNativ_ytd_applied_count()
				+ "\n\n For Hybrid ecomm - Applied cases MTD is " + NatHybApplied.appliedBean.getHybride_mtd_applied_count() 
				+ ". Applied cases YTD is " +NatHybApplied.appliedBean.getHybride_ytd_applied_count() + ".";
			}
			else 
			{
				if("Agency".equalsIgnoreCase(channel))
				{
					finalresponse= "As of "+real_tim_timstamp+" Applied cases MTD for "+channel+
							" is "+mtd_applied_count+". Applied cases YTD for "+channel+" is "+ytd_applied_count+
							" If you want to see the data for sub-channels, please enter sub-channel name � Defence, Office within office, APC, Greenfield.";
				}
				else
				{
					finalresponse= "As of "+real_tim_timstamp+" Applied cases MTD for "+channel+
							" is "+mtd_applied_count+". Applied cases YTD for "+channel+" is "+ytd_applied_count+
							". If you want to see the Zone/Region wise business numbers, please specify the same.";
				}
			}

		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+real_tim_timstamp+" Applied cases MTD for "+superZone+" is "
					+mtd_applied_count+". Applied cases YTD for "+superZone+" is " +ytd_applied_count+
					". If you want to see the zone wise business numbers, please specify the same.";
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
		{
			finalresponse= "As of "+real_tim_timstamp+" Applied cases MTD for "+userzone+" is "
					+mtd_applied_count+". Applied cases YTD for "+userzone+" is " +ytd_applied_count+
					". If you want to see the region wise business numbers, please specify the same.";
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) )
		{
			finalresponse= "As of "+real_tim_timstamp+" Applied cases MTD for KM "+keyMarket+" is "
					+mtd_applied_count+". Applied cases YTD for KM "+keyMarket+" is " +ytd_applied_count;
					
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
		{
			finalresponse= "As of "+real_tim_timstamp+" Applied cases MTD for "+user_region+ " is " 
					+mtd_applied_count+ ". Applied cases YTD for "+user_region+" is "+ ytd_applied_count;

		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+real_tim_timstamp+" Applied cases MTD for "+user_clusters+ " is " 
					+mtd_applied_count+ ". Applied cases YTD for "+user_clusters+" is "+ ytd_applied_count;

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+real_tim_timstamp+" Applied cases MTD for "+user_clusters+ " is " 
					+mtd_applied_count+ ". Applied cases YTD for "+user_clusters+" is "+ ytd_applied_count;

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+real_tim_timstamp+" Applied cases MTD for "+user_clusters+ " is " 
					+mtd_applied_count+ ". Applied cases YTD for "+user_clusters+" is "+ ytd_applied_count;

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of "+real_tim_timstamp+" Applied cases MTD for "+user_region+ " is " 
					+mtd_applied_count+ ". Applied cases YTD for "+user_region+" is "+ ytd_applied_count;

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(superZone))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of " +real_tim_timstamp+" Applied cases "+period+" for "+channel+ " is "+ytd_applied_count+
							". If you want to see the Zone/Region wise business numbers, please specify the same.";
				}
				else if("MTD".equalsIgnoreCase(period)){
					finalresponse="As of " +real_tim_timstamp+" Applied cases "+period+" for "+channel+ " is "+mtd_applied_count+
							". If you want to see the Zone/Region wise business numbers, please specify the same.";
				}
				else
				{
					finalresponse="As of " +real_tim_timstamp+" for "+channel+ " Applied cases - FTD (as on last batch) is "+daily_applied_count+
							" and FTD (as on current date) is "+daily_applied_count2;
							
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_count();
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_count();
				}
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(keyMarket)
				&& "".equalsIgnoreCase(user_region)
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied cases "+period+ " for "+superZone+" is "+ytd_applied_count+
							". If you want to see the region wise business numbers, please specify the same.";
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied cases "+period+ " for "+superZone+" is "+mtd_applied_count+
							". If you want to see the region wise business numbers, please specify the same.";
				}
				else
				{
					finalresponse="As of " +real_tim_timstamp+" for "+superZone+ " Applied cases - FTD (as on last batch) is "+daily_applied_count+
							" and FTD (as on current date) is "+daily_applied_count2;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_count();
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_count();
				}
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region)
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied cases "+period+ " for KM "+keyMarket+" is "+ytd_applied_count+
							". If you want to see the region wise business numbers, please specify the same.";
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied cases "+period+ " for KM "+keyMarket+" is "+mtd_applied_count+
							". If you want to see the region wise business numbers, please specify the same.";
				}
				else
				{
					finalresponse="As of " +real_tim_timstamp+" for KM "+keyMarket+ " Applied cases - FTD (as on last batch) is "+daily_applied_count+
							" and FTD (as on current date) is "+daily_applied_count2;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_count();
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_count();
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region)
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied cases "+period+ " for "+userzone+" zone is "+ytd_applied_count+
							". If you want to see the region wise business numbers, please specify the same.";
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied cases "+period+ " for "+userzone+" zone is "+mtd_applied_count+
							". If you want to see the region wise business numbers, please specify the same.";
				}
				else
				{
					finalresponse="As of " +real_tim_timstamp+" for "+userzone+ " Applied cases - FTD (as on last batch) is "+daily_applied_count+
							" and FTD (as on current date) is "+daily_applied_count2;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_count();
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_count();
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+real_tim_timstamp+" Applied cases "+period+" for "+ user_region+" is "+ytd_applied_count+" ";
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+real_tim_timstamp+" Applied cases "+period+" for "+ user_region+" is "+mtd_applied_count+" ";
				}else
				{
					finalresponse="As of " +real_tim_timstamp+" for "+user_region+ " Applied cases - FTD (as on last batch) is "+daily_applied_count+
							" and FTD (as on current date) is "+daily_applied_count2;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_count();
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_count();
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+real_tim_timstamp+" Applied cases "+period+" for "+ user_clusters+" is "+ytd_applied_count+" ";
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+real_tim_timstamp+" Applied cases "+period+" for "+ user_clusters+" is "+mtd_applied_count+" ";
				}else
				{
					finalresponse="As of " +real_tim_timstamp+" for "+user_clusters+ " Applied cases - FTD (as on last batch) is "+daily_applied_count+
							" and FTD (as on current date) is "+daily_applied_count2;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_count();
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_count();
				}
			}
		}
		/*-------------------new Condition added by bhavneet 31-08-2018*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+real_tim_timstamp+" Applied cases "+period+" for "+ user_clusters+" is "+ytd_applied_count+" ";
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+real_tim_timstamp+" Applied cases "+period+" for "+ user_clusters+" is "+mtd_applied_count+" ";
				}else
				{
					finalresponse="As of " +real_tim_timstamp+" for "+user_clusters+ " Applied cases - FTD (as on last batch) is "+daily_applied_count+
							" and FTD (as on current date) is "+daily_applied_count2;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_count();
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_count();
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+real_tim_timstamp+" Applied cases "+period+" for "+ user_region+" is "+ytd_applied_count+" ";
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+real_tim_timstamp+" Applied cases "+period+" for "+ user_region+" is "+mtd_applied_count+" ";
				}else
				{
					finalresponse="As of " +real_tim_timstamp+" for "+user_region+ " Applied cases - FTD (as on last batch) is "+daily_applied_count+
							" and FTD (as on current date) is "+daily_applied_count2;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_count();
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_count();
				}
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+real_tim_timstamp+" Applied cases "+period+" for "+ user_clusters+" is "+ytd_applied_count+" ";
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse=" As of "+real_tim_timstamp+" Applied cases "+period+" for "+ user_clusters+" is "+mtd_applied_count+" ";
				}else
				{
					finalresponse="As of " +real_tim_timstamp+" for "+user_clusters+ " Applied cases - FTD (as on last batch) is "+daily_applied_count+
							" and FTD (as on current date) is "+daily_applied_count2;
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_count();
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_count();
				}
			}
		}
		else
		{
			if(!"Internet Sales".equalsIgnoreCase(channel))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied cases "+period+" for MLI is "+ytd_applied_count+
							". If you want to see the channel wise business numbers, please specify the same.";
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+real_tim_timstamp+" Applied cases "+period+" for MLI is "+mtd_applied_count+
							". If you want to see the channel wise business numbers, please specify the same.";
				}else
				{
					finalresponse="As of " +real_tim_timstamp+" for MLI Applied Cases - FTD (as on last batch) is "+daily_applied_count+
							" and FTD (as on current date) is "+daily_applied_count2+"."
									+ " If you want to see the channel wise business numbers, please specify the same.";
				}
			}
			else
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_count();
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_count();
				}
				else
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", For Native ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_count()+"."
							+ "\n\n For Hybrid ecomm - Applied cases FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_count();
				}
			}
		}
		return finalresponse.toString();
	}
}
