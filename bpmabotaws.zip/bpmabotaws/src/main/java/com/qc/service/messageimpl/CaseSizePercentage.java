package com.qc.service.messageimpl;

public class CaseSizePercentage {

	public static String caseSizePercentageIntent(String channel, String period, String user_region, String user_circle, 
			String userzone , String real_tim_timstamp,
			String achiev_mtd_case_size, String achiev_ytd_case_size, String subchannel,String user_clusters, String user_go, String superZone, String keyMarket)
	{
		String finalresponse="";
		if("MLI".equalsIgnoreCase(channel))
		{channel="";}
		if("Monthly".equalsIgnoreCase(period))
		{period="";}
		else
		{
			if("FTD".equalsIgnoreCase(period))
			{
				period="MTD";
			}
			else
			{
				period=period.toUpperCase();
			}
		}
		if(!"".equalsIgnoreCase(user_circle))
		{user_region="Circle "+user_circle;}
		if(!"".equalsIgnoreCase(user_go))
		{
			user_clusters="Office "+user_go;
		}
		if(!"".equalsIgnoreCase(subchannel))
		{channel = subchannel;}

		if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
		   && "".equalsIgnoreCase(period)&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(superZone)&& "".equalsIgnoreCase(keyMarket))
		{
			finalresponse= "MLI Case Size acheivement MTD: "+achiev_mtd_case_size+"%, YTD " +achiev_ytd_case_size+"% till "+real_tim_timstamp+
					". If you want to see the channel wise business numbers, please specify.";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(superZone)&& "".equalsIgnoreCase(keyMarket))
		{
			if("Agency".equalsIgnoreCase(channel))
			{
				finalresponse= channel+" channel Case Size acheivement MTD: "+achiev_mtd_case_size+"%, YTD " +achiev_ytd_case_size+"% till "+real_tim_timstamp
						+ "If you want to see the data for sub-channels, please enter sub-channel name - Defence, Office within office, APC, Greenfield.";
			}
			else{
				finalresponse= channel+" channel Case Size acheivement MTD: "+achiev_mtd_case_size+"%, YTD " +achiev_ytd_case_size+"% till "+real_tim_timstamp+
						". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
			{
				finalresponse= superZone+" Case Size acheivement MTD: "+achiev_mtd_case_size+"%, YTD " +achiev_ytd_case_size+"% till "+real_tim_timstamp+
						". If you want to see the zone wise business numbers, please specify the same.";
			}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
		{
			finalresponse= "Zone "+userzone+" Case Size acheivement MTD: "+achiev_mtd_case_size+"%, YTD " +achiev_ytd_case_size+"% till "+real_tim_timstamp+
					". If you want to see the region wise business numbers, please specify the same.";
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
			{
				finalresponse= "KM "+keyMarket+" Case Size acheivement MTD: "+achiev_mtd_case_size+"%, YTD " +achiev_ytd_case_size+"% till "+real_tim_timstamp+
						". If you want to see the zone wise business numbers, please specify the same.";
			}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= ""+user_region+" Case Size acheivement MTD: "+achiev_mtd_case_size+"%, YTD " +achiev_ytd_case_size+"% till "+real_tim_timstamp+
					". If you want to see the region wise business numbers, please specify the same.";

		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= ""+user_clusters+" Case Size acheivement MTD: "+achiev_mtd_case_size+"%, YTD " +achiev_ytd_case_size+"% till "+real_tim_timstamp;
					

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= ""+user_clusters+" Case Size acheivement MTD: "+achiev_mtd_case_size+"%, YTD " +achiev_ytd_case_size+"% till "+real_tim_timstamp;

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= ""+user_clusters+" Case Size acheivement MTD: "+achiev_mtd_case_size+"%, YTD " +achiev_ytd_case_size+"% till "+real_tim_timstamp+
					".";

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= ""+user_region+" Case Size acheivement MTD: "+achiev_mtd_case_size+"%, YTD " +achiev_ytd_case_size+"% till "+real_tim_timstamp+
					". If you want to see the region wise business numbers, please specify the same.";

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(superZone))
		{	

			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= channel+" channel Case Size acheivement "+period+" : "+achiev_ytd_case_size+"% till "+real_tim_timstamp+
						". If you want to see the Zone/Region wise business numbers, please specify the same. ";
			}else
			{
				finalresponse= channel+" channel Case Size acheivement "+period+" : "+achiev_mtd_case_size+"% till "+real_tim_timstamp+
						". If you want to see the Zone/Region wise business numbers, please specify the same. ";
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(superZone) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse= superZone+" Case Size acheivement "+period+" : "+achiev_ytd_case_size+"% till "+real_tim_timstamp+
							". If you want to see the region wise business numbers please specify the same.";
				}else
				{
					finalresponse= superZone+" Case Size acheivement "+period+" : "+achiev_mtd_case_size+"% till "+real_tim_timstamp+
							". If you want to see the region wise business numbers please specify the same.";
				}
			}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(keyMarket) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse= "KM "+keyMarket+" Case Size acheivement "+period+" : "+achiev_ytd_case_size+"% till "+real_tim_timstamp+
							". If you want to see the region wise business numbers please specify the same.";
				}else
				{
					finalresponse= "KM "+keyMarket+" Case Size acheivement "+period+" : "+achiev_mtd_case_size+"% till "+real_tim_timstamp+
							". If you want to see the region wise business numbers please specify the same.";
				}
			}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period) && "".equalsIgnoreCase(keyMarket))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "Zone "+userzone+" Case Size acheivement "+period+" : "+achiev_ytd_case_size+"% till "+real_tim_timstamp+
						". If you want to see the region wise business numbers please specify the same.";
			}else
			{
				finalresponse= "Zone "+userzone+" Case Size acheivement "+period+" : "+achiev_mtd_case_size+"% till "+real_tim_timstamp+
						". If you want to see the region wise business numbers please specify the same.";
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= ""+user_region+" Case Size acheivement " +period+" : "+achiev_ytd_case_size+"% till "+real_tim_timstamp+
						". If you want to see the region wise business numbers please specify the same.";
			}else
			{
				finalresponse= ""+user_region+" Case Size acheivement " +period+" : "+achiev_mtd_case_size+"% till "+real_tim_timstamp+
						". If you want to see the region wise business numbers please specify the same.";
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= ""+user_clusters+" Case Size acheivement " +period+" : "+achiev_ytd_case_size+"% till "+real_tim_timstamp+
						".";
			}else
			{
				finalresponse= ""+user_clusters+" Case Size acheivement " +period+" : "+achiev_mtd_case_size+"% till "+real_tim_timstamp+
						".";
			}
		}
		/*added by bhavneet*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse= ""+user_clusters+" Case Size acheivement " +period+" : "+achiev_ytd_case_size+"% till "+real_tim_timstamp+
							".";
				}else
				{
					finalresponse= ""+user_clusters+" Case Size acheivement " +period+" : "+achiev_mtd_case_size+"% till "+real_tim_timstamp+
							".";
				}
			}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= ""+user_region+" Case Size acheivement " +period+" : "+achiev_ytd_case_size+"% till "+real_tim_timstamp+
						". If you want to see the region wise business numbers please specify the same.";
			}else
			{
				finalresponse= ""+user_region+" Case Size acheivement " +period+" : "+achiev_mtd_case_size+"% till "+real_tim_timstamp+
						". If you want to see the region wise business numbers please specify the same.";
			}
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
			&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= ""+user_clusters+" Case Size acheivement " +period+" : "+achiev_ytd_case_size+"% till "+real_tim_timstamp+
						".";
			}else
			{
				finalresponse= ""+user_clusters+" Case Size acheivement " +period+" : "+achiev_mtd_case_size+"% till "+real_tim_timstamp+
						".";
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(user_clusters)&&"".equalsIgnoreCase(period)) {
			finalresponse= ""+user_clusters+" Case Size acheivement MTD: "+achiev_mtd_case_size+"%, YTD " +achiev_ytd_case_size+"% till "+real_tim_timstamp+
					".";
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(user_clusters)&&!"".equalsIgnoreCase(period)) {
			
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= ""+user_clusters+" Case Size acheivement " +period+" : "+achiev_ytd_case_size+"% till "+real_tim_timstamp+
						".";
			}else
			{
				finalresponse= ""+user_clusters+" Case Size acheivement " +period+" : "+achiev_mtd_case_size+"% till "+real_tim_timstamp+
						".";
			}
		}
		else
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "MLI Case Size acheivement " +period+" : "+achiev_ytd_case_size+"% till "+real_tim_timstamp+
						". If you want to see the channel wise business numbers please specify the same.";
			}else
			{
				finalresponse= "MLI Case Size acheivement " +period+" : "+achiev_mtd_case_size+"% till "+real_tim_timstamp+
						". If you want to see the channel wise business numbers please specify the same.";
			}
		}
		return finalresponse.toString();
	}
}