package com.qc.utils;
import java.util.ResourceBundle;
import java.net.HttpURLConnection;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.BufferedReader;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class HttpUrlConnection 
{
	private static Logger logger = LogManager.getLogger(HttpUrlConnection.class);
	public String httpConnection_response(String action, String segment, String serviceChannel, String productType)
	{
		ResourceBundle res = ResourceBundle.getBundle("com.qc.bot.resources.application");
		HttpURLConnection conn = null;
		StringBuilder result = new StringBuilder();
		String output = ""; 
		try
		{
			if("NUMBERS".equalsIgnoreCase(action) || "AdjMFYP".equalsIgnoreCase(action) ||"WIP".equalsIgnoreCase(action)
					||"WIP.YES".equalsIgnoreCase(action)||"APPLIED".equalsIgnoreCase(action))
			{
				XTrustProvider trustProvider=new XTrustProvider();
				trustProvider.install();
				String serviceurl = res.getString("serviceurl");
				URL url = new URL(serviceurl);
				conn = (HttpURLConnection) url.openConnection();
				HttpsURLConnection.setFollowRedirects(true);
				conn.setDoInput(true);
				conn.setDoOutput(true);
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Content-Type", "application/json");
				StringBuilder requestdata=new StringBuilder();
				requestdata.append("	{	");
				requestdata.append("	  \"header\": {	");
				requestdata.append("	    \"correlationId\": \"1234567890\",	");
				requestdata.append("	    \"msgVersion\": \"\",	");
				requestdata.append("	    \"appId\": \"\",	");
				requestdata.append("	    \"userId\": \"\",	");
				requestdata.append("	    \"password\": \"\",	");
				requestdata.append("	    \"rollId\":\"\"	");
				requestdata.append("	  },	");
				requestdata.append("	  \"payload\": {	");
				requestdata.append("	    \"segment\": \""+segment+"\",	");
				requestdata.append("	    \"channel\": \""+serviceChannel+"\"	");
				requestdata.append("	  }	");
				requestdata.append("	}	");
				logger.info("External API Call : START");
				OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
				writer.write(requestdata.toString());
				writer.flush();
				try {writer.close(); } 
				catch (Exception e1) 
				{
					logger.info(e1);
				}

				int apiResponseCode = conn.getResponseCode();
				if(apiResponseCode == 200)
				{
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
					while ((output = br.readLine()) != null) 
					{
						result.append(output);
					}
					conn.disconnect();
					br.close();
					logger.info("External API Call : END");

				}
				else
				{
					logger.info("Unable to connect External API");
				}
			}
			else
			{
				XTrustProvider trustProvider=new XTrustProvider();
				trustProvider.install();
				String serviceurl = res.getString("serviceurl2");
				URL url = new URL(serviceurl);
				conn = (HttpURLConnection) url.openConnection();
				HttpsURLConnection.setFollowRedirects(true);
				conn.setDoInput(true);
				conn.setDoOutput(true);
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Content-Type", "application/json");
				StringBuilder requestdata=new StringBuilder();
				requestdata.append("	{	");
				requestdata.append("	  \"header\": {	");
				requestdata.append("	    \"correlationId\": \"1234567890\",	");
				requestdata.append("	    \"msgVersion\": \"\",	");
				requestdata.append("	    \"appId\": \"\",	");
				requestdata.append("	    \"userId\": \"\",	");
				requestdata.append("	    \"password\": \"\",	");
				requestdata.append("	    \"rollId\":\"\"	");
				requestdata.append("	  },	");
				requestdata.append("	  \"payload\": {	");
				requestdata.append("	    \"segment\": \""+segment+"\",	");
				requestdata.append("	    \"channel\": \""+serviceChannel+"\",	");
				requestdata.append("	    \"planType\": \""+productType+"\"	");
				requestdata.append("	  }	");
				requestdata.append("	}	");
				logger.info("External API Call : START");
				OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
				writer.write(requestdata.toString());
				writer.flush();
				try {writer.close(); } 
				catch (Exception e1) 
				{
					logger.info(e1);
				}

				int apiResponseCode = conn.getResponseCode();
				if(apiResponseCode == 200)
				{
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
					while ((output = br.readLine()) != null) 
					{
						result.append(output);
					}
					conn.disconnect();
					br.close();
					logger.info("External API Call : END");

				}
				else
				{
					logger.info("Unable to connect External API");
				}
			}
			}
			catch(Exception e)
			{

				logger.info(e);
			}
			return result.toString();
		}
	}

