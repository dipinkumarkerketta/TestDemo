package com.qc.common;

public class ADMHeaderConstant {

	public static final String MTD = "Paid Cases#ADJ MFYP \n (In lacs)#Wgt MFYP \n (In lacs)#FYC without Segment Bonus \n (In lacs)#Growth %";
	public static final String YTD = "Paid Cases#ADJ MFYP \n (In lacs)#Wgt MFYP \n (In lacs)#FYC without Segment Bonus \n (In lacs)#Growth %";
	public static final String MTD_APPLIED_BUSINESS = "NOPs#WFYP \n (In lacs)#ADJ IFYP \n (In lacs)";
	public static final String EARLY_SUCCESS_AGGENTS_DETAILS = "Total Agents#Since Inception#Current FY#Current Month";
	public static final String DETAILS_OF_PROACTIVE_AGENTS = "MTD Proactive Agents#YTD Proactive Agents#FYC Shortfall \n (In lacs)";
	public static final String ACTIVITY_ON_YTD_BASIS = "Total M/M#YTD Paid Cases#Shortfall#MTD Active#YTD Active";
	public static final String QUALITY_RECRUITMENT_9IN90_CAREER_AGENT_SCHEME_STATUS = "QR Target MTD#Actual QR#No. of Agents Qualified for 9in90#Probable Agents#Get Going Agents";
	public static final String COMMISSION_DETAILS_OF_AGENTS="FYC Q1 \n (In lacs)#FYC Q2 \n (In lacs)#FYC Q3 \n (In lacs)#FYC Q4 \n (In lacs)#YTD FYC \n (In lacs)";
	public static final String MTD_PROTECTION_UPDATE="NOPs#WFYP \n (In lacs)#ADJ MFYP \n (In lacs)";
	public static final String YTD_PROTECTION_UPDATE="NOPs#WFYP \n (In lacs)#ADJ MFYP \n (In lacs)";
	public static final String RENEWAL_BUSINESS_UPDATE="Collectible \n (In lacs)#Collected \n (In lacs)#13 M Persistency";
	
}

