package com.qc.common;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.UUID;
import javax.net.ssl.HttpsURLConnection;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.qc.api.service.impl.BotApiServiceImpl;

@Service
public class CallingJavaService 
{
	
	private static Logger logger = LogManager.getLogger(BotApiServiceImpl.class);
	public String callService(String action, String segment, String serviceChannel, String user_sub_channel, 
			String userzone, String user_region, String user_circle, String user_clusters, String user_go, String user_cmo,
			String user_amo, String planType, String policyNumber, String user_superzone, String user_keyMarket)
	{
		String  DevMode = "N";
		StringBuilder requestdata = new StringBuilder();
		StringBuilder result = new StringBuilder();
		String output = new String();
		ResourceBundle res = ResourceBundle.getBundle("com.qc.bot.resources.application");
		HttpURLConnection conn = null;

		if("WIP".equalsIgnoreCase(action) || "WIP.YES".equalsIgnoreCase(action) || "NUMBERS".equalsIgnoreCase(action)
				|| "AdjMFYP".equalsIgnoreCase(action) || "APPLIED".equalsIgnoreCase(action) 
				|| "Achievement".equalsIgnoreCase(action) ||"Growth".equalsIgnoreCase(action) || "Penetration".equalsIgnoreCase(action)
				|| "NB.Paidcases".equalsIgnoreCase(action)|| "NB.AdjMFYP".equalsIgnoreCase(action)|| "NB.Applied".equalsIgnoreCase(action)
				|| "NB.casesize".equalsIgnoreCase(action) ||"NB.AppliedAdjIFYP".equalsIgnoreCase(action)||"NB.AppliedCases".equalsIgnoreCase(action)
				|| "NB.LPCAPPADJIFYP".equalsIgnoreCase(action) || "NB.LPCAPPADJAFYP".equalsIgnoreCase(action)|| "NB.LPCAPLCASES".equalsIgnoreCase(action) 
				|| "NB.LPCPAIDADJMFYP".equalsIgnoreCase(action)	|| "NB.LPCPAIDCASES".equalsIgnoreCase(action) || "NB.casesize%".equalsIgnoreCase(action) 
				||"NB.Growth".equalsIgnoreCase(action) || "NB.Recruitment".equalsIgnoreCase(action) ||"NB.Recruitment%".equalsIgnoreCase(action)
				||"NB.GROWTHAPLADGIFYP".equalsIgnoreCase(action)||"NB.GROWTHAPLAFYP".equalsIgnoreCase(action)||"NB.GROWTHAPLCASES".equalsIgnoreCase(action)
				||"NB.GROWTHLPCADJMFYP".equalsIgnoreCase(action)||"NB.GROWTHLPCAPLADJIFYP".equalsIgnoreCase(action)||"NB.GROWTHLPCAPLAFYP".equalsIgnoreCase(action)
				||"NB.GROWTHLPCAPLCASES".equalsIgnoreCase(action)||"NB.GROWTHLPCPAIDCASES".equalsIgnoreCase(action)||"NB.GROWTHPAIDCASES".equalsIgnoreCase(action)
				||"NB.GROWTHRECRUITMENT".equalsIgnoreCase(action)||"NB.Achievement".equalsIgnoreCase(action) ||"NB.MODEMIX".equalsIgnoreCase(action) 
				||"NB.ProductMix".equalsIgnoreCase(action) || "NB.ProductMixADJMFYP".equalsIgnoreCase(action) || "NB.Productmixpaidcase".equalsIgnoreCase(action)
				||"NB.GROWTHCASESIZE".equalsIgnoreCase(action)||"NB.GROWTHAPLADJIFYP".equalsIgnoreCase(action)||"NB.HUBHOLD".equalsIgnoreCase(action) 
				||"NB.RENEWAL".equalsIgnoreCase(action)||"NB.NTU".equalsIgnoreCase(action)||"NB.PROTECTION".equalsIgnoreCase(action)
		        ||"PROTECTION.YES".equalsIgnoreCase(action) ||"NBRegion.NBRegion-yes".equalsIgnoreCase(action)
		        ||"NBZONE.NBZONE-YES".equalsIgnoreCase(action) ||"NBCLUSTER.NBCLUSTER-YES".equalsIgnoreCase(action)
		     	||"NBCIRCLE.NBCIRCLE-YES".equalsIgnoreCase(action)
		 	    ||"NBSUBCHANNEL.NBSUBCHANNEL-YES".equalsIgnoreCase(action)
		        ||"NBGO.NBGO-YES".equalsIgnoreCase(action)
		        ||"nbperiod.nbperiod-yes".equalsIgnoreCase(action)
		        ||"nbchannel.nbchannel-yes".equalsIgnoreCase(action) 
		        ||"NB.POLICYSTATUS".equalsIgnoreCase(action)) 
		{
			if("West Bengal".equalsIgnoreCase(user_circle))
				{
					user_circle=user_circle.replaceAll("\\s","");
				}
			try {
				/*if("Achievement".equalsIgnoreCase(action))
				{
					if("Agency".equalsIgnoreCase(serviceChannel) || "Axis Bank".equalsIgnoreCase(serviceChannel))
					{
						user_sub_channel=serviceChannel;
					}
				}*/
				String user_designation_desc="";
				logger.info("External API Call : Mlichatbotsprint2enchance : START");
				String serviceurl = res.getString("servicegetUserDetail");
				logger.info("SERVICE URL :-"+serviceurl);
				URL url = new URL(serviceurl);
				if(DevMode!=null && !"".equalsIgnoreCase(DevMode) && "Y".equalsIgnoreCase(DevMode))
				{
					Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
					conn = (HttpURLConnection) url.openConnection(proxy);
					logger.info("Connection opened");
				}else{
					conn = (HttpURLConnection) url.openConnection();
					logger.info("Connection opened");
				}
				UUID uniqueId = UUID.randomUUID();
				HttpsURLConnection.setFollowRedirects(true);
				conn.setDoInput(true);
				conn.setDoOutput(true);
				conn.setRequestMethod("POST");
				conn.setRequestProperty("Content-Type", "application/json");
				requestdata.append("	{	");
				requestdata.append("	  \"header\": {	");
				requestdata.append("	    \"correlationId\": \""+uniqueId+"\",	");
				requestdata.append("	    \"msgVersion\": \"\",	");
				requestdata.append("	    \"appId\": \"\",	");
				requestdata.append("	    \"userId\": \"\",	");
				requestdata.append("	    \"password\": \"\",	");
				requestdata.append("	    \"rollId\":\"\"	");
				requestdata.append("	  },	");
				requestdata.append("	  \"payload\": {	");
				requestdata.append("	    \"segment\": \""+segment+"\",	");
				requestdata.append("	    \"designationDesc\": \""+user_designation_desc+"\",");
				requestdata.append("	    \"channel\": \""+serviceChannel+"\",");
				requestdata.append("	    \"subChannel\": \""+user_sub_channel+"\",");
				requestdata.append("	    \"superZone\": \""+user_superzone+"\",");
				requestdata.append("	    \"zone\": \""+userzone+"\",");
				requestdata.append("	    \"keyMarket\": \""+user_keyMarket+"\",");
				requestdata.append("	    \"region\": \""+user_region.trim()+"\",");
				requestdata.append("	    \"circle\": \""+user_circle+"\",");
				requestdata.append("	    \"cluster\": \""+user_clusters+"\",");
				requestdata.append("	    \"go\": \""+user_go+"\",");
				requestdata.append("	    \"cmo\": \""+user_cmo+"\",");
				requestdata.append("	    \"amo\": \""+user_amo+"\",");
				requestdata.append("	    \"planType\": \""+planType+"\",");
				requestdata.append("	     \"policyNumber\": \""+policyNumber+"\"");
				requestdata.append("	  }	");
				requestdata.append("	}	");
				//logger.debug("API request :: " +requestdata);
				//System.out.println("START External API Call : Mlichatbotsprint2enchance");
				logger.info("START External API Call : Mlichatbotsprint2enchance");
				OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
				writer.write(requestdata.toString());
				writer.flush();
				try {writer.close(); } catch (Exception e1) {}
				int apiResponseCode = conn.getResponseCode();
				//System.out.println("API Response Code : Mlichatbotsprint2enchance"+ apiResponseCode);
				logger.debug("API Response Code : Mlichatbotsprint2enchance"+ apiResponseCode);
				if(apiResponseCode == 200)
				{
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
					while ((output = br.readLine()) != null) 
					{
						result.append(output);
					}
					conn.disconnect();
					br.close();
					logger.info("Connection closed");
					logger.info("END External API Call : Mlichatbotsprint2enchance");
				}
				else
				{
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
					while ((output = br.readLine()) != null) {
						result.append(output);
					}
					conn.disconnect();
					br.close();
					logger.info("Connection closed");
				}
			}
			catch(Exception exc)
			{
			  logger.error("Something went wrong while calling API Call : Mlichatbotsprint2enchance");
			}
		}
		return result.toString();
	}
}
