package com.qc.common;

import org.springframework.stereotype.Service;

@Service
public class CustomizeChannel 
{
	public String messageChannel(String user_ssoid,String user_circle, String user_region, String userzone, String user_sub_channel, String source,
			String channel, String user_clusters, String user_go, String employeeIdentification, String user_superzone, String user_keyMarket)
	{
		String LacsCr="";
		String msgChannel="";
		for(int i=0; i<=0; i++)
		{
			if(!"".equalsIgnoreCase(user_clusters))
			{
				msgChannel=user_clusters;
				msgChannel="Cluster "+msgChannel;
				LacsCr="Lacs";
				break;
			}
			if(!"".equalsIgnoreCase(user_go))
			{
				msgChannel=user_go;
				msgChannel="GO "+msgChannel;
				LacsCr="Lacs";
				break;
			}
			if(!"".equalsIgnoreCase(user_circle))
			{
				msgChannel=user_circle;
				msgChannel="Circle "+msgChannel;
				LacsCr="Lacs";
				break;
			}
			else if(!"".equalsIgnoreCase(user_region))
			{
				msgChannel=user_region;
				msgChannel="Region "+msgChannel;
				LacsCr="Lacs";
				break;
			}

			else if(!"".equalsIgnoreCase(user_keyMarket)) {
				msgChannel="KM "+user_keyMarket;
				LacsCr="Lacs";
				break;
			}

			else if(!"".equalsIgnoreCase(userzone))
			{
				msgChannel=userzone;
				msgChannel="Zone "+msgChannel;
				LacsCr="Cr";
				break;
			}

			else if(!"".equalsIgnoreCase(user_superzone)) {
				msgChannel=user_superzone;
				LacsCr="Cr";
				break;
			}

			else if(!"".equalsIgnoreCase(user_sub_channel) && !"CH".equalsIgnoreCase(employeeIdentification))
			{
				if("google".equalsIgnoreCase(source))
				{
					msgChannel=user_sub_channel;
					LacsCr="Cr";
					break;
				}
				else
				{
					msgChannel=user_sub_channel;
					msgChannel="SubChannel "+msgChannel;
					LacsCr="Cr";
					break;
				}
			}
			else
			{
				msgChannel = channel;
				LacsCr="Cr";
			}
		}
		return LacsCr +"~" + msgChannel;
	}
}
