package com.qc.common;

public class DRHeaderConstant {

	public static final String MTD = "Paid Cases#ADJ MFYP#Wgt MFYP#FYC without Segment Bonus#Growth %";
	public static final String YTD = "Paid Cases#ADJ MFYP#Wgt MFYP#FYC without Segment Bonus#Growth %";
	public static final String MTD_APPLIED_BUSINESS = "NOPs#WFYP#ADJ IFYP";
	public static final String EARLY_SUCCESS="Cases#FYC#Cases Short Fall#FYC Short Fall#Final";
	public static final String PROACTIVE_ON_MTD="FYC Actual#FYC Target#Short in FYC#Proactive M/M MTD#Status";
	public static final String PROACTIVE_ON_YTD="FYC Actual#FYC Target#Short in FYC#Status";
	public static final String ACTIVITY_ON_YTD_BASIS1="Paid Cases#Shortfall#M/M#Vintage#StarLevel";
	public static final String ACTIVITY_ON_YTD_BASIS2="Last Active Date#YTD Active Status#MTD Active Status";
	public static final String Quality_Recruitment="QR FYC#Shortfall QR FYC#Qualifying Month";
	public static final String nine_In90="Paid Case#FYC#Shortfall in Paidcase#Shortfall in FYC#Qualifying Month";
	public static final String COMMISSION_DETAILS="Career Agent Scheme#FYC Q1#FYC Q2#FYC Q3#FYC Q4";
	public static final String MTD_PROTECTION_UPDATE="NOPs#WFYP#ADJ MFYP";
	public static final String YTD_PROTECTION_UPDATE="NOPs#WFYP#ADJ MFYP";
	public static final String RENEWAL_BUSINESS_UPDATE="Collectible#Collected#13 M Persistency";
	
}

