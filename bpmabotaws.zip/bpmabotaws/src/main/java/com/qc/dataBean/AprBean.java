package com.qc.dataBean;

import org.springframework.stereotype.Component;

@Component
public class AprBean 
{
	private String agentId;
	private String botType;
	private String paidCasesMtd;
	private String adjMfypMtd;
	private String weightMfypMtd;
	private String fycMtd;
	private String mtdGrowthPer;
	private String ytdPaidCases;
	private String adjMfypYtd;
	private String weightMfypYtd;
	private String ytdFycWithoutSgBonus;
	private String ytdGrowthPer;
	private String mtdAppliedNops;
	private String mtdAppliedWfyp;
	private String aplAdjIfypMtd;
	private String earlySuccessCases;
	private String earlySuccessFyc;
	private String earlySuccessCasesShortfall;
	private String earlySuccessFycShortfall;
	private String finalEarlySuccess;
	private String fycActualMtd;
	private String fycTargetMtd;
	private String shortInFycMtd;
	private String proactiveManMonthsMtd;
	private String proStatusmtd;
	private String fycActualYtd;
	private String fycYtdTarget;
	private String shortInFycYtd;
	private String proStatusYtd;
	private String paidCsYtd;
	private String shortInPaidCase;
	private String manMonthytd;
	private String activityYtdVintage;
	private String activityYtdStLevel;
	private String activityYtdLastActiveDate;
	private String activityYtdYtdActiveStatus;
	private String activityYtdMtdActiveStatus;
	private String qrFyc;
	private String shortfallQrFyc;
	private String qrQualifyingMonth;
	private String paidCase9In90;
	private String fyc9In90;
	private String shortInPaidCase9In90;
	private String shortInFyc9In90;
	private String 	nineIn90Month;
	private String 	comisionDtlCarerAgtSchmSt;
	private String 	fycqtr1;
	private String 	fycqtr2;
	private String 	fycqtr3;
	private String 	fycqtr4;
	private String mtdProtectionUpdateNop;
	private String mtdProtectionUpdateWfyp;
	private String mtdProtectionUpdateAdjMfyp;
	private String ytdProtectionUpdateNop;
	private String ytdProtectionUpdateWfyp;
	private String ytdProtectionUpdateAdjMfyp;
	private String renewalBusiUpdtCollectible;
	private String renewalBusiUpdtCollected;
	private String renewalBusiUpdt13mPersis;
	private String earlySuccessTotalAgents;
	private String earlySuccessSinceInception;
	private String earlySuccessCurrentFy;
	private String earlySuccessCurrentMonth;
	private String mtdProactiveAgents;
	private String ytdProactiveAgents;
	private String fycShortfall;
	private String activityTotalMM;
	private String activityMtdActive;
	private String activityYtdActive;
	private String qrTargetMtd;
	private String agentsQualifiedNineIn90;
	private String probableAgents;
	private String getGoingAgents;
	private String ytdFyc;
	private String actualQr;
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getBotType() {
		return botType;
	}
	public void setBotType(String botType) {
		this.botType = botType;
	}
	public String getPaidCasesMtd() {
		return paidCasesMtd;
	}
	public void setPaidCasesMtd(String paidCasesMtd) {
		this.paidCasesMtd = paidCasesMtd;
	}
	public String getAdjMfypMtd() {
		return adjMfypMtd;
	}
	public void setAdjMfypMtd(String adjMfypMtd) {
		this.adjMfypMtd = adjMfypMtd;
	}
	public String getWeightMfypMtd() {
		return weightMfypMtd;
	}
	public void setWeightMfypMtd(String weightMfypMtd) {
		this.weightMfypMtd = weightMfypMtd;
	}
	public String getFycMtd() {
		return fycMtd;
	}
	public void setFycMtd(String fycMtd) {
		this.fycMtd = fycMtd;
	}
	public String getMtdGrowthPer() {
		return mtdGrowthPer;
	}
	public void setMtdGrowthPer(String mtdGrowthPer) {
		this.mtdGrowthPer = mtdGrowthPer;
	}
	public String getYtdPaidCases() {
		return ytdPaidCases;
	}
	public void setYtdPaidCases(String ytdPaidCases) {
		this.ytdPaidCases = ytdPaidCases;
	}
	public String getAdjMfypYtd() {
		return adjMfypYtd;
	}
	public void setAdjMfypYtd(String adjMfypYtd) {
		this.adjMfypYtd = adjMfypYtd;
	}
	public String getWeightMfypYtd() {
		return weightMfypYtd;
	}
	public void setWeightMfypYtd(String weightMfypYtd) {
		this.weightMfypYtd = weightMfypYtd;
	}
	public String getYtdFycWithoutSgBonus() {
		return ytdFycWithoutSgBonus;
	}
	public void setYtdFycWithoutSgBonus(String ytdFycWithoutSgBonus) {
		this.ytdFycWithoutSgBonus = ytdFycWithoutSgBonus;
	}
	public String getYtdGrowthPer() {
		return ytdGrowthPer;
	}
	public void setYtdGrowthPer(String ytdGrowthPer) {
		this.ytdGrowthPer = ytdGrowthPer;
	}
	public String getMtdAppliedNops() {
		return mtdAppliedNops;
	}
	public void setMtdAppliedNops(String mtdAppliedNops) {
		this.mtdAppliedNops = mtdAppliedNops;
	}
	public String getMtdAppliedWfyp() {
		return mtdAppliedWfyp;
	}
	public void setMtdAppliedWfyp(String mtdAppliedWfyp) {
		this.mtdAppliedWfyp = mtdAppliedWfyp;
	}
	public String getAplAdjIfypMtd() {
		return aplAdjIfypMtd;
	}
	public void setAplAdjIfypMtd(String aplAdjIfypMtd) {
		this.aplAdjIfypMtd = aplAdjIfypMtd;
	}
	public String getEarlySuccessCases() {
		return earlySuccessCases;
	}
	public void setEarlySuccessCases(String earlySuccessCases) {
		this.earlySuccessCases = earlySuccessCases;
	}
	public String getEarlySuccessFyc() {
		return earlySuccessFyc;
	}
	public void setEarlySuccessFyc(String earlySuccessFyc) {
		this.earlySuccessFyc = earlySuccessFyc;
	}
	public String getEarlySuccessCasesShortfall() {
		return earlySuccessCasesShortfall;
	}
	public void setEarlySuccessCasesShortfall(String earlySuccessCasesShortfall) {
		this.earlySuccessCasesShortfall = earlySuccessCasesShortfall;
	}
	public String getEarlySuccessFycShortfall() {
		return earlySuccessFycShortfall;
	}
	public void setEarlySuccessFycShortfall(String earlySuccessFycShortfall) {
		this.earlySuccessFycShortfall = earlySuccessFycShortfall;
	}
	public String getFinalEarlySuccess() {
		return finalEarlySuccess;
	}
	public void setFinalEarlySuccess(String finalEarlySuccess) {
		this.finalEarlySuccess = finalEarlySuccess;
	}
	public String getFycActualMtd() {
		return fycActualMtd;
	}
	public void setFycActualMtd(String fycActualMtd) {
		this.fycActualMtd = fycActualMtd;
	}
	public String getFycTargetMtd() {
		return fycTargetMtd;
	}
	public void setFycTargetMtd(String fycTargetMtd) {
		this.fycTargetMtd = fycTargetMtd;
	}
	public String getShortInFycMtd() {
		return shortInFycMtd;
	}
	public void setShortInFycMtd(String shortInFycMtd) {
		this.shortInFycMtd = shortInFycMtd;
	}
	public String getProactiveManMonthsMtd() {
		return proactiveManMonthsMtd;
	}
	public void setProactiveManMonthsMtd(String proactiveManMonthsMtd) {
		this.proactiveManMonthsMtd = proactiveManMonthsMtd;
	}
	public String getProStatusmtd() {
		return proStatusmtd;
	}
	public void setProStatusmtd(String proStatusmtd) {
		this.proStatusmtd = proStatusmtd;
	}
	public String getFycActualYtd() {
		return fycActualYtd;
	}
	public void setFycActualYtd(String fycActualYtd) {
		this.fycActualYtd = fycActualYtd;
	}
	public String getFycYtdTarget() {
		return fycYtdTarget;
	}
	public void setFycYtdTarget(String fycYtdTarget) {
		this.fycYtdTarget = fycYtdTarget;
	}
	public String getShortInFycYtd() {
		return shortInFycYtd;
	}
	public void setShortInFycYtd(String shortInFycYtd) {
		this.shortInFycYtd = shortInFycYtd;
	}
	public String getProStatusYtd() {
		return proStatusYtd;
	}
	public void setProStatusYtd(String proStatusYtd) {
		this.proStatusYtd = proStatusYtd;
	}
	public String getPaidCsYtd() {
		return paidCsYtd;
	}
	public void setPaidCsYtd(String paidCsYtd) {
		this.paidCsYtd = paidCsYtd;
	}
	public String getShortInPaidCase() {
		return shortInPaidCase;
	}
	public void setShortInPaidCase(String shortInPaidCase) {
		this.shortInPaidCase = shortInPaidCase;
	}
	public String getManMonthytd() {
		return manMonthytd;
	}
	public void setManMonthytd(String manMonthytd) {
		this.manMonthytd = manMonthytd;
	}
	public String getActivityYtdVintage() {
		return activityYtdVintage;
	}
	public void setActivityYtdVintage(String activityYtdVintage) {
		this.activityYtdVintage = activityYtdVintage;
	}
	public String getActivityYtdStLevel() {
		return activityYtdStLevel;
	}
	public void setActivityYtdStLevel(String activityYtdStLevel) {
		this.activityYtdStLevel = activityYtdStLevel;
	}
	public String getActivityYtdLastActiveDate() {
		return activityYtdLastActiveDate;
	}
	public void setActivityYtdLastActiveDate(String activityYtdLastActiveDate) {
		this.activityYtdLastActiveDate = activityYtdLastActiveDate;
	}
	public String getActivityYtdYtdActiveStatus() {
		return activityYtdYtdActiveStatus;
	}
	public void setActivityYtdYtdActiveStatus(String activityYtdYtdActiveStatus) {
		this.activityYtdYtdActiveStatus = activityYtdYtdActiveStatus;
	}
	public String getActivityYtdMtdActiveStatus() {
		return activityYtdMtdActiveStatus;
	}
	public void setActivityYtdMtdActiveStatus(String activityYtdMtdActiveStatus) {
		this.activityYtdMtdActiveStatus = activityYtdMtdActiveStatus;
	}
	public String getQrFyc() {
		return qrFyc;
	}
	public void setQrFyc(String qrFyc) {
		this.qrFyc = qrFyc;
	}
	public String getShortfallQrFyc() {
		return shortfallQrFyc;
	}
	public void setShortfallQrFyc(String shortfallQrFyc) {
		this.shortfallQrFyc = shortfallQrFyc;
	}
	public String getQrQualifyingMonth() {
		return qrQualifyingMonth;
	}
	public void setQrQualifyingMonth(String qrQualifyingMonth) {
		this.qrQualifyingMonth = qrQualifyingMonth;
	}
	public String getPaidCase9In90() {
		return paidCase9In90;
	}
	public void setPaidCase9In90(String paidCase9In90) {
		this.paidCase9In90 = paidCase9In90;
	}
	public String getFyc9In90() {
		return fyc9In90;
	}
	public void setFyc9In90(String fyc9In90) {
		this.fyc9In90 = fyc9In90;
	}
	public String getShortInPaidCase9In90() {
		return shortInPaidCase9In90;
	}
	public void setShortInPaidCase9In90(String shortInPaidCase9In90) {
		this.shortInPaidCase9In90 = shortInPaidCase9In90;
	}
	public String getShortInFyc9In90() {
		return shortInFyc9In90;
	}
	public void setShortInFyc9In90(String shortInFyc9In90) {
		this.shortInFyc9In90 = shortInFyc9In90;
	}
	public String getNineIn90Month() {
		return nineIn90Month;
	}
	public void setNineIn90Month(String nineIn90Month) {
		this.nineIn90Month = nineIn90Month;
	}
	public String getComisionDtlCarerAgtSchmSt() {
		return comisionDtlCarerAgtSchmSt;
	}
	public void setComisionDtlCarerAgtSchmSt(String comisionDtlCarerAgtSchmSt) {
		this.comisionDtlCarerAgtSchmSt = comisionDtlCarerAgtSchmSt;
	}
	public String getFycqtr1() {
		return fycqtr1;
	}
	public void setFycqtr1(String fycqtr1) {
		this.fycqtr1 = fycqtr1;
	}
	public String getFycqtr2() {
		return fycqtr2;
	}
	public void setFycqtr2(String fycqtr2) {
		this.fycqtr2 = fycqtr2;
	}
	public String getFycqtr3() {
		return fycqtr3;
	}
	public void setFycqtr3(String fycqtr3) {
		this.fycqtr3 = fycqtr3;
	}
	public String getFycqtr4() {
		return fycqtr4;
	}
	public void setFycqtr4(String fycqtr4) {
		this.fycqtr4 = fycqtr4;
	}
	public String getMtdProtectionUpdateNop() {
		return mtdProtectionUpdateNop;
	}
	public void setMtdProtectionUpdateNop(String mtdProtectionUpdateNop) {
		this.mtdProtectionUpdateNop = mtdProtectionUpdateNop;
	}
	public String getMtdProtectionUpdateWfyp() {
		return mtdProtectionUpdateWfyp;
	}
	public void setMtdProtectionUpdateWfyp(String mtdProtectionUpdateWfyp) {
		this.mtdProtectionUpdateWfyp = mtdProtectionUpdateWfyp;
	}
	public String getMtdProtectionUpdateAdjMfyp() {
		return mtdProtectionUpdateAdjMfyp;
	}
	public void setMtdProtectionUpdateAdjMfyp(String mtdProtectionUpdateAdjMfyp) {
		this.mtdProtectionUpdateAdjMfyp = mtdProtectionUpdateAdjMfyp;
	}
	public String getYtdProtectionUpdateNop() {
		return ytdProtectionUpdateNop;
	}
	public void setYtdProtectionUpdateNop(String ytdProtectionUpdateNop) {
		this.ytdProtectionUpdateNop = ytdProtectionUpdateNop;
	}
	public String getYtdProtectionUpdateWfyp() {
		return ytdProtectionUpdateWfyp;
	}
	public void setYtdProtectionUpdateWfyp(String ytdProtectionUpdateWfyp) {
		this.ytdProtectionUpdateWfyp = ytdProtectionUpdateWfyp;
	}
	public String getYtdProtectionUpdateAdjMfyp() {
		return ytdProtectionUpdateAdjMfyp;
	}
	public void setYtdProtectionUpdateAdjMfyp(String ytdProtectionUpdateAdjMfyp) {
		this.ytdProtectionUpdateAdjMfyp = ytdProtectionUpdateAdjMfyp;
	}
	public String getRenewalBusiUpdtCollectible() {
		return renewalBusiUpdtCollectible;
	}
	public void setRenewalBusiUpdtCollectible(String renewalBusiUpdtCollectible) {
		this.renewalBusiUpdtCollectible = renewalBusiUpdtCollectible;
	}
	public String getRenewalBusiUpdtCollected() {
		return renewalBusiUpdtCollected;
	}
	public void setRenewalBusiUpdtCollected(String renewalBusiUpdtCollected) {
		this.renewalBusiUpdtCollected = renewalBusiUpdtCollected;
	}
	public String getRenewalBusiUpdt13mPersis() {
		return renewalBusiUpdt13mPersis;
	}
	public void setRenewalBusiUpdt13mPersis(String renewalBusiUpdt13mPersis) {
		this.renewalBusiUpdt13mPersis = renewalBusiUpdt13mPersis;
	}
	public String getEarlySuccessTotalAgents() {
		return earlySuccessTotalAgents;
	}
	public void setEarlySuccessTotalAgents(String earlySuccessTotalAgents) {
		this.earlySuccessTotalAgents = earlySuccessTotalAgents;
	}
	public String getEarlySuccessSinceInception() {
		return earlySuccessSinceInception;
	}
	public void setEarlySuccessSinceInception(String earlySuccessSinceInception) {
		this.earlySuccessSinceInception = earlySuccessSinceInception;
	}
	public String getEarlySuccessCurrentFy() {
		return earlySuccessCurrentFy;
	}
	public void setEarlySuccessCurrentFy(String earlySuccessCurrentFy) {
		this.earlySuccessCurrentFy = earlySuccessCurrentFy;
	}
	public String getEarlySuccessCurrentMonth() {
		return earlySuccessCurrentMonth;
	}
	public void setEarlySuccessCurrentMonth(String earlySuccessCurrentMonth) {
		this.earlySuccessCurrentMonth = earlySuccessCurrentMonth;
	}
	public String getMtdProactiveAgents() {
		return mtdProactiveAgents;
	}
	public void setMtdProactiveAgents(String mtdProactiveAgents) {
		this.mtdProactiveAgents = mtdProactiveAgents;
	}
	public String getYtdProactiveAgents() {
		return ytdProactiveAgents;
	}
	public void setYtdProactiveAgents(String ytdProactiveAgents) {
		this.ytdProactiveAgents = ytdProactiveAgents;
	}
	public String getFycShortfall() {
		return fycShortfall;
	}
	public void setFycShortfall(String fycShortfall) {
		this.fycShortfall = fycShortfall;
	}
	public String getActivityTotalMM() {
		return activityTotalMM;
	}
	public void setActivityTotalMM(String activityTotalMM) {
		this.activityTotalMM = activityTotalMM;
	}
	public String getActivityMtdActive() {
		return activityMtdActive;
	}
	public void setActivityMtdActive(String activityMtdActive) {
		this.activityMtdActive = activityMtdActive;
	}
	public String getActivityYtdActive() {
		return activityYtdActive;
	}
	public void setActivityYtdActive(String activityYtdActive) {
		this.activityYtdActive = activityYtdActive;
	}
	public String getQrTargetMtd() {
		return qrTargetMtd;
	}
	public void setQrTargetMtd(String qrTargetMtd) {
		this.qrTargetMtd = qrTargetMtd;
	}
	public String getAgentsQualifiedNineIn90() {
		return agentsQualifiedNineIn90;
	}
	public void setAgentsQualifiedNineIn90(String agentsQualifiedNineIn90) {
		this.agentsQualifiedNineIn90 = agentsQualifiedNineIn90;
	}
	public String getProbableAgents() {
		return probableAgents;
	}
	public void setProbableAgents(String probableAgents) {
		this.probableAgents = probableAgents;
	}
	public String getGetGoingAgents() {
		return getGoingAgents;
	}
	public void setGetGoingAgents(String getGoingAgents) {
		this.getGoingAgents = getGoingAgents;
	}
	public String getYtdFyc() {
		return ytdFyc;
	}
	public void setYtdFyc(String ytdFyc) {
		this.ytdFyc = ytdFyc;
	}
	public String getActualQr() {
		return actualQr;
	}
	public void setActualQr(String actualQr) {
		this.actualQr = actualQr;
	}
	
	
}
