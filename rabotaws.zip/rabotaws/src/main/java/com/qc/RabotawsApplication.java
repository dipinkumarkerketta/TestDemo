package com.qc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabotawsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RabotawsApplication.class, args);
	}

}
