package com.qc.service.messageimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class FundValue 
{
	@Autowired
	private Bean bean;
	private static Logger logger = LogManager.getLogger(FundValue.class);
	public String fundValueIntent(String policyNumber)
	{
		String finalresponse="";
		if("TRAD".equalsIgnoreCase(bean.getBTCH_TIMSTAMP()))
		{
			finalresponse="Fund Value is not applicable for this policy.";
		}
		else if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
			+" the fund value against "+policyNumber+" is Rs "+bean.getPol_fund_value();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
			+" the fund value against "+policyNumber+" is Rs "+bean.getPol_fund_value();
		}
		else
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
			+" the fund value against "+policyNumber+" is Rs "+bean.getPol_fund_value();
		}
		logger.info("AdjMFYPIntent--"+ finalresponse);
		return finalresponse;
	}
}
