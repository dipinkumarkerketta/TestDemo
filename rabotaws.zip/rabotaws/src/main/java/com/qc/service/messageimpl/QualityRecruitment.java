package com.qc.service.messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class QualityRecruitment 
{
	@Autowired
	private Bean bean;
	String finalresponse="";
	public String qualityRecruitmentIntent(String channel)
	{
		if("Agency".equalsIgnoreCase(channel))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your Quality Recruitment count YTD is :"+bean.getQua_recruit_with_extra_cre_act();  
		}
		else if("BancAssurance".equalsIgnoreCase(channel))
		{
			finalresponse="NOT APPLICABLE";
		}
		else if("Axis Bank".equalsIgnoreCase(channel))
		{
			finalresponse="Not Applicable for "+channel+" channel";
		}
		else
		{
			finalresponse="Not Applicable for "+channel+" channel";
		}
		return finalresponse;
	}
}
