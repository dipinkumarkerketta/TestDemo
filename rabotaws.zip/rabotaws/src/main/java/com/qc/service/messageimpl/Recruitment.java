package com.qc.service.messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class Recruitment 
{
	@Autowired
	private Bean bean;
	String finalresponse="";

	public String recruitmentIntent(String channel)
	{
		if("Agency".equalsIgnoreCase(channel))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your Recruitment count MTD is :"+bean.getRecruitment_mtd()+" and YTD is : "+bean.getRecruitment_ytd();
		}
		else if("BancaAssurance".equalsIgnoreCase(channel))
		{
			finalresponse="Not Applicable for "+channel+" channel";
		}
		else if("Axis Bank".equalsIgnoreCase(channel))
		{
			finalresponse="Not Applicable for "+channel+" channel";
		}
		else
		{
			finalresponse="Not Applicable for "+channel+" channel";
		}
		return finalresponse;
	}
}
