package com.qc.service.messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;
import com.qc.api.service.impl.BotApiServiceImpl;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Service
public class AdjMFYP 
{
	@Autowired
	private Bean bean;
	
	private static Logger logger = LogManager.getLogger(AdjMFYP.class);
	public String adjMFYPIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
		finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your Total Adj.MFYP is FTD : Rs. "+bean.getAdj_mfyp_ftd()+
				" Lacs, MTD : Rs."+bean.getAdj_mfyp_mtd()+ " Lacs, QTD : Rs."+bean.getAdj_mfyp_qtd()+ " Lacs, YTD : Rs."+bean.getAdj_mfyp_ytd()+" Lacs.";
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
		finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your Total Adj.MFYP is FTD : Rs. "+bean.getAdj_mfyp_ftd()+
				" Lacs, MTD : Rs."+bean.getAdj_mfyp_mtd()+ " Lacs, QTD : Rs."+bean.getAdj_mfyp_qtd()+ " Lacs, YTD : Rs."+bean.getAdj_mfyp_ytd()+" Lacs.";
		}
		else
		{
		finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your Total Adj.MFYP is FTD : Rs. "+bean.getAdj_mfyp_ftd()+
				" Lacs, MTD : Rs."+bean.getAdj_mfyp_mtd()+ " Lacs, QTD : Rs."+bean.getAdj_mfyp_qtd()+ " Lacs, YTD : Rs."+bean.getAdj_mfyp_ytd()+" Lacs.";
		}
		logger.info("AdjMFYPIntent--"+ finalresponse);
		return finalresponse;
	}
}
