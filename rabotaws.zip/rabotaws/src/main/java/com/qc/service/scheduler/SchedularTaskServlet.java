/*package com.qc.service.scheduler;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import java.util.ResourceBundle;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;



import com.qc.api.service.impl.BotApiServiceImpl;


public class SchedularTaskServlet extends HttpServlet 
{
	private static Logger logger = LogManager.getLogger(SchedularTaskServlet.class);
	static ResourceBundle res=ResourceBundle.getBundle("com.qc.service.scheduler.Scheduler");
	static ScheduledExecutorService scheduledExecutorService;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}  	
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		
	}
	
	public void init(ServletConfig config) throws ServletException
    {
		super.init(config);
		proceed();
	}	
	
	private void proceed(){
		try{
			Runnable cacheRemoveScheduler = new  MapCacheRemovalScheduler();
			try
			{
				scheduledExecutorService = Executors.newScheduledThreadPool(2);
				schedulerTasks("CacheRemove", cacheRemoveScheduler);
				
				logger.info("SchedularTaskServlet Is Commented:-");
			}
			catch(Exception e)
			{
				logger.error("Error in SchedularTaskServlet in Scheduling batches :-"+e,new Throwable());
			}				
			logger.info("SchedularTaskServlet Is Initialization finished:-");
		}catch (Exception e) {
			logger.error("Error in scheduler servlet." + e);
		}
	}
	
	public void schedulerTasks(String taskName,Runnable schedular)
	{
		logger.info("Getting in for Schedular for "+taskName+" :-");		
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy kk:mm");			
		Calendar cal =null;
		int weekDay=0;
		int weekMin=0;
		int weekHr=0;
		int runDay=0;
		int runHr=0;
		int runMin=0;
		int runDelay=0;
		float runGap=0;
		String flag=null;
		try
		{	
			flag=res.getString("com.max.chatbot."+taskName+".Active").trim();
			if(flag!=null && flag.equalsIgnoreCase("Y"))
			{
				cal=Calendar.getInstance();
				weekDay = cal.get(Calendar.DAY_OF_WEEK);//get the Weekday , from 1 to 7
				weekHr = cal.get(Calendar.HOUR_OF_DAY);//get the Weekday , from 0 to 23
				weekMin = cal.get(Calendar.MINUTE);//get the Weekday , from 0 to 59
				logger.info("Current Week Day is :-"+weekDay+", Week Hrs:-"+weekHr+", Week Min:-"+weekMin);	
				runDay=Integer.parseInt(res.getString("com.max.chatbot."+taskName+".day").trim());
				runDay=runDay==0?weekDay:runDay;
				runHr=Integer.parseInt(res.getString("com.max.chatbot."+taskName+".hrs").trim());
				runHr=runHr==0?weekHr:runHr;
				runMin=Integer.parseInt(res.getString("com.max.chatbot."+taskName+".min").trim());
				//runGap=Integer.parseInt(res.getString("com.max.aml."+taskName+".gap").trim());
				runGap=Float.parseFloat(res.getString("com.max.chatbot."+taskName+".gap").trim());
				runDelay=Integer.parseInt(res.getString("com.max.chatbot."+taskName+".delay").trim());
				logger.info("Values get from the ApplicationResource Property file for "+taskName+" are:- WeekDay:-"+runDay+" Hrs:-"+runHr+" Min:-"+runMin+" Delay in Days:-"+runDelay+" Gap in Hrs:-"+runGap);
				runDay=(runDay>=weekDay)?(runDay-weekDay):runDay+(7-weekDay);			
				runHr=(runHr>=weekHr)?(runHr-weekHr):runHr+(24-weekHr);
				runMin=(runMin>=weekMin)?(runMin-weekMin):runMin-weekMin;
				logger.info("Difference between current values and Property values are :-days:-"+runDay+" Hrs:-"+runHr+" Min:-"+runMin);
				cal.setTime(sdf.parse(sdf.format(new Date())));
				logger.info("Current Date is :-"+sdf.format(cal.getTime()));				
				cal.add(Calendar.DATE, runDay);			
				logger.info("Next Run Date after adding run Day is :-"+sdf.format(cal.getTime()));	
				cal.add(Calendar.HOUR, runHr);
				logger.info("Next Run Date run Hr is :-"+sdf.format(cal.getTime()));	
				cal.add(Calendar.MINUTE,runMin);
				logger.info("Next Run Date after adding run min is :-"+sdf.format(cal.getTime()));			
				runDay=Integer.parseInt(String.valueOf((cal.getTimeInMillis()-(sdf.parse(sdf.format(new Date()))).getTime())));
				logger.info("Next First run time is :-"+runDay);	
			    @SuppressWarnings("unused")
				ScheduledFuture<?> alarmFuture = scheduledExecutorService.scheduleWithFixedDelay(schedular,(long) runDay,(long) ((long) runDelay*runGap*60*60*1000), TimeUnit.MILLISECONDS);
			}
		}
		catch(Exception e)
		{
			logger.error("Error in Getting values for "+taskName+" is :-"+e,new Throwable());
		}
		logger.info("Going out from Schedular for "+taskName+":-");
	}	
}*/