package com.qc.service.messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.qc.api.entity.Bean;

@Service
public class WtgMFYP 
{
	@Autowired
	private Bean bean;
	private static Logger logger = LogManager.getLogger(WtgMFYP.class);
	public String wtgMFYPIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel()) || "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="Not Applicable";
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse=" As of "+bean.getREAL_TIM_TIMSTAMP()+", Your Total Wtg.MFYP FTD : Rs."
					+ " Lacs, MTD : Rs."+bean.getWtg_mfyp_mtd()+" Lacs, QTD : Rs."+bean.getWtg_mfyp_qtd()+" Lacs, YTD: Rs. "+bean.getWtg_mfyp_ytd()+" Lacs.";
		}
		else
		{
			finalresponse=" As of "+bean.getREAL_TIM_TIMSTAMP()+", Your Total Wtg. MFYP FTD : Rs."+bean.getWtg_mfyp_mtd()+""
					+ " Lacs, MTD : Rs."+bean.getWtg_mfyp_mtd()+" Lacs, QTD : Rs."+bean.getWtg_mfyp_qtd()+" Lacs, YTD: Rs. "+bean.getWtg_mfyp_ytd()+" Lacs.";
		}
		logger.info("WtgMFYP --"+finalresponse);
		return finalresponse;
	}
}
