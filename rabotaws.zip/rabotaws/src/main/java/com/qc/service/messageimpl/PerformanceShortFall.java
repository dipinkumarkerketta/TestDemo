package com.qc.service.messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class PerformanceShortFall 
{
	@Autowired
	private Bean bean;
	String finalresponse;
	public String performanceShortFallIntent(String channel)
	{
		if("Axis Bank".equalsIgnoreCase(channel))
		{
			finalresponse=" As of "+bean.getREAL_TIM_TIMSTAMP()+", Your shortfall in rolling 12 month adj. MFYP is Rs."+bean.getPrmtn_shrtfl_adj_mfyp_pln_ach()+", "
					+ " shortfall in rolling 6 month activation is "+bean.getPrmtn_shrtfl_actvn_ach()+"% and shortfall in Persistency % is "+bean.getPrmtn_shrtfl_15m_pers_qtd_ach()+"%.";
		}
		else if("BancAssurance".equalsIgnoreCase(channel))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your Shortfall in adj. MFYP is "+bean.getPromo_adj_p_mfyp_in_lacs_srtfl()+"L,"
					+ " Shortfall in Paid Cases is "+bean.getPromo_paid_cases_shortfall()+" and Shortfall in 15M Persistency is "+bean.getPromo_15m_pers_shortfall()+"L.";
		}
		else if("Agency".equalsIgnoreCase(channel))
		{
			finalresponse="NOT APPLICABLE";
		}
		else
		{
			finalresponse="NOT APPLICABLE";
		}
		return finalresponse;
	}
}
