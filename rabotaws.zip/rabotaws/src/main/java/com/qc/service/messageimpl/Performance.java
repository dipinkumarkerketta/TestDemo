package com.qc.service.messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class Performance 
{
	@Autowired
	private Bean bean;
	String finalresponse="";
	public String performanceIntent(String channel)
	{
		if("Axis Bank".equalsIgnoreCase(channel))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your rolling 12 month adj.MFYP is "+bean.getPerform_adj_mfyp_plan_ach_p()+"%,"
					+ " your rolling 6 month activation % is "+bean.getPerform_activation_ach_p()+"% and Persistency % is "
					+ bean.getPerform_15th_month_pers_qtd_p()+"%.";

		}
		else if("CAT".equalsIgnoreCase(channel))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", for 6 months cycle Your Weighted MFYP is Rs."+bean.getPromo_wtg_fyp_act_6m()+" at "
					+bean.getPromo_wtg_fyp_ach_p_6m()+"%, your NOP count is "+bean.getPromo_nop_act_6m()+" at "+bean.getPromo_nop_ach_p_6m()+"% and Collection is "
					+bean.getPromo_collection_ach_p()+"%. For 9 months cycle Your Weighted MFYP is Rs."+bean.getPromo_wtg_fyp_act_9m()+" at "
					+bean.getPromo_wtg_fyp_ach_p_9m()+"%, your NOP count is "+bean.getPromo_nop_act_9m()+" at "+bean.getPromo_nop_ach_p_9m()+"% and Collection is "
					+bean.getPromo_collection_ach_p()+"%. For 12 months cycle Your Weighted MFYP is Rs."+bean.getPromo_wtg_fyp_act12m()
					+" at "+bean.getPromo_wtg_fyp_ach_p_12m()+"%, your NOP count is "+bean.getPromo_nop_act12m()+" at "+bean.getPromo_nop_ach_p_12m()
					+"% and Collection is "+bean.getPromo_collection_ach_p()+"%.";
		}
		else if("Agency".equalsIgnoreCase(channel))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your Weighted MFYP is Rs. "+bean.getYtd_wtg_fyp_in_lac_act()+"L at "
					+bean.getYtd_wtg_fyp_in_lac_ach_p()+"% , your Quality Recruitment count is "+bean.getQua_recruit_with_extra_cre_act()+" at "
					+bean.getQua_recruit_ach_p()+"%, Active Agent is "+bean.getTot_proac_agt_mm_wit_extr_cred()+" and Collection is "+bean.getTot_proac_agt_mm_ach_p()+"%.";
		}
		else
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+", Your adj. MFYP is Rs."+bean.getPromo_adj_p_mfyp_in_lacs_act()
			+"L at "+bean.getPromo_adj_p_mfyp_in_lacs_p()+"%, Your Paid Cases count is "+bean.getPromo_paid_cases_act()+" at "
			+bean.getPromo_paid_cases_p()+"% and 15M Persistency is "+bean.getPromo_15m_pers_in_lacs_p()+"%.";
		}
		return finalresponse;
	}
}
